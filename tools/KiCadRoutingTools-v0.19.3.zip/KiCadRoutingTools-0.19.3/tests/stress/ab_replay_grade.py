#!/usr/bin/env python3
"""Replay a whole stress-test set into a fresh wave dir and grade it -- the A/B
harness on top of redo_stress_test.py (single-manifest replay).

`redo_stress_test.py` replays ONE board's recorded command manifest. This driver
replays every board in a set in parallel, then grades each board's *final* board
for DRC (at the route step's actual --clearance) and connectivity, and writes a
JSON summary. Run it once per code version ("wave") to A/B an engine change.

Two modes:

  # Grade one wave (the working tree decides which code runs):
  ab_replay_grade.py --set ~/Documents/kicad_stress_test/runs_set3 \
                     --out ~/Documents/kicad_stress_test/ab_run/old --label old

  # Compare two wave summaries:
  ab_replay_grade.py --compare .../old/summary.json .../new/summary.json

Typical A/B recipe (the engine change is uncommitted in the working tree):

  git stash push file1.py file2.py            # baseline = HEAD
  ab_replay_grade.py --set runs_set3 --out ab/old --label old
  git stash pop                               # candidate = HEAD + change
  ab_replay_grade.py --set runs_set3 --out ab/new --label new
  ab_replay_grade.py --compare ab/old/summary.json ab/new/summary.json

Notes / gotchas (see memory: rerun-stress-boards, grade-drc-at-routed-clearance):
- Manifests reference tools by ABSOLUTE repo path, so a replay always runs
  whatever is checked out -- the two waves MUST be sequential (shared git state),
  but boards WITHIN a wave run in parallel.
- A board whose chain breaks (e.g. a diff pair fails -> route_diff writes no
  output) reports chain_complete=False and is excluded from the DRC/conn
  comparison. Compare only counts boards complete in BOTH waves.
- DRC is graded at each board's own routed --clearance, parsed from its manifest.
"""
import argparse
import concurrent.futures
import json
import os
import re
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))  # for _gitver when run as a script
from _gitver import write_git_version, load_git_version, format_version

REPO = Path(__file__).resolve().parent.parent.parent  # tests/stress/ -> repo root


def route_clearance(manifest_txt, default="0.1"):
    """DRC must be graded at the routed clearance. A board may route different
    steps at different --clearance (e.g. a signal retry at 0.15 over a 0.1 base,
    plus planes at 0.1); grade at the MINIMUM so copper laid at the tightest
    clearance isn't phantom-flagged at a looser one (see grade-drc-at-routed-
    clearance: grading tigard at 0.15 vs its real 0.1 invents ~600 violations)."""
    vals = [float(v) for v in re.findall(r"--clearance\s+(\d[\d.]*)", manifest_txt)]
    return str(min(vals)) if vals else default


def final_output_name(manifest_txt):
    """Final board = last .kicad_pcb token of the last non-check command.

    Output naming varies per board (<board>_stepN, <board>_signal, step1_signal,
    ...), so detect it from the manifest rather than globbing a fixed pattern.
    For route*.py the output is the 2nd positional and for fanout it is --output;
    in both, the LAST .kicad_pcb token on the line is the produced board.
    """
    last = None
    for line in manifest_txt.splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "check_" in line:
            continue
        toks = [t.strip("'\"") for t in line.split() if t.strip("'\"").endswith(".kicad_pcb")]
        if toks:
            last = toks[-1]
    return os.path.basename(last) if last else None


def _drc_count(text):
    m = re.search(r"FAILED \((\d+) violations?\)", text) or re.search(r"FOUND (\d+) DRC VIOLATION", text)
    return int(m.group(1)) if m else 0  # no match == PASSED / clean


def _conn_count(text):
    m = re.search(r"Connectivity issues \((\d+)\)", text)
    return int(m.group(1)) if m else 0


def _completion(text):
    """Routing completion from check_connected output: a net is complete if it is
    neither unrouted nor has a connectivity issue. Returns (total, incomplete, pct)
    or (None, None, None) if the net total can't be parsed."""
    tm = re.search(r"Checking (\d+) [\w ]*nets", text)
    if not tm:
        return None, None, None
    total = int(tm.group(1))
    um = re.search(r"Unrouted nets \((\d+)\)", text)
    im = re.search(r"Connectivity issues \((\d+)\)", text)
    incomplete = min(total, (int(um.group(1)) if um else 0) + (int(im.group(1)) if im else 0))
    pct = round(100.0 * (total - incomplete) / total, 1) if total else None
    return total, incomplete, pct


def _tool_of(argv):
    """Tool name (basename of the first .py arg) for per-tool timing aggregation."""
    for a in argv:
        if a.endswith(".py"):
            return os.path.basename(a)
    return argv[-1] if argv else "?"


def _diff_pair_stats(log_text):
    """Coupled diff-pair completion, from route_diff's JSON_SUMMARY lines in the
    replay log. route_diff classifies each pair as coupled (routed_diff_pairs),
    deferred-to-single-ended (single_ended_diff_pairs), or failed. Across multiple
    route_diff calls a pair's FINAL status wins (a retry can couple one that first
    failed). 'Completion' here = coupled / total pairs -- the rate of pairs actually
    routed as coupled diff pairs (single-ended fallback does NOT count). Returns
    None pct when the board has no diff pairs."""
    status = {}
    for m in re.finditer(r"JSON_SUMMARY:\s*(\{.*\})", log_text):
        try:
            d = json.loads(m.group(1))
        except Exception:
            continue
        if "routed_diff_pairs" not in d:   # skip non-diff summaries (e.g. bga_fanout)
            continue
        for p in d.get("routed_diff_pairs", []):       status[p] = "coupled"
        for p in d.get("single_ended_diff_pairs", []): status[p] = "single_ended"
        for p in d.get("failed_diff_pairs", []):       status[p] = "failed"
    total = len(status)
    coupled = sum(1 for v in status.values() if v == "coupled")
    return {"diff_pairs_total": total,
            "diff_pairs_coupled": coupled,
            "diff_pairs_single_ended": sum(1 for v in status.values() if v == "single_ended"),
            "diff_pairs_failed": sum(1 for v in status.values() if v == "failed"),
            "diff_coupled_pct": round(100.0 * coupled / total, 1) if total else None}


def manifest_baseline(txt, *search_dirs):
    """Resolve the pristine UNROUTED input board = first .kicad_pcb token of the
    first real command. Manifests reference it either by ABSOLUTE path or by a
    bare relative name (e.g. `board0.kicad_pcb`); a relative/missing token is
    resolved against the board's source/output dirs so the #405 symmetric
    baseline subtraction actually fires. Without this, a relative baseline token
    silently fails os.path.exists() and kicad_preexisting stays 0, phantom-
    counting pre-existing edge/hole conditions as router-introduced (openstint:
    6 pre-existing edge items surfaced as kicad_only). Returns the resolved path
    (or the raw token, which grade() treats as an absent baseline)."""
    tok = None
    for line in txt.splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        toks = [t.strip("'\"") for t in line.split()
                if t.strip("'\"").endswith(".kicad_pcb")]
        if toks:
            tok = toks[0]
            break
    if not tok:
        return None
    if os.path.exists(tok):
        return tok
    for d in search_dirs:
        cand = os.path.join(str(d), os.path.basename(tok))
        if os.path.exists(cand):
            return cand
    return tok


def _kicad_grade(pcb, clearance, baseline=None):
    """KiCad's own DRC verdict on the final board (#316): copper-class
    violation count + the two-sided diff vs check_drc, graded with the
    netclass clearance equalized to the routed clearance. Returns Nones when
    kicad-cli is unavailable so replay grading still works everywhere.

    This is a THIN adapter over kicad_drc_compare.compare_board_data -- the
    SHARED per-board grading core the `kicad_drc_compare` CLI also uses, so the
    two tools produce identical numbers by construction (they no longer
    reimplement baseline subtraction or matching). The core does symmetric
    baseline subtraction (#405) on BOTH engines' items and the board-edge
    anchor reconciliation.

    `baseline` = the UNROUTED input board (#326/#338): its items are pre-existing
    design conditions (e.g. edge-connector pads inside the board's own
    copper_edge rule) that no routing can fix -- subtracted from both engines so
    kicad_drc/kicad_only reflect ROUTER-introduced items; the subtracted count
    is reported as kicad_preexisting."""
    _none = {"kicad_drc": None, "kicad_only": None, "checkdrc_only": None,
             "kicad_connection_width": None, "checkdrc_reconciled": None,
             "checkdrc_preexisting": None}
    try:
        sys.path.insert(0, str(REPO / "tests" / "stress"))
        from kicad_drc_compare import KICAD_CLI, compare_board_data
        if not os.path.exists(KICAD_CLI):
            return _none
        data = compare_board_data(pcb, clearance=float(clearance), baseline=baseline)
        if data is None or "skip" in data:
            return _none
        return {"kicad_drc": data["kicad"], "kicad_preexisting": data["kicad_preexisting"],
                # baseline-subtracted + accepted-removed check_drc count (== the
                # kicad_drc_compare CLI's `check_drc=N`): the ROUTER-ATTRIBUTABLE
                # real DRC, used for drc_real below so pre-existing input copper
                # doesn't inflate the summary.
                "checkdrc_reconciled": data["check_drc"],
                "checkdrc_preexisting": data["checkdrc_preexisting"],
                "kicad_only": data["kicad_only"], "checkdrc_only": data["checkdrc_only"],
                "kicad_matched": data["matched"],
                "kicad_intentional_edge": data.get("kicad_intentional_edge", 0),
                "checkdrc_intentional_edge": data.get("checkdrc_intentional_edge", 0),
                # #406 min copper web (KiCad-only class; None = not graded).
                "kicad_connection_width": data.get("kicad_connection_width"),
                "connection_width_min": data.get("connection_width_min")}
    except Exception:
        return _none


def grade(pcb, clearance, baseline=None):
    # Grade at the board's OWN recorded floors when the sibling .kicad_pro
    # exists (check_drc auto-grades from it -- the Stage-C clearance ledger
    # writes the true minimum every step used, including legitimate fine-tap
    # escalations BELOW the manifest --clearance). Grading such copper at the
    # manifest clearance manufactures phantom violations: nrfmicro's plane
    # repair fine-tapped R5.2 at a recorded 0.127 floor and the 0.2 manifest
    # grade counted +13 "regressions" on a board whose auto-grade is clean
    # (#347 A/B). The manifest clearance stays as the fallback for finals
    # shipped without a .kicad_pro (the daisho gap, #217).
    pro = Path(pcb).with_suffix(".kicad_pro")
    drc_args = [sys.executable, "-X", "utf8", str(REPO / "check_drc.py"), pcb, "--quiet"]
    # Auto-grade only when the .kicad_pro actually RECORDS a clearance: a
    # stock/minimal project copied through the chain has none, and check_drc
    # would silently fall back to 0.2 -- manufacturing phantom sub-clearance
    # violations on a 0.1-routed board (the tigard class, again).
    _recorded = None
    if pro.exists():
        try:
            import json as _json
            sys.path.insert(0, str(REPO))
            from fix_kicad_drc_settings import project_copper_clearance
            with open(pro) as _f:
                _recorded = project_copper_clearance(_json.load(_f))
        except Exception:
            _recorded = None
    if _recorded is None:
        drc_args[-1:-1] = ["-c", clearance]
    drc = subprocess.run(drc_args, capture_output=True, text=True)
    # NOT --quiet: the "Checking N routed nets" total (needed for completion %)
    # only prints in non-quiet mode; the unrouted/connectivity-issue counts print
    # either way.
    conn = subprocess.run([sys.executable, "-X", "utf8", str(REPO / "check_connected.py"), pcb],
                          capture_output=True, text=True)
    ctext = conn.stdout + conn.stderr
    total, incomplete, pct = _completion(ctext)
    out = {"drc": _drc_count(drc.stdout + drc.stderr), "conn": _conn_count(ctext),
           "nets_total": total, "nets_incomplete": incomplete, "completion_pct": pct}
    out.update(_kicad_grade(pcb, clearance, baseline=baseline))
    # raw `drc` is the full check_drc count (NOT baseline-subtracted -- it counts
    # pre-existing input copper like edge-connector pads and chassis-ground pours).
    # `drc_real` is the ROUTER-ATTRIBUTABLE real DRC that compare()/the regression
    # gate grade on: prefer the shared grading core's reconciled check_drc count
    # (checkdrc_reconciled -- baseline-subtracted per #405 AND accepted-by-design
    # removed, identical to the kicad_drc_compare CLI's check_drc=N), so a track
    # routed into a pre-existing edge-exempt pad no longer looks like a regression
    # (orangecrab: raw drc 3 tracks-into-connector-pads -> reconciled 0). Falls back
    # to raw-minus-accepted-edge when kicad-cli (hence the core) is unavailable, and
    # to raw drc for pre-#408 summaries that lack the field.
    cie = out.get("checkdrc_intentional_edge") or 0
    out["drc_intentional_edge"] = cie
    recon = out.get("checkdrc_reconciled")
    if recon is not None:
        out["drc_real"] = recon
    elif out["drc"] is not None:
        out["drc_real"] = max(0, out["drc"] - cie)
    else:
        out["drc_real"] = None
    return out


# Extra "OLD:NEW" prefix rewrites appended to every board's replay (--remap on
# redo_stress_test is append-able). The reason this exists: manifests bake the
# TOOL paths absolutely, so a replay always runs whatever lives at the recorded
# repo path -- which means a wave cannot exercise a git WORKTREE without
# rewriting that prefix. Pass
#   --extra-remap /path/to/repo/:/path/to/repo/.claude/worktrees/<wt>/
# to A/B a branch without disturbing the main checkout.
EXTRA_REMAPS = []


def do_board(set_dir, out_dir, label, board):
    manifest = set_dir / board / "redo_commands.sh"
    src = str(set_dir / board)
    dst = str(out_dir / board)
    Path(dst).mkdir(parents=True, exist_ok=True)
    txt = manifest.read_text()
    clr = route_clearance(txt)
    timings_path = f"{dst}/timings.json"
    with open(f"{dst}/_replay.log", "w") as log:
        # --workdir dst confines every command to the wave dir; combined with the
        # --remap it makes redo_stress_test's clobber guard authoritative (a manifest
        # whose baked paths don't match `src` aborts loudly instead of overwriting the
        # original run dir -- the copied-set footgun).
        _extra = []
        for _r in EXTRA_REMAPS:
            _extra += ["--remap", _r]
        rc = subprocess.run([sys.executable, str(REPO / "tests/stress/redo_stress_test.py"),
                             str(manifest), "--remap", f"{src}:{dst}"] + _extra
                            + ["--workdir", dst,
                               "--skip-checks", "--continue-on-error",
                               "--timings-out", timings_path],
                            stdout=log, stderr=subprocess.STDOUT).returncode
    # Per-step wall-clock (for A/B timing comparison): keep the raw per-command
    # list and a per-tool sum (route.py / route_planes.py / ... -- where the
    # vectorization speedups land), plus the total.
    steps, time_by_tool, peak_by_tool, total_s, peak_board = [], {}, {}, 0.0, 0.0
    peak_fp_by_tool, peak_fp_board = {}, 0.0
    if os.path.exists(timings_path):
        for c in json.loads(Path(timings_path).read_text()).get("commands", []):
            tool = _tool_of(c.get("argv", []))
            sec = c.get("seconds", 0.0)
            pk = c.get("peak_rss_mb", 0.0)
            # peak_footprint_mb (darwin only): the authoritative memory number
            # RSS under-reports -- mimalloc-retained + IOAccelerator-tagged pages
            # (issue #419). Absent on non-darwin timings; treated as 0 then.
            fp = c.get("peak_footprint_mb", 0.0) or 0.0
            step = {"tool": tool, "seconds": sec, "peak_rss_mb": pk, "rc": c.get("returncode")}
            if fp:
                step["peak_footprint_mb"] = fp
            steps.append(step)
            time_by_tool[tool] = round(time_by_tool.get(tool, 0.0) + sec, 3)
            peak_by_tool[tool] = round(max(peak_by_tool.get(tool, 0.0), pk), 1)  # max, not sum
            if fp:
                peak_fp_by_tool[tool] = round(max(peak_fp_by_tool.get(tool, 0.0), fp), 1)
            total_s += sec
            peak_board = max(peak_board, pk)
            peak_fp_board = max(peak_fp_board, fp)
    # Coupled diff-pair completion is parsed from route_diff's JSON_SUMMARY in the
    # replay log (captured above), so it reflects what actually coupled-routed.
    log_path = f"{dst}/_replay.log"
    log_text = Path(log_path).read_text(errors="replace") if os.path.exists(log_path) else ""
    dp = _diff_pair_stats(log_text)
    fname = final_output_name(txt)
    final = os.path.join(dst, fname) if fname else None
    done = bool(final) and os.path.exists(final)
    res = {"board": board, "clearance": clr, "replay_rc": rc,
           "final": fname if done else None, "chain_complete": done,
           "drc": None, "conn": None, "nets_total": None, "nets_incomplete": None,
           "completion_pct": None,
           "total_seconds": round(total_s, 3), "peak_rss_mb": round(peak_board, 1),
           "time_by_tool": time_by_tool, "peak_by_tool": peak_by_tool, "steps": steps,
           **dp}
    # Footprint (darwin) is the memory number that actually caught issue #419;
    # keep it additive so non-darwin records are unchanged.
    if peak_fp_board:
        res["peak_footprint_mb"] = round(peak_fp_board, 1)
        res["peak_footprint_by_tool"] = peak_fp_by_tool
    if done:
        # Unrouted-input baseline (#326/#338): the manifest's first command's
        # first .kicad_pcb argument is the pristine input board; its kicad
        # items are pre-existing design conditions subtracted from the
        # final's kicad grade (kicad_preexisting) so kicad_drc reflects
        # router-introduced items. Resolve a relative token against the board's
        # dest/src dirs (board0.kicad_pcb lives there after the remap).
        baseline = manifest_baseline(txt, dst, src)
        res.update(grade(final, clr, baseline=baseline))
    dps = f"{res['diff_pairs_coupled']}/{res['diff_pairs_total']}" if res['diff_pairs_total'] else "-"
    fp_note = f" fp={res['peak_footprint_mb']}MB" if res.get("peak_footprint_mb") else ""
    print(f"[{label}] {board}: chain={'ok' if done else 'BROKEN'} "
          f"drc={res['drc']} kdrc={res.get('kicad_drc')} cw={res.get('kicad_connection_width')} "
          f"conn={res['conn']} compl={res['completion_pct']}% "
          f"dpair={dps} t={res['total_seconds']}s peak={res['peak_rss_mb']}MB{fp_note} final={res['final']}", flush=True)
    return res


def run_wave(set_dir, out_dir, label, jobs):
    # Skip dot-prefixed dirs: those are headless-worker artifacts (a paused /
    # NORESULT retry copy of a real board, e.g. `.framework_dock_noresult_...`),
    # not corpus boards -- the clean board dir is present separately (see memory
    # stress-headless-worker-noresult).
    boards = sorted(d.name for d in set_dir.iterdir()
                    if not d.name.startswith(".") and (d / "redo_commands.sh").exists())
    out_dir.mkdir(parents=True, exist_ok=True)
    ver = write_git_version(out_dir, REPO, label=label)  # provenance: which code produced this wave
    print(f"[{label}] code under test: {format_version(ver)}  (commit {ver.get('commit')})")
    print(f"[{label}] replaying {len(boards)} boards from {set_dir} -> {out_dir} ({jobs} parallel)")
    results = []
    summary = out_dir / "summary.json"

    def _flush():
        # #383: stream partial results to disk as boards finish, so a mid-run
        # death still leaves the completed boards' grades on disk (the wave
        # driver used to write summary.json only at the very end).
        summary.write_text(json.dumps(sorted(results, key=lambda r: r["board"]), indent=2))

    with concurrent.futures.ThreadPoolExecutor(max_workers=jobs) as ex:
        fut_board = {ex.submit(do_board, set_dir, out_dir, label, b): b for b in boards}
        for f in concurrent.futures.as_completed(fut_board):  # report as boards finish
            b = fut_board[f]
            try:
                results.append(f.result())
            except BaseException as e:  # noqa: BLE001 -- one board must never kill the wave
                # #383: a worker raising SystemExit/KeyboardInterrupt (a bare
                # sys.exit() deep in a grading helper) used to propagate through
                # f.result() and out of main(), leaving NO summary and no error
                # line. Degrade that board to a NORESULT row and keep going.
                print(f"[{label}] {b}: NORESULT ({type(e).__name__}: {e})", flush=True)
                results.append({"board": b, "clearance": None, "replay_rc": None,
                                "final": None, "chain_complete": False,
                                "drc": None, "conn": None, "nets_total": None,
                                "nets_incomplete": None, "completion_pct": None,
                                "error": f"{type(e).__name__}: {e}"})
            _flush()
    results.sort(key=lambda r: r["board"])
    _flush()
    complete = sum(1 for r in results if r["chain_complete"])
    print(f"[{label}] wrote {summary}: {complete}/{len(results)} chains complete")
    return results


def regrade(out_dir, set_dir):
    """Re-grade an existing wave's final boards (no re-routing) and rewrite its
    summary.json -- e.g. after a grading fix like the route_clearance change, or
    to reuse a prior wave as a baseline."""
    out_dir = Path(out_dir); set_dir = Path(set_dir)
    results = []
    for bdir in sorted(p for p in out_dir.iterdir() if p.is_dir()):
        b = bdir.name
        man = set_dir / b / "redo_commands.sh"
        if not man.exists():
            continue
        txt = man.read_text(); clr = route_clearance(txt)
        fname = final_output_name(txt)
        final = bdir / fname if fname else None
        done = bool(final) and final.exists()
        lp = bdir / "_replay.log"
        log_text = lp.read_text(errors="replace") if lp.exists() else ""
        dp = _diff_pair_stats(log_text)
        res = {"board": b, "clearance": clr, "replay_rc": 0,
               "final": fname if done else None, "chain_complete": done,
               "drc": None, "conn": None, "nets_total": None, "nets_incomplete": None,
               "completion_pct": None, **dp}  # regrade re-runs no commands, so no timing
        if done:
            # Resolve the unrouted-input baseline against the wave board dir and
            # the manifest's set dir (a relative board0.kicad_pcb token lives in
            # both) so #405 symmetric subtraction fires (see manifest_baseline).
            baseline = manifest_baseline(txt, bdir, set_dir / b)
            res.update(grade(str(final), clr, baseline=baseline))
        print(f"[regrade] {b}: chain={'ok' if done else 'BROKEN'} drc={res['drc']} "
              f"conn={res['conn']} compl={res['completion_pct']}%")
        results.append(res)
    (out_dir / "summary.json").write_text(json.dumps(results, indent=2))
    print(f"[regrade] rewrote {out_dir/'summary.json'}")
    return results


def _fmt(v):
    return "-" if v is None else str(v)


def compare(old_json, new_json):
    old = {r["board"]: r for r in json.loads(Path(old_json).read_text())}
    new = {r["board"]: r for r in json.loads(Path(new_json).read_text())}
    ov, nv = load_git_version(old_json), load_git_version(new_json)
    if ov or nv:
        print(f"code: old = {format_version(ov)}   new = {format_version(nv)}")
    boards = sorted(set(old) | set(new))
    # Connectivity is graded on TOTAL INCOMPLETE nets (unrouted + connectivity-issue
    # nets), NOT the "conn" (connectivity-issue) count alone: a net that loses its
    # copper entirely leaves the conn bucket for the unrouted bucket, so conn can
    # DROP while the board got worse. incomplete = nets_incomplete (falls back to
    # conn for pre-#-schema summaries that lack it).
    def _incompl(r):
        ni = r.get("nets_incomplete")
        return ni if ni is not None else r.get("conn")
    # #408: grade on drc_real (raw check_drc minus accepted-by-design edge items:
    # copper the router had to run into the edge band to reach an edge connector /
    # edge-mounted pad). Falls back to raw drc for pre-#408 summaries that lack it.
    def _drc(r):
        v = r.get("drc_real")
        return v if v is not None else r.get("drc")
    # #406 min copper web (kicad-cli class, graded when a floor is recorded).
    # None (not graded / pre-#406 summary / no kicad-cli) contributes no delta.
    def _cw(r):
        return r.get("kicad_connection_width")
    print(f"{'board':14} {'drc o->n':>11} {'connw o->n':>12} {'incompl o->n':>13} {'compl% o->n':>13} "
          f"{'dpair o->n':>13} {'time(s) o->n':>16} {'peakMB o->n':>15}  note")
    print("-" * 140)
    drc_delta = incompl_delta = dpair_delta = cw_delta = 0
    t_old = t_new = 0.0
    time_old, time_new = {}, {}   # per-tool wall-clock summed across boards (speedup view)
    pk_old, pk_new = {}, {}       # per-tool peak RSS = max across boards (memory view)
    for b in boards:
        o, n = old.get(b), new.get(b)
        oc = o and o["chain_complete"]
        nc = n and n["chain_complete"]
        if not (oc and nc):
            print(f"{b:14} {'-':>11} {'-':>12} {'-':>13} {'-':>13} {'-':>13} {'-':>16} {'-':>15}  chain incomplete "
                  f"(old={'ok' if oc else 'broken'}, new={'ok' if nc else 'broken'}) -- excluded")
            continue
        oi, ni = _incompl(o), _incompl(n)
        od, nd = _drc(o), _drc(n)
        dd = (nd - od) if (od is not None and nd is not None) else 0
        cd = (ni - oi) if (oi is not None and ni is not None) else 0  # incomplete-net delta
        ocw, ncw = _cw(o), _cw(n)
        cwd = (ncw - ocw) if (ocw is not None and ncw is not None) else 0  # web delta (#406)
        drc_delta += dd; incompl_delta += cd; cw_delta += cwd
        # coupled diff-pair count (fewer coupled = quality regression)
        ocp, ncp = o.get("diff_pairs_coupled"), n.get("diff_pairs_coupled")
        odt, ndt = o.get("diff_pairs_total"), n.get("diff_pairs_total")
        dpd = (ncp - ocp) if (ocp is not None and ncp is not None) else 0
        dpair_delta += dpd
        dp_o = f"{ocp}/{odt}" if odt else "-"
        dp_n = f"{ncp}/{ndt}" if ndt else "-"
        to, tn = o.get("total_seconds"), n.get("total_seconds")
        if to is not None and tn is not None:
            t_old += to; t_new += tn
        for src, dst in ((o.get("time_by_tool", {}), time_old), (n.get("time_by_tool", {}), time_new)):
            for k, v in src.items():
                dst[k] = round(dst.get(k, 0.0) + v, 3)
        for src, dst in ((o.get("peak_by_tool", {}), pk_old), (n.get("peak_by_tool", {}), pk_new)):
            for k, v in src.items():
                dst[k] = round(max(dst.get(k, 0.0), v), 1)
        op, npc = o.get("completion_pct"), n.get("completion_pct")
        po, pn = o.get("peak_rss_mb"), n.get("peak_rss_mb")
        # Footprint (darwin) -- the memory number that actually catches #419-class
        # regressions RSS misses. Appended as an extra column only when present.
        pfo, pfn = o.get("peak_footprint_mb"), n.get("peak_footprint_mb")
        fp_col = f"  fp {_fmt(pfo):>6} -> {_fmt(pfn):<6}" if (pfo or pfn) else ""
        flag = ""
        if dd > 0 or cd > 0 or dpd < 0 or cwd > 0:    flag = "  <-- REGRESSION"
        elif dd < 0 or cd < 0 or dpd > 0 or cwd < 0:  flag = "  improved"
        # #408: annotate when accepted-by-design edge items were subtracted, so a
        # drop from raw drc to drc_real is visible rather than looking like noise.
        nie = n.get("drc_intentional_edge") or 0
        if nie:
            flag += f"  (#408 -{nie} edge accepted)"
        speed = f"  ({to/tn:.2f}x)" if (to and tn) else ""
        print(f"{b:14} {_fmt(od):>4} -> {_fmt(nd):<4} {_fmt(ocw):>4} -> {_fmt(ncw):<4} "
              f"{_fmt(oi):>5} -> {_fmt(ni):<5} "
              f"{_fmt(op):>5} -> {_fmt(npc):<5} {dp_o:>5} -> {dp_n:<5} "
              f"{_fmt(to):>6} -> {_fmt(tn):<6}{speed:>9} {_fmt(po):>6} -> {_fmt(pn):<6}{fp_col}{flag}")
    print("-" * 140)
    verdict = ("REGRESSION" if (drc_delta > 0 or incompl_delta > 0
                                or dpair_delta < 0 or cw_delta > 0) else "no regression")
    print(f"net delta: drc {drc_delta:+d}, connection_width {cw_delta:+d} (#406), "
          f"incomplete nets {incompl_delta:+d} "
          f"(unrouted + connectivity-issue), coupled diff-pairs {dpair_delta:+d}"
          f"  ==>  {verdict}")
    if t_old and t_new:
        print(f"total replay wall-clock: {t_old:.1f}s -> {t_new:.1f}s  ({t_old/t_new:.2f}x)")
        print("\nper-tool: wall-clock (summed) and peak RSS (max) over boards complete in both:")
        print(f"  {'tool':28} {'t_old(s)':>9} {'t_new(s)':>9} {'speedup':>8}   "
              f"{'peak_old':>9} {'peak_new':>9}")
        for tool in sorted(set(time_old) | set(time_new), key=lambda k: -time_new.get(k, 0)):
            ot, nt = time_old.get(tool, 0.0), time_new.get(tool, 0.0)
            sp = f"{ot/nt:.2f}x" if nt else "-"
            print(f"  {tool:28} {ot:>9.1f} {nt:>9.1f} {sp:>8}   "
                  f"{pk_old.get(tool, 0):>8.0f}MB {pk_new.get(tool, 0):>8.0f}MB")
    else:
        print("(timing/peak not available in one/both summaries -- re-run waves with the "
              "current ab_replay_grade to capture per-step timing + peak memory)")
    return (drc_delta <= 0 and incompl_delta <= 0 and dpair_delta >= 0
            and cw_delta <= 0)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--set", help="Set runs dir, e.g. ~/Documents/kicad_stress_test/runs_set3")
    ap.add_argument("--out", help="Wave output dir (per code version)")
    ap.add_argument("--label", default="wave", help="Label for log lines (e.g. old / new)")
    ap.add_argument("--jobs", type=int, default=4, help="Boards in parallel (default 4)")
    ap.add_argument("--compare", nargs=2, metavar=("OLD.json", "NEW.json"),
                    help="Compare two wave summaries and print a regression table")
    ap.add_argument("--regrade", metavar="WAVE_DIR",
                    help="Re-grade an existing wave's finals (no re-routing) and rewrite its summary.json")
    ap.add_argument("--extra-remap", action="append", default=[], metavar="OLD:NEW",
                    help="Extra path-prefix rewrite for every replayed command. Manifests "
                         "bake TOOL paths absolutely, so use this to point a wave at a git "
                         "worktree: --extra-remap /repo/:/repo/.claude/worktrees/wt/")
    args = ap.parse_args()
    for _r in args.extra_remap:
        if ":" not in _r:
            ap.error(f"--extra-remap needs OLD:NEW, got {_r!r}")
    EXTRA_REMAPS[:] = args.extra_remap

    if args.compare:
        ok = compare(*args.compare)
        return 0 if ok else 1
    if args.regrade:
        if not args.set:
            ap.error("--regrade needs --set (for per-board manifests)")
        regrade(args.regrade, Path(args.set).expanduser())
        return 0
    if not args.set or not args.out:
        ap.error("--set and --out are required (or use --compare/--regrade)")
    run_wave(Path(args.set).expanduser(), Path(args.out).expanduser(), args.label, args.jobs)
    return 0


if __name__ == "__main__":
    sys.exit(main())
