"""
KiCad Routing Tools - wxPython GUI for SWIG plugin

Provides a wx-based dialog for routing configuration.
"""

import os
import re
import sys
import time
import wx
import threading

# Add parent directory to path
PLUGIN_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(PLUGIN_DIR)
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

import routing_defaults as defaults
from kicad_parser import POSITION_DECIMALS
from kicad_parser import mm_to_iu

# What a failed startup check can look like coming out of `import route`.
# SystemExit is the historical form; StartupCheckError is what the checks raise
# now that they no longer kill an importing process (#457 item 3). Tolerant of an
# old startup_checks with no such class, so a stale checkout still imports.
try:
    from startup_checks import StartupCheckError as _StartupCheckError
    _STARTUP_FAILURES = (SystemExit, _StartupCheckError)
except ImportError:  # pragma: no cover - stale checkout
    _STARTUP_FAILURES = (SystemExit,)


def _via_width(via):
    """KiCad 9/10 padstack vias can refuse layerless GetWidth() ('result
    with an error set', seen on vias ADDED in-session then re-synced);
    GetFrontWidth() is the stable outer-annulus accessor."""
    try:
        return via.GetWidth()
    except Exception:
        return via.GetFrontWidth()

from .fanout_gui import NetSelectionPanel
from .gui_utils import StdoutRedirector
from .settings_persistence import get_dialog_settings, restore_dialog_settings


def _build_layer_mappings():
    """Build layer name <-> ID mappings using pcbnew.

    Returns:
        tuple: (name_to_id dict, id_to_name dict)
    """
    import pcbnew
    name_to_id = {'F.Cu': pcbnew.F_Cu, 'B.Cu': pcbnew.B_Cu}
    id_to_name = {pcbnew.F_Cu: 'F.Cu', pcbnew.B_Cu: 'B.Cu'}
    for i in range(1, 31):
        layer_id = getattr(pcbnew, f'In{i}_Cu', None)
        if layer_id is not None:
            name_to_id[f'In{i}.Cu'] = layer_id
            id_to_name[layer_id] = f'In{i}.Cu'
    return name_to_id, id_to_name


def _split_net_list(text):
    """Split a whitespace-separated net-name field, honouring quotes.

    KiCad net names routinely contain SPACES -- any net declared on a sheet with
    a space in its name, e.g. '/Management Interface/VDDA'. The power-nets field
    is whitespace-separated, so a bare split() tore that one net into
    '/Management' and 'Interface/VDDA': 6 names against 5 widths, and
    identify_power_nets raises "patterns (6) and widths (5) must have same
    length". In the GUI that exception killed the routing worker thread after
    the engine had printed its header; the tab re-enabled its button, so the
    AI-tab plan executor recorded the step as FINISHED and moved on. eth_tap
    step 11 silently routed nothing at all -- 2270 segments of signal routing
    lost with no error shown (#493 follow-up).

    shlex.split accepts the plain space-separated form unchanged and additionally
    understands quotes, so a name with spaces survives when written by
    ai_plan (which now quotes) or typed by a user.
    """
    import shlex
    text = (text or '').strip()
    if not text:
        return []
    try:
        return shlex.split(text)
    except ValueError:
        return text.split()   # unbalanced quotes: fall back, never crash routing


def _nm_to_mm(nm):
    """KiCad's integer nanometres -> mm, without the one-ULP multiply error.

    `nm * 1e-6` is NOT the same as `nm / 1e6`: 1e-6 has no exact binary
    representation, so the multiply lands one ULP below the true value for some
    magnitudes (200000 -> 0.19999999999999998, 450000 -> 0.44999999999999996).
    Those values were handed to the routing engines as clearance / via size, so
    the GUI routed against constraints a hair different from the CLI's (#493).
    """
    return nm / 1e6


def _get_netclass_parameters(class_name):
    """Get routing parameters for a specific net class from pcbnew.

    Args:
        class_name: Name of the net class (e.g., 'Default', 'Wide')

    Returns:
        dict with keys: track_width, clearance, via_size, via_drill,
        diff_pair_width, diff_pair_gap (all in mm)
        Returns None if net class not found or error occurs.
    """
    try:
        import pcbnew
        board = pcbnew.GetBoard()
        if board is None:
            return None

        ds = board.GetDesignSettings()
        net_settings = ds.m_NetSettings

        # Get the net class by name
        netclass = net_settings.GetNetClassByName(class_name)
        if not netclass:
            # Try getting default
            netclass = net_settings.GetDefaultNetclass()
        if not netclass:
            return None

        # KiCad stores values in nanometers, convert to mm.
        # DIVIDE by 1e6; never multiply by 1e-6 (#493 item 3). 1e-6 is not
        # exactly representable, so `nm * 1e-6` lands one ULP BELOW the true
        # value for some magnitudes -- 200000 -> 0.19999999999999998,
        # 450000 -> 0.44999999999999996 (0.3/0.25/0.127/0.09 happen to be
        # unaffected, which is why this only bit boards whose netclass used
        # 0.2/0.45). Those epsilons reached the engine as the routing clearance
        # and via size, so the GUI routed and repaired against constraints a hair
        # off the CLI's and produced different copper. `nm / 1e6` is correctly
        # rounded and reproduces the literal exactly.
        result = {
            'track_width': _nm_to_mm(netclass.GetTrackWidth()),
            'clearance': _nm_to_mm(netclass.GetClearance()),
            'via_size': _nm_to_mm(netclass.GetViaDiameter()),
            'via_drill': _nm_to_mm(netclass.GetViaDrill()),
        }

        # Add differential pair parameters if available
        if hasattr(netclass, 'GetDiffPairWidth'):
            result['diff_pair_width'] = _nm_to_mm(netclass.GetDiffPairWidth())
        if hasattr(netclass, 'GetDiffPairGap'):
            result['diff_pair_gap'] = _nm_to_mm(netclass.GetDiffPairGap())

        return result
    except Exception:
        return None


def _get_board_minimum_constraints():
    """Get board-level minimum constraints from pcbnew.

    These are the hard floors from Board Setup → Design Rules → Constraints.

    Returns:
        dict with min_track_width, min_clearance, min_via_size, min_via_drill,
        min_hole_to_hole, min_copper_edge_clearance (in mm)
        or None if board not available
    """
    try:
        import pcbnew
        board = pcbnew.GetBoard()
        if board is None:
            return None

        ds = board.GetDesignSettings()

        result = {
            'min_track_width': _nm_to_mm(ds.m_TrackMinWidth),
            'min_clearance': _nm_to_mm(ds.m_MinClearance),
            'min_via_size': _nm_to_mm(ds.m_ViasMinSize),
            'min_via_drill': _nm_to_mm(ds.m_MinThroughDrill),
        }

        # Try to get hole-to-hole clearance (may not be available in all versions)
        if hasattr(ds, 'm_HoleToHoleMin'):
            result['min_hole_to_hole'] = _nm_to_mm(ds.m_HoleToHoleMin)

        # Try to get copper-to-edge clearance
        if hasattr(ds, 'm_CopperEdgeClearance'):
            result['min_copper_edge_clearance'] = _nm_to_mm(ds.m_CopperEdgeClearance)

        return result
    except Exception:
        return None


class RoutingDialog(wx.Dialog):
    """Main dialog for configuring and running the router."""

    def __init__(self, parent, pcb_data, board_filename, saved_settings=None,
                 preselected_nets=None):
        super().__init__(
            parent,
            title="KiCad Routing Tools",
            size=(800, 800),
            style=wx.DEFAULT_DIALOG_STYLE | wx.RESIZE_BORDER
        )

        # Get saved transparency or use default
        self._initial_transparency = 240
        if saved_settings and 'window_transparency' in saved_settings:
            self._initial_transparency = saved_settings['window_transparency']

        # Set window transparency (0=fully transparent, 255=opaque)
        self.SetTransparent(self._initial_transparency)

        # Configure tooltip timing (in milliseconds)
        wx.ToolTip.SetDelay(250)       # Delay before showing
        wx.ToolTip.SetAutoPop(10000)   # How long tooltip stays visible
        wx.ToolTip.SetReshow(50)       # Delay when moving between controls

        self.pcb_data = pcb_data
        self.board_filename = board_filename
        self._cancel_requested = False
        self._routing_thread = None
        self._connectivity_cache = {}  # Cache: net_id -> is_connected
        self._saved_settings = saved_settings  # Settings to restore after init
        # Nets the user selected in the PCB editor before opening the plugin.
        # These pre-check the matching nets for routing (GitHub issue #6).
        self._preselected_nets = set(preselected_nets) if preselected_nets else set()
        self._last_notebook = None  # Track netclass notebook for cleanup
        self._initial_load = True  # Skip board sync on first refresh (data is already current)
        # Per-session "no" responses to the "make a plane first?" suggestion
        # in _on_route, keyed by (net_name, layer) so a user who declines for
        # GND isn't asked again, but is still asked about VCC.
        self._plane_prompt_dismissed = set()

        self._create_ui()
        # Routing movie recorder (#506). Created after the UI because it reads
        # the Advanced tab's "Make routing movie" checkbox; inert while that is
        # unchecked (the default).
        from .movie_recorder import MovieRecorder
        self.movie_recorder = MovieRecorder(self)
        self.Bind(wx.EVT_WINDOW_DESTROY, self._on_dialog_destroy)
        self._load_nets_immediate()  # Load net names only (fast)
        self.Centre()

        # Defer sync and connectivity check until after dialog is shown
        wx.CallAfter(self._deferred_init)

    def _on_make_movie_toggle(self, event):
        """Ticking "Make routing movie" starts recording from the board as it
        stands now, so the next step's movie shows only what THAT step adds."""
        self.movie_recorder.on_toggle(event)

    def _on_dialog_destroy(self, event):
        if event.GetEventObject() is self:
            try:
                self.movie_recorder.cleanup()
            except Exception:
                pass
        event.Skip()

    def _sync_pcb_data_from_board(self):
        """Sync pcb_data.segments and pcb_data.vias from pcbnew's in-memory board.

        This is necessary because pcb_data is parsed from the file on disk,
        but tracks added during previous routing sessions only exist in pcbnew's
        memory until the file is saved.
        """
        # Clear connectivity cache since board state is changing
        self._connectivity_cache = {}

        try:
            import pcbnew
            from kicad_parser import Segment, Via

            board = pcbnew.GetBoard()
            if board is None:
                return
        except Exception as e:
            print(f"Warning: Could not sync from board: {e}")
            return

        try:
            # Get layer mappings
            _, id_to_name = _build_layer_mappings()

            def get_layer_name(layer_id):
                return id_to_name.get(layer_id, 'F.Cu')

            # Collect all segments from board
            new_segments = []
            for track in board.GetTracks():
                if track.GetClass() == "PCB_TRACK":
                    seg = Segment(
                        start_x=pcbnew.ToMM(track.GetStart().x),
                        start_y=pcbnew.ToMM(track.GetStart().y),
                        end_x=pcbnew.ToMM(track.GetEnd().x),
                        end_y=pcbnew.ToMM(track.GetEnd().y),
                        width=pcbnew.ToMM(track.GetWidth()),
                        layer=get_layer_name(track.GetLayer()),
                        net_id=track.GetNetCode(),
                    )
                    new_segments.append(seg)

            # Collect all vias from board
            new_vias = []
            for track in board.GetTracks():
                if track.GetClass() == "PCB_VIA":
                    via = track
                    top_layer = via.TopLayer()
                    bot_layer = via.BottomLayer()
                    v = Via(
                        x=pcbnew.ToMM(via.GetPosition().x),
                        y=pcbnew.ToMM(via.GetPosition().y),
                        size=pcbnew.ToMM(_via_width(via)),
                        drill=pcbnew.ToMM(via.GetDrill()),
                        layers=[get_layer_name(top_layer), get_layer_name(bot_layer)],
                        net_id=via.GetNetCode(),
                    )
                    new_vias.append(v)

            # Replace pcb_data segments and vias with what's in pcbnew
            self.pcb_data.segments = new_segments
            self.pcb_data.vias = new_vias

            # Also sync zones - the connectivity check uses pcb_data.zones to
            # determine which nets are connected via copper pours. Without
            # this, a freshly-created plane is invisible to "hide connected"
            # until the GUI reopens.
            try:
                from kicad_parser import _extract_zones_from_pcbnew
                self.pcb_data.zones = _extract_zones_from_pcbnew(
                    board, pcbnew.ToMM, get_layer_name)
            except Exception as e:
                print(f"Warning: Error syncing zones from board: {e}")

            # Sync FOOTPRINT and PAD positions too (#362) so a later route step
            # sees caps where optimize_caps actually moved them, not their
            # load-time positions. See gui_utils.sync_footprint_positions_from_board.
            try:
                from .gui_utils import sync_footprint_positions_from_board
                sync_footprint_positions_from_board(board, self.pcb_data)
            except Exception as e:
                print(f"Warning: Error syncing footprint positions from board: {e}")
        except Exception as e:
            print(f"Warning: Error syncing tracks from board: {e}")

    def _create_ui(self):
        """Create the dialog UI with tabs for Configure, Advanced, and Log."""
        main_panel = wx.Panel(self)
        main_sizer = wx.BoxSizer(wx.VERTICAL)

        # Create notebook for tabs
        self.notebook = wx.Notebook(main_panel)

        # Tab 1: Basic parameters
        config_panel = self._create_config_tab()
        self.notebook.AddPage(config_panel, "Basic")

        # Tab 2: Advanced (swappable nets + advanced parameters + options)
        advanced_panel = self._create_advanced_tab()
        self.notebook.AddPage(advanced_panel, "Advanced")

        # Tab 3: Differential
        differential_panel = self._create_differential_tab()
        self.notebook.AddPage(differential_panel, "Differential")

        # Tab 4: Fanout
        self.fanout_tab = self._create_fanout_tab()
        self.notebook.AddPage(self.fanout_tab, "Fanout")

        # Tab 5: Planes
        self.planes_tab = self._create_planes_tab()
        self.notebook.AddPage(self.planes_tab, "Planes")

        # Tab 6: AI (AI skills, issue #40)
        self.ai_tab = self._create_ai_tab()
        self.notebook.AddPage(self.ai_tab, "AI")

        # Tab 7: Log
        log_panel = self._create_log_tab()
        self.notebook.AddPage(log_panel, "Log")

        # Tab 8: About
        self.about_tab = self._create_about_tab()
        self.notebook.AddPage(self.about_tab, "About")

        # Add notebook to main sizer
        main_sizer.Add(self.notebook, 1, wx.EXPAND | wx.ALL, 5)

        # Bind tab change to validate settings when switching tabs
        self.notebook.Bind(wx.EVT_NOTEBOOK_PAGE_CHANGED, self._on_main_tab_changed)

        # Status bar at bottom
        self.status_bar = wx.StaticText(main_panel, label="")
        main_sizer.Add(self.status_bar, 0, wx.EXPAND | wx.ALL, 5)

        main_panel.SetSizer(main_sizer)

    def _create_about_tab(self):
        """Create the About tab."""
        from .about_tab import AboutTab
        return AboutTab(
            self.notebook,
            on_reset_settings=self._reset_all_settings,
            on_transparency_changed=self._on_transparency_changed,
            initial_transparency=self._initial_transparency,
            on_validate_pcb_data=self._validate_pcb_data
        )

    def _validate_pcb_data(self):
        """Compare pcbnew-extracted PCBData against file-parsed PCBData."""
        from kicad_parser import parse_kicad_pcb, compare_pcb_data

        if not self.board_filename:
            self._append_log("Validation: Board has no filename (not saved yet). "
                             "Save the board first to enable file-based validation.\n")
            return

        self._append_log("=== PCB Data Validation ===\n")
        self._append_log(f"Comparing pcbnew data vs file parse of: {self.board_filename}\n")

        try:
            file_data = parse_kicad_pcb(self.board_filename)
        except Exception as e:
            self._append_log(f"Error parsing file: {e}\n")
            return

        diffs = compare_pcb_data(self.pcb_data, file_data)

        if not diffs:
            self._append_log("PASS: No differences found! pcbnew data matches file parse.\n")
        else:
            self._append_log(f"Found {len(diffs)} difference(s):\n")
            for diff in diffs:
                self._append_log(f"  - {diff}\n")

        self._append_log("=== Validation Complete ===\n\n")

        # Switch to log tab to show results
        for i in range(self.notebook.GetPageCount()):
            if self.notebook.GetPageText(i) == "Log":
                self.notebook.SetSelection(i)
                break

    def _on_transparency_changed(self, value):
        """Handle transparency slider change from About tab."""
        self.SetTransparent(value)

    def _create_config_tab(self):
        """Create the Basic tab with basic routing parameters and options."""
        panel = wx.Panel(self.notebook)
        config_sizer = wx.BoxSizer(wx.VERTICAL)
        h_sizer = wx.BoxSizer(wx.HORIZONTAL)

        # Left side: Net selection (1:1 ratio with right side)
        net_box = wx.StaticBox(panel, label="Net Selection")
        net_sizer = wx.StaticBoxSizer(net_box, wx.VERTICAL)

        self.net_panel = NetSelectionPanel(
            panel, self.pcb_data,
            instructions="Select nets to route...",
            hide_label="Hide connected",
            hide_tooltip="Hide nets that are already fully connected",
            show_hide_checkbox=True,
            show_component_filter=True,
            show_component_dropdown=True,
            min_pads_for_dropdown=3,
            show_hide_differential=True,
            hide_differential_default=False
        )
        self.net_panel.set_selection_changed_callback(self._update_status_bar)
        self.net_panel.set_tabbed_view_changed_callback(self._on_tabbed_view_changed)
        net_sizer.Add(self.net_panel, 1, wx.EXPAND)

        h_sizer.Add(net_sizer, 1, wx.EXPAND | wx.ALL, 5)

        # Right side: Basic parameters, layers, options, progress, buttons (2:1:2 ratio)
        right_sizer = wx.BoxSizer(wx.VERTICAL)
        right_sizer.Add(self._create_parameters_panel(panel), 2, wx.EXPAND | wx.BOTTOM, 5)
        right_sizer.Add(self._create_layers_panel(panel), 1, wx.EXPAND | wx.BOTTOM, 5)
        right_sizer.Add(self._create_basic_options_panel(panel), 2, wx.EXPAND | wx.BOTTOM, 5)
        right_sizer.Add(self._create_progress_panel(panel), 0, wx.EXPAND | wx.BOTTOM, 5)
        right_sizer.Add(self._create_buttons_panel(panel), 0, wx.EXPAND)
        h_sizer.Add(right_sizer, 1, wx.EXPAND | wx.ALL, 5)

        config_sizer.Add(h_sizer, 1, wx.EXPAND | wx.ALL, 5)
        panel.SetSizer(config_sizer)
        return panel

    def _create_parameters_panel(self, panel):
        """Create the parameters panel with basic settings only."""
        param_box = wx.StaticBox(panel, label="Parameters")
        param_box_sizer = wx.StaticBoxSizer(param_box, wx.VERTICAL)

        # Obey design rule constraints checkbox
        self.obey_drc_check = wx.CheckBox(panel, label="Obey design rule constraints")
        self.obey_drc_check.SetValue(True)
        self.obey_drc_check.SetToolTip(
            "Enforce KiCad's board-level minimum constraints from Board Setup → Design Rules"
        )
        self.obey_drc_check.Bind(wx.EVT_CHECKBOX, self._on_obey_drc_changed)
        param_box_sizer.Add(self.obey_drc_check, 0, wx.ALL, 5)

        param_scroll = wx.ScrolledWindow(panel, style=wx.VSCROLL)
        param_scroll.SetScrollRate(0, 10)
        param_inner = wx.BoxSizer(wx.VERTICAL)

        # Basic parameters grid
        param_grid = wx.FlexGridSizer(cols=2, hgap=10, vgap=5)
        param_grid.AddGrowableCol(1)
        self._add_basic_parameters(param_scroll, param_grid)
        param_inner.Add(param_grid, 0, wx.EXPAND | wx.ALL, 5)

        param_scroll.SetSizer(param_inner)
        param_box_sizer.Add(param_scroll, 1, wx.EXPAND)
        return param_box_sizer

    def _add_basic_parameters(self, parent, grid):
        """Add basic parameter controls to grid."""
        # Map control names to DRC minimum keys
        self._drc_min_keys = {
            'track_width': 'min_track_width',
            'clearance': 'min_clearance',
            'via_size': 'min_via_size',
            'via_drill': 'min_via_drill',
            'hole_to_hole_clearance': 'min_hole_to_hole',
            'board_edge_clearance': 'min_copper_edge_clearance',
        }
        params = [
            ('track_width', 'Track Width (mm):', defaults.TRACK_WIDTH, "Width of routed traces"),
            ('clearance', 'Min Clearance (mm):', defaults.CLEARANCE, "Minimum spacing between traces and other copper"),
            ('via_size', 'Via Size (mm):', defaults.VIA_SIZE, "Outer diameter of vias"),
            ('via_drill', 'Via Drill (mm):', defaults.VIA_DRILL, "Drill hole diameter for vias"),
            ('hole_to_hole_clearance', 'Min Hole Clearance (mm):', defaults.HOLE_TO_HOLE_CLEARANCE, "Minimum spacing between via/pad drill holes"),
        ]
        # Each geometry floor is a "checkbox + spinctrl" row like the edge control
        # (#439): unchecked = default from the board (Default net-class for
        # track/clearance/via, board Constraint for the hole floor); checking the
        # box overrides with the typed value. Checking the CLEARANCE box is also
        # the "clamp non-Default net-classes" switch (== CLI passing --clearance).
        for name, label, default, tooltip in params:
            r = defaults.PARAM_RANGES[name]
            grid.Add(wx.StaticText(parent, label=label), 0, wx.ALIGN_CENTER_VERTICAL)
            row_sizer = wx.BoxSizer(wx.HORIZONTAL)
            chk = wx.CheckBox(parent, label="")
            chk.SetValue(False)
            chk.SetToolTip(
                "Override this value (unchecked = use the board's own value: "
                "Default net-class for track/clearance/via, board Constraint for hole).")
            chk.Bind(wx.EVT_CHECKBOX, self._on_param_override_check)
            ctrl = wx.SpinCtrlDouble(parent, min=r['min'], max=r['max'], initial=default, inc=r['inc'])
            ctrl.SetDigits(r['digits'])
            ctrl.SetToolTip(tooltip)
            ctrl.Bind(wx.EVT_SPINCTRLDOUBLE, lambda evt, n=name: self._on_drc_param_changed(evt, n))
            ctrl.Enable(False)
            setattr(self, name, ctrl)
            setattr(self, name + '_check', chk)
            row_sizer.Add(chk, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
            row_sizer.Add(ctrl, 1, wx.EXPAND)
            grid.Add(row_sizer, 0, wx.EXPAND)

        # Fab tier (issue #237): the JLC manufacturing floor every tab routes/grades
        # DOWN toward. 'standard' (no extra cost) auto-escalates to 'advanced' (the
        # more-costly 0.25/0.15 small via etc.) WITH A WARNING when a fine-pitch
        # fan-out can't escape at the standard floor; 'advanced' is a hard floor. An
        # optional override file overlays the selected tier (only the keys it lists)
        # and disables escalation. One shared control read by every tab.
        grid.Add(wx.StaticText(parent, label="Fab Tier:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.fab_tier = wx.Choice(parent, choices=["standard", "advanced"])
        self.fab_tier.SetSelection(0)
        self.fab_tier.SetToolTip(
            "JLC fab capability floor. standard = no-extra-cost, escalates to advanced "
            "(with a warning) when a fine-pitch fan-out needs it; advanced = tight "
            "0.25/0.15 via etc. (more costly), a hard floor.")
        self.fab_tier.Bind(wx.EVT_CHOICE, self._revalidate_fab_floors)
        grid.Add(self.fab_tier, 0, wx.EXPAND)

        # Override file: a recent-files dropdown (favourites) + Browse... file picker.
        grid.Add(wx.StaticText(parent, label="Fab Overrides File:"), 0, wx.ALIGN_CENTER_VERTICAL)
        ovr_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.fab_overrides_path = wx.ComboBox(parent, choices=[], style=wx.CB_DROPDOWN)
        # Small min width so this row doesn't force the parameter grid's value
        # column wider than the spin controls (the ComboBox expands to fill whatever
        # width the column gives; the Browse button stays compact).
        self.fab_overrides_path.SetMinSize((60, -1))
        self.fab_overrides_path.SetToolTip(
            "Optional fab-floor override file (key=value lines, e.g. 'via_drill = 0.15') "
            "overlaying the selected tier; pick a recently-used file from the dropdown "
            "or Browse. Supplying one disables standard->advanced escalation. See the "
            "ready-to-copy template fab_overrides.example.txt in the repo root for the "
            "format and every key.")
        self.fab_overrides_path.Bind(wx.EVT_COMBOBOX, self._revalidate_fab_floors)
        ovr_sizer.Add(self.fab_overrides_path, 1, wx.EXPAND | wx.RIGHT, 4)
        self.fab_overrides_browse = wx.Button(parent, label="…", style=wx.BU_EXACTFIT)
        self.fab_overrides_browse.SetToolTip(
            "Browse for a fab-floor override file (template: fab_overrides.example.txt)")
        self.fab_overrides_browse.Bind(wx.EVT_BUTTON, self._on_browse_fab_overrides)
        ovr_sizer.Add(self.fab_overrides_browse, 0)
        grid.Add(ovr_sizer, 0, wx.EXPAND)

        # Edge clearance (checkbox + value)
        grid.Add(wx.StaticText(parent, label="Min Edge Clearance (mm):"), 0, wx.ALIGN_CENTER_VERTICAL)
        edge_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.edge_clearance_check = wx.CheckBox(parent, label="")
        self.edge_clearance_check.SetValue(False)
        self.edge_clearance_check.SetToolTip(
            "Enable custom edge clearance (unchecked = use the board's minimum "
            "copper-to-edge constraint when obeying design rules, else none)")
        self.edge_clearance_check.Bind(wx.EVT_CHECKBOX, self._on_edge_clearance_check)
        r = defaults.PARAM_RANGES['board_edge_clearance']
        self.board_edge_clearance = wx.SpinCtrlDouble(parent, min=r['min'], max=r['max'], initial=defaults.BOARD_EDGE_CLEARANCE, inc=r['inc'])
        self.board_edge_clearance.SetDigits(r['digits'])
        self.board_edge_clearance.Bind(wx.EVT_SPINCTRLDOUBLE, lambda evt: self._on_drc_param_changed(evt, 'board_edge_clearance'))
        self.board_edge_clearance.SetToolTip(
            "When disabled, the board's minimum copper-to-edge constraint is used "
            "(if obeying design rules)")
        self.board_edge_clearance.Enable(False)
        edge_sizer.Add(self.edge_clearance_check, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        edge_sizer.Add(self.board_edge_clearance, 1, wx.EXPAND)
        grid.Add(edge_sizer, 0, wx.EXPAND)

        # Grid step
        r = defaults.PARAM_RANGES['grid_step']
        grid.Add(wx.StaticText(parent, label="Grid Step (mm):"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.grid_step = wx.SpinCtrlDouble(parent, min=r['min'], max=r['max'], initial=defaults.GRID_STEP, inc=r['inc'])
        self.grid_step.SetDigits(r['digits'])
        self.grid_step.SetToolTip("Routing grid resolution (smaller = finer routing, slower)")
        grid.Add(self.grid_step, 0, wx.EXPAND)

        # Via cost (integer)
        r = defaults.PARAM_RANGES['via_cost']
        grid.Add(wx.StaticText(parent, label="Via Cost:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.via_cost = wx.SpinCtrl(parent, min=r['min'], max=r['max'], initial=defaults.VIA_COST)
        self.via_cost.SetToolTip("Cost penalty for adding vias (higher = fewer layer changes)")
        grid.Add(self.via_cost, 0, wx.EXPAND)

        # Max rip-up count
        r = defaults.PARAM_RANGES['max_ripup']
        grid.Add(wx.StaticText(parent, label="Max Rip-up:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.max_ripup = wx.SpinCtrl(parent, min=r['min'], max=r['max'], initial=defaults.MAX_RIPUP)
        self.max_ripup.SetToolTip("Maximum number of nets to rip up and reroute when blocked")
        grid.Add(self.max_ripup, 0, wx.EXPAND)

        # Rip-up abandon metric (#85 arbitration; docs/rip-up-reroute.md)
        grid.Add(wx.StaticText(parent, label="Rip-up Abandon Metric:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.ripup_abandon_metric = wx.Choice(
            parent, choices=list(defaults.RIPUP_ABANDON_METRIC_CHOICES))
        self.ripup_abandon_metric.SetStringSelection(defaults.RIPUP_ABANDON_METRIC)
        self.ripup_abandon_metric.SetToolTip(
            "How a multipoint tap rip-up decides between keeping the retry and "
            "abandoning it: stranded (default; count only fully-lost victims), "
            "total-pads / complete-nets (whole rip-tree totals), congestion / "
            "history / weighted (boxed-in and hard-to-route pads count more), "
            "probe / weighted-probe (discount pads unroutable either way)")
        grid.Add(self.ripup_abandon_metric, 0, wx.EXPAND)

        # Rip-up blocker SELECTION algorithm (#424 audit)
        grid.Add(wx.StaticText(parent, label="Rip-up Blocker Select:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.ripup_blocker_select = wx.Choice(
            parent, choices=list(defaults.RIPUP_BLOCKER_SELECT_CHOICES))
        self.ripup_blocker_select.SetStringSelection(defaults.RIPUP_BLOCKER_SELECT)
        self.ripup_blocker_select.SetToolTip(
            "Which net the rip-up ladder targets first: count (default; "
            "historical weighted cell count), near-target (endpoint-proximity "
            "first -- the true last-mile blocker hugs the failing pad but has "
            "few cells), bidir (boost nets blocking BOTH search directions), "
            "mincut (soft-cost probe on a map clone reads the actual crossing "
            "set: the true joint cut; falls back to count when the wall is "
            "static copper)")
        grid.Add(self.ripup_blocker_select, 0, wx.EXPAND)

    def _on_obey_drc_changed(self, event):
        """Handle checkbox toggle - apply board minimums if enabled."""
        if self.obey_drc_check.GetValue():
            self._apply_board_minimums_to_controls()

    def _fab_floored(self, ctrl_name, val):
        """Pin ``val`` UP to the fab floor for ``ctrl_name`` (the fab can't make
        sub-floor geometry) -- parity with the CLI's enforce_fab_floors, and it
        respects the same --fab-tier / fab-overrides file. Idempotent for a control
        value that was already fab-floored interactively."""
        floor = self._fab_floor_for_ctrl(ctrl_name)
        if floor is not None and val is not None and val < floor:
            return floor
        return val

    def _effective_board_edge_clearance(self):
        """Board-edge clearance to route with. UNCHECKED: the board's own
        min_copper_edge_clearance constraint (parity with the CLI, which uses it
        when --board-edge-clearance is omitted). CHECKED: the entered override
        value, honored as given -- identical to the other basic-tab overrides
        (_effective_geometry_floor): the shared Obey-DRC interactive validation
        (_on_drc_param_changed / _apply_board_minimums_to_controls, keyed via
        _drc_min_keys['board_edge_clearance']) already clamps the control up to the
        board minimum while Obey-DRC is on, so no redundant route-time re-clamp is
        needed here (edge was the only param that carried one). Pinned UP to the
        fab copper-to-edge floor either way."""
        if self.edge_clearance_check.GetValue():
            val = self.board_edge_clearance.GetValue()
        else:
            val = (_get_board_minimum_constraints() or {}).get('min_copper_edge_clearance') or 0.0
        return self._fab_floored('board_edge_clearance', val)

    def _effective_plane_edge_clearance(self):
        """Plane-zone edge inset (mirrors route_planes.py / repair_planes.py):
        the board's DECLARED copper-edge rule if it has one, else PLANE_EDGE_CLEARANCE
        (0.5 -- plane pours want more edge margin than signal traces); pinned up to the
        fab copper-to-edge floor. NOT the signal _effective_board_edge_clearance, which
        fab-floors a no-edge-rule board's 0 up to 0.2 and loses the 'declared vs not'
        distinction (that collapsed the GUI plane inset to 0.2 while the CLI held 0.5)."""
        rule = (_get_board_minimum_constraints() or {}).get('min_copper_edge_clearance')
        val = rule if (rule and rule > 1e-9) else defaults.PLANE_EDGE_CLEARANCE
        return self._fab_floored('board_edge_clearance', val)

    def _effective_geometry_floor(self, name):
        """Geometry floor to route/grade with (#439 parity with the CLI):
        the dedicated control when its override checkbox is checked; otherwise
        the board's own value -- Default net-class for track/clearance/via,
        board Constraint for the hole floor. Falls back to the control value
        when the board value is unavailable, and is pinned UP to the fab floor."""
        if getattr(self, name + '_check').GetValue():
            val = getattr(self, name).GetValue()
            # #439 B: Min Clearance is a pure CEILING on every class incl. Default, so
            # the base clearance is min(Default class, override) -- exactly like the
            # CLI's args.clearance = min(_dflt_clr, _ceiling). An override ABOVE the
            # board's Default class therefore never loosens the base (the interactive
            # validation warns + pins it; this is the route-time safety net).
            if name == 'clearance':
                dflt = (_get_netclass_parameters('Default') or {}).get('clearance')
                if dflt is not None and val > dflt:
                    val = dflt
        else:
            if name == 'hole_to_hole_clearance':
                constraints = _get_board_minimum_constraints() or {}
                board_val = constraints.get('min_hole_to_hole')
            else:
                netclass = _get_netclass_parameters('Default') or {}
                board_val = netclass.get(name)
            val = board_val if board_val is not None else getattr(self, name).GetValue()
        return self._fab_floored(name, val)

    def _effective_track_width(self):
        return self._effective_geometry_floor('track_width')

    def _effective_clearance(self):
        return self._effective_geometry_floor('clearance')

    def _effective_via_size(self):
        return self._effective_geometry_floor('via_size')

    def _effective_via_drill(self):
        return self._effective_geometry_floor('via_drill')

    def _effective_hole_to_hole_clearance(self):
        return self._effective_geometry_floor('hole_to_hole_clearance')

    def _on_drc_param_changed(self, event, ctrl_name):
        """Validate parameter change against DRC minimums."""
        # Guard against re-entrancy: correcting the value below triggers another
        # EVT_SPINCTRLDOUBLE, and showing a modal dialog inside the handler steals
        # focus from the spin control which fires yet another event. Without this
        # guard the warning dialog reappears endlessly and the UI deadlocks (#30).
        if getattr(self, '_drc_validating', False):
            return

        # Fab floor (issue #237): independent of the DRC-obey toggle, a track /
        # clearance / via / drill / hole value can never go below what the fab can
        # make for the active tier. Pin to the floor and warn, don't route sub-fab.
        floor = self._fab_floor_for_ctrl(ctrl_name)
        ctrl = getattr(self, ctrl_name, None)
        if floor is not None and ctrl is not None and ctrl.GetValue() < floor - 1e-9:
            self._drc_validating = True
            try:
                ctrl.SetValue(floor)
            finally:
                self._drc_validating = False
            label = ctrl_name.replace('_', ' ').title()
            wx.CallAfter(
                wx.MessageBox,
                f"{label} cannot go below the fab floor {floor:.4f} mm for the "
                f"selected fab tier; pinned to it. Use a Fab Overrides file to "
                f"declare a smaller fab capability.",
                "Fab Floor", wx.OK | wx.ICON_WARNING)
            return

        # #439 B: the Min Clearance override is a pure CEILING. A value ABOVE the
        # board's Default net-class clearance has no effect on the base clearance
        # (nets never route looser than their own class -- min(Default, override), as
        # in the CLI). Pin it to the Default class and warn, so what you enter routes.
        if ctrl_name == 'clearance' and ctrl is not None \
                and getattr(self, 'clearance_check', None) is not None \
                and self.clearance_check.GetValue():
            dflt = (_get_netclass_parameters('Default') or {}).get('clearance')
            if dflt is not None and ctrl.GetValue() > dflt + 1e-9:
                self._drc_validating = True
                try:
                    ctrl.SetValue(dflt)
                finally:
                    self._drc_validating = False
                wx.CallAfter(
                    wx.MessageBox,
                    f"Min Clearance is a ceiling: a value above the board's Default "
                    f"net-class clearance ({dflt:.4f} mm) has no effect on the base "
                    f"clearance (nets never route looser than their own class). "
                    f"Pinned to {dflt:.4f} mm.",
                    "Min Clearance", wx.OK | wx.ICON_WARNING)
                return

        if not (hasattr(self, 'obey_drc_check') and self.obey_drc_check.GetValue()):
            event.Skip()
            return

        minimums = _get_board_minimum_constraints()
        if minimums is None:
            event.Skip()
            return

        min_key = self._drc_min_keys.get(ctrl_name)
        if not min_key or min_key not in minimums:
            event.Skip()
            return

        ctrl = getattr(self, ctrl_name, None)
        if ctrl is None:
            event.Skip()
            return

        minimum = minimums[min_key]
        current = ctrl.GetValue()

        if current < minimum:
            # Correct the value first (suppressing the nested validation event),
            # then show the warning deferred so no modal dialog runs inside this
            # handler. By the time it shows, the value is already valid.
            self._drc_validating = True
            try:
                ctrl.SetValue(minimum)
            finally:
                self._drc_validating = False
            label = ctrl_name.replace('_', ' ').title()
            wx.CallAfter(
                wx.MessageBox,
                f"{label} cannot be less than {minimum:.3f} mm\n"
                f"(Board minimum from Design Rules)",
                "Design Rule Constraint",
                wx.OK | wx.ICON_WARNING
            )
        else:
            event.Skip()

    def _apply_board_minimums_to_controls(self):
        """Apply board-level minimum constraints to control values.

        Called when dialog opens, before values are displayed to user.
        Silently adjusts values to meet board minimums.
        """
        if not (hasattr(self, 'obey_drc_check') and self.obey_drc_check.GetValue()):
            return

        minimums = _get_board_minimum_constraints()
        if minimums is None:
            return

        # Map control names to minimum keys
        checks = [
            ('track_width', 'min_track_width'),
            ('clearance', 'min_clearance'),
            ('via_size', 'min_via_size'),
            ('via_drill', 'min_via_drill'),
            ('hole_to_hole_clearance', 'min_hole_to_hole'),
            ('board_edge_clearance', 'min_copper_edge_clearance'),
        ]

        for ctrl_name, min_key in checks:
            ctrl = getattr(self, ctrl_name, None)
            if ctrl and minimums.get(min_key):
                current = ctrl.GetValue()
                minimum = minimums[min_key]
                if current < minimum:
                    ctrl.SetValue(minimum)

    def _add_advanced_parameters(self, parent, grid):
        """Add advanced parameter controls to grid."""
        # Impedance routing (checkbox + value)
        grid.Add(wx.StaticText(parent, label="Impedance:"), 0, wx.ALIGN_CENTER_VERTICAL)
        impedance_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.impedance_check = wx.CheckBox(parent, label="")
        self.impedance_check.SetValue(False)
        self.impedance_check.SetToolTip("Use impedance-based track width (overrides Track Width)")
        r = defaults.PARAM_RANGES['impedance']
        self.impedance_value = wx.SpinCtrl(parent, min=r['min'], max=r['max'], initial=defaults.IMPEDANCE_DEFAULT)
        self.impedance_value.SetToolTip("Target impedance in ohms")
        impedance_sizer.Add(self.impedance_check, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        impedance_sizer.Add(self.impedance_value, 1, wx.EXPAND)
        impedance_sizer.Add(wx.StaticText(parent, label="\u03A9"), 0, wx.ALIGN_CENTER_VERTICAL | wx.LEFT, 3)
        grid.Add(impedance_sizer, 0, wx.EXPAND)

        # Integer parameters
        int_params = [
            ('max_iterations', 'Max Iterations:', defaults.MAX_ITERATIONS, "Maximum A* iterations per net before giving up"),
            ('max_probe_iterations', 'Probe Iterations:', defaults.MAX_PROBE_ITERATIONS, "Iterations for quick probe routing attempts"),
            ('turn_cost', 'Turn Cost:', defaults.TURN_COST, "Penalty for 90-degree turns (encourages straighter routes)"),
            ('direction_preference_cost', 'Dir. Pref. Cost:', defaults.DIRECTION_PREFERENCE_COST, "Penalty for routing against layer's preferred direction"),
        ]
        for name, label, default, tooltip in int_params:
            r = defaults.PARAM_RANGES[name]
            grid.Add(wx.StaticText(parent, label=label), 0, wx.ALIGN_CENTER_VERTICAL)
            ctrl = wx.SpinCtrl(parent, min=r['min'], max=r['max'], initial=default)
            ctrl.SetToolTip(tooltip)
            setattr(self, name, ctrl)
            grid.Add(ctrl, 0, wx.EXPAND)

        # Heuristic weight
        r = defaults.PARAM_RANGES['heuristic_weight']
        grid.Add(wx.StaticText(parent, label="Heuristic Weight:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.heuristic_weight = wx.SpinCtrlDouble(parent, min=r['min'], max=r['max'], initial=defaults.HEURISTIC_WEIGHT, inc=r['inc'])
        self.heuristic_weight.SetDigits(r['digits'])
        self.heuristic_weight.SetToolTip("A* heuristic weight (higher = faster but less optimal routes)")
        grid.Add(self.heuristic_weight, 0, wx.EXPAND)

        # Proximity heuristic factor
        r = defaults.PARAM_RANGES['proximity_heuristic_factor']
        grid.Add(wx.StaticText(parent, label="Prox. Heuristic Factor:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.proximity_heuristic_factor = wx.SpinCtrlDouble(parent, min=r['min'], max=r['max'], initial=defaults.PROXIMITY_HEURISTIC_FACTOR, inc=r['inc'])
        self.proximity_heuristic_factor.SetDigits(r['digits'])
        self.proximity_heuristic_factor.SetToolTip("Factor for proximity-aware A* heuristic (0 = disabled)")
        grid.Add(self.proximity_heuristic_factor, 0, wx.EXPAND)

        # Float parameters
        float_params = [
            ('bga_proximity_radius', 'BGA Proximity (mm):', defaults.BGA_PROXIMITY_RADIUS, "Radius around BGA pads to apply extra cost"),
            ('bga_proximity_cost', 'BGA Prox. Cost:', defaults.BGA_PROXIMITY_COST, "Cost multiplier for routing near BGA pads"),
            ('stub_proximity_radius', 'Stub Proximity (mm):', defaults.STUB_PROXIMITY_RADIUS, "Radius around stubs to apply extra cost"),
            ('stub_proximity_cost', 'Stub Prox. Cost:', defaults.STUB_PROXIMITY_COST, "Cost for routing near stubs of other nets"),
            ('neckdown_length', 'Neck-down (mm):', defaults.NECKDOWN_LENGTH, "Length of narrow track from the pad when a wide power route is necked down (issue #72)"),
            ('neckdown_taper_length', 'Neck Taper (mm):', defaults.NECKDOWN_TAPER_LENGTH, "Length of the stepped narrow-to-wide width taper on necked routes (0 = abrupt)"),
            ('coplanar_gap', 'Coplanar Gap (mm):', defaults.COPLANAR_GAP, "#486: declare that impedance-controlled traces run through a same-layer ground pour this far away (edge to edge). >0 uses the coplanar-waveguide-over-ground model instead of microstrip -- a NARROWER trace for the same ohms. Pour the plane layers with a MATCHING zone clearance, then verify with check_impedance.py. 0 = plain microstrip."),
            ('via_proximity_cost', 'Via Prox. Multiplier:', defaults.VIA_PROXIMITY_COST, "Cost multiplier for placing vias near other vias"),
            ('track_proximity_distance', 'Track Prox. (mm):', defaults.TRACK_PROXIMITY_DISTANCE, "Distance to detect parallel tracks for bunching avoidance"),
            ('track_proximity_cost', 'Track Prox. Cost:', defaults.TRACK_PROXIMITY_COST, "Cost for routing parallel to existing tracks"),
            ('vertical_attraction_radius', 'Vert. Attract (mm):', defaults.VERTICAL_ATTRACTION_RADIUS, "Radius for cross-layer track stacking: attracts the route toward ANY net's tracks on other layers (net-agnostic)"),
            ('vertical_attraction_cost', 'Vert. Attract Cost:', defaults.VERTICAL_ATTRACTION_COST, "Bonus for routing in the vertical shadow of other layers' tracks (0 = off; net-agnostic corridor stacking)"),
            ('ripped_route_avoidance_radius', 'Rip Avoid (mm):', defaults.RIPPED_ROUTE_AVOIDANCE_RADIUS, "Radius to avoid area where previous route failed"),
            ('ripped_route_avoidance_cost', 'Rip Avoid Cost:', defaults.RIPPED_ROUTE_AVOIDANCE_COST, "Cost for routing through previously ripped area"),
            ('routing_clearance_margin', 'Clearance Margin:', defaults.ROUTING_CLEARANCE_MARGIN, "Extra clearance margin multiplier for safety"),
        ]
        for name, label, default, tooltip in float_params:
            r = defaults.PARAM_RANGES[name]
            grid.Add(wx.StaticText(parent, label=label), 0, wx.ALIGN_CENTER_VERTICAL)
            ctrl = wx.SpinCtrlDouble(parent, min=r['min'], max=r['max'], initial=default, inc=r['inc'])
            ctrl.SetDigits(r['digits'])
            ctrl.SetToolTip(tooltip)
            setattr(self, name, ctrl)
            grid.Add(ctrl, 0, wx.EXPAND)

        # Ordering strategy
        grid.Add(wx.StaticText(parent, label="Ordering Strategy:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.ordering_strategy = wx.Choice(parent, choices=["mps", "inside_out", "original", "bus"])
        self.ordering_strategy.SetSelection(0)
        self.ordering_strategy.SetToolTip("Net ordering strategy: mps (minimum planar subset), "
                                          "inside_out, original order, or bus (detected bus groups "
                                          "first, members middle-out, rest by mps)")
        grid.Add(self.ordering_strategy, 0, wx.EXPAND)

        # Direction dropdown
        grid.Add(wx.StaticText(parent, label="Routing Direction:"), 0, wx.ALIGN_CENTER_VERTICAL)
        self.direction_choice = wx.Choice(parent, choices=["Auto", "Forward", "Backward"])
        self.direction_choice.SetSelection(0)
        self.direction_choice.SetToolTip("Direction search order for each net route")
        grid.Add(self.direction_choice, 0, wx.EXPAND)

    def _create_layers_panel(self, panel):
        """Create the layers selection panel."""
        layer_box = wx.StaticBox(panel, label="Layers")
        layer_box_sizer = wx.StaticBoxSizer(layer_box, wx.VERTICAL)
        layer_scroll = wx.ScrolledWindow(panel, style=wx.VSCROLL)
        layer_scroll.SetScrollRate(0, 10)
        layer_inner = wx.WrapSizer(wx.HORIZONTAL)

        self.layer_checks = {}
        for layer in self.pcb_data.board_info.copper_layers:
            cb = wx.CheckBox(layer_scroll, label=layer)
            # Default to all copper layers defined in the PCB
            cb.SetValue(True)
            cb.SetToolTip(f"Include {layer} for routing")
            self.layer_checks[layer] = cb
            layer_inner.Add(cb, 0, wx.ALL, 3)

        layer_scroll.SetSizer(layer_inner)
        layer_box_sizer.Add(layer_scroll, 1, wx.EXPAND)

        self.check_stackup_btn = wx.Button(panel, label="Check Stackup (AI)")
        self.check_stackup_btn.SetToolTip(
            "Run the recommend-stackup skill: reviews the board's physical stackup, "
            "flags untouched KiCad defaults (which skew impedance calculations), and "
            "recommends a fab-realistic stackup. Analysis only - shows a report.")
        self.check_stackup_btn.Bind(wx.EVT_BUTTON, self._on_check_stackup)
        layer_box_sizer.Add(self.check_stackup_btn, 0, wx.ALL, 3)
        return layer_box_sizer

    def _on_check_stackup(self, event):
        """Run recommend-stackup headless and show the report (issue #40)."""
        from .ai_gui import run_skill_dialog, board_path_for_analysis

        board = board_path_for_analysis(self.board_filename)
        if board is None:
            return
        value = run_skill_dialog(
            self, "AI: check stackup",
            "recommend-stackup", os.path.abspath(board),
            "analysis only, do not modify any files. After the report, end "
            "your reply with exactly one line of the form RESULT=<copper "
            "layer count you recommend> (a bare integer), e.g. RESULT=4",
            intro=f"Running recommend-stackup on {os.path.basename(board)} ...\n"
                  "(local analysis; typically a minute or two)",
            ai_params=self._ai_params())
        if value is not None:
            board_layers = len(self.pcb_data.board_info.copper_layers)
            note = ""
            try:
                if int(value) != board_layers:
                    note = (f" (board currently has {board_layers}; change it in "
                            "Board Setup before impedance-controlled routing)")
            except ValueError:
                pass
            self._append_log(f"AI recommends {value} copper layers{note}\n")

    def _on_browse_fab_overrides(self, event):
        """Browse for a fab-floor override file; remember it as a recent favourite."""
        cur = self.fab_overrides_path.GetValue().strip()
        ddir = os.path.dirname(cur) if cur else ""
        with wx.FileDialog(self, "Select fab-floor override file", defaultDir=ddir,
                           wildcard="Override files (*.txt;*.cfg)|*.txt;*.cfg|All files (*.*)|*.*",
                           style=wx.FD_OPEN | wx.FD_FILE_MUST_EXIST) as dlg:
            if dlg.ShowModal() == wx.ID_CANCEL:
                return
            self._add_recent_fab_override(dlg.GetPath())

    def _add_recent_fab_override(self, path):
        """Put `path` at the top of the override-file dropdown (deduped, capped)."""
        if not path:
            return
        items = [path] + [s for s in self.fab_overrides_path.GetStrings() if s != path]
        del items[8:]
        self.fab_overrides_path.Set(items)
        self.fab_overrides_path.SetValue(path)
        self._revalidate_fab_floors()

    def _fab_floor_for_ctrl(self, ctrl_name):
        """Fab floor (mm) for a Basic-tab spin control under the active fab tier +
        override file, or None if the control has no fab floor / no board loaded."""
        try:
            from fab_tiers import fab_floor_for_param, parse_fab_overrides
            ncu = len(self.pcb_data.board_info.copper_layers) or 2
            tier = self.fab_tier.GetString(self.fab_tier.GetSelection())
            path = self.fab_overrides_path.GetValue().strip()
            ovr = parse_fab_overrides(path) if path and os.path.isfile(path) else {}
            return fab_floor_for_param(ctrl_name, ncu, tier, ovr)
        except Exception:
            return None

    def _revalidate_fab_floors(self, event=None):
        """Re-pin every fab-floored Basic-tab spin control after the fab tier or
        override file changes (an override can RAISE a floor above the current value)."""
        pinned = []
        for name in ('track_width', 'clearance', 'via_size', 'via_drill',
                     'hole_to_hole_clearance'):
            ctrl = getattr(self, name, None)
            floor = self._fab_floor_for_ctrl(name)
            if ctrl is not None and floor is not None and ctrl.GetValue() < floor - 1e-9:
                self._drc_validating = True
                try:
                    ctrl.SetValue(floor)
                finally:
                    self._drc_validating = False
                pinned.append(f"{name.replace('_', ' ')} -> {floor:.4f} mm")
        if pinned and event is not None:
            wx.CallAfter(
                wx.MessageBox,
                "Pinned to the new fab floor:\n  " + "\n  ".join(pinned),
                "Fab Floor", wx.OK | wx.ICON_INFORMATION)
        if event is not None:
            event.Skip()

    def _create_basic_options_panel(self, panel):
        """Create the basic options panel for the Basic tab."""
        options_box = wx.StaticBox(panel, label="Options")
        options_box_sizer = wx.StaticBoxSizer(options_box, wx.VERTICAL)
        options_scroll = wx.ScrolledWindow(panel, style=wx.VSCROLL)
        options_scroll.SetScrollRate(0, 10)
        options_inner = wx.BoxSizer(wx.VERTICAL)

        # Stub layer swaps
        self.enable_layer_switch = wx.CheckBox(options_scroll, label="Stub layer swaps")
        self.enable_layer_switch.SetValue(True)
        self.enable_layer_switch.SetToolTip("Enable stub layer switching optimization")
        options_inner.Add(self.enable_layer_switch, 0, wx.ALL, 3)

        # Move copper text
        self.move_text_check = wx.CheckBox(options_scroll, label="Move copper text to silkscreen")
        self.move_text_check.SetValue(True)
        self.move_text_check.SetToolTip("Move gr_text from copper layers to silkscreen to prevent routing interference")
        options_inner.Add(self.move_text_check, 0, wx.ALL, 3)

        # Add teardrops
        self.add_teardrops_check = wx.CheckBox(options_scroll, label="Add teardrops")
        self.add_teardrops_check.SetValue(False)
        self.add_teardrops_check.SetToolTip("Add teardrop settings to all pads in output file")
        options_inner.Add(self.add_teardrops_check, 0, wx.ALL, 3)

        self.fix_drc_check = wx.CheckBox(options_scroll, label="Fix DRC settings after routing")
        self.fix_drc_check.SetValue(True)
        self.fix_drc_check.SetToolTip(
            "After routing, loosen the live board's DRC Board Setup floors + Default "
            "net class + non-routing severities to the values just routed to (issue "
            "#160), so a manual DRC flags only genuine problems instead of stock-"
            "default noise. The board's next save persists it. Mirrors the CLI's "
            "auto-fix (route.py, off via --no-fix-drc-settings)")
        options_inner.Add(self.fix_drc_check, 0, wx.ALL, 3)

        # Guide corridor: follow a user-drawn polyline (issue #7)
        self.guide_corridor_check = wx.CheckBox(options_scroll, label="Follow User-layer guide path")
        self.guide_corridor_check.SetValue(defaults.GUIDE_CORRIDOR_ENABLED)
        self.guide_corridor_check.SetToolTip(
            "Route the selected nets so they follow a polyline you draw on a User layer "
            "(waypoints), avoiding obstacles. Multiple nets pack alongside without overlapping.")
        options_inner.Add(self.guide_corridor_check, 0, wx.ALL, 3)

        gc_sizer = wx.BoxSizer(wx.HORIZONTAL)
        gc_sizer.Add(wx.StaticText(options_scroll, label="Guide Layer:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.guide_corridor_layer_ctrl = wx.TextCtrl(options_scroll, value=defaults.GUIDE_CORRIDOR_LAYER, size=(70, -1))
        self.guide_corridor_layer_ctrl.SetToolTip("User layer the guide polyline is drawn on (e.g., User.1)")
        gc_sizer.Add(self.guide_corridor_layer_ctrl, 0, wx.RIGHT, 8)
        gc_sizer.Add(wx.StaticText(options_scroll, label="Spacing(mm):"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.guide_corridor_spacing_ctrl = wx.TextCtrl(options_scroll, value=str(defaults.GUIDE_CORRIDOR_SPACING), size=(45, -1))
        self.guide_corridor_spacing_ctrl.SetToolTip("Max mm between waypoints. 0 = only the drawn segment endpoints; "
                                                    ">0 subdivides long segments to follow curves more tightly.")
        gc_sizer.Add(self.guide_corridor_spacing_ctrl, 0)
        options_inner.Add(gc_sizer, 0, wx.EXPAND | wx.ALL, 3)

        self.clear_guide_layer_check = wx.CheckBox(options_scroll, label="Clear guide layer after routing")
        self.clear_guide_layer_check.SetValue(False)
        self.clear_guide_layer_check.SetToolTip(
            "After a successful route, delete the guide graphics from the guide layer so you "
            "can draw new ones. Only acts when 'Follow User-layer guide path' is enabled.")
        options_inner.Add(self.clear_guide_layer_check, 0, wx.ALL, 3)

        # Keepout zone: keep tracks out of a user-drawn polygon (issue #27)
        self.keepout_check = wx.CheckBox(options_scroll, label="Keep out of User-layer polygon(s)")
        self.keepout_check.SetValue(defaults.KEEPOUT_ENABLED)
        self.keepout_check.SetToolTip(
            "Keep routed tracks out of any closed polygons you draw on a User layer. "
            "Applies to all nets being routed this run. Don't draw them over pads you need to route.")
        options_inner.Add(self.keepout_check, 0, wx.ALL, 3)

        ko_sizer = wx.BoxSizer(wx.HORIZONTAL)
        ko_sizer.Add(wx.StaticText(options_scroll, label="Keepout Layer:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.keepout_layer_ctrl = wx.TextCtrl(options_scroll, value=defaults.KEEPOUT_LAYER, size=(70, -1))
        self.keepout_layer_ctrl.SetToolTip("User layer the keepout polygons are drawn on (e.g., User.2)")
        ko_sizer.Add(self.keepout_layer_ctrl, 0)
        options_inner.Add(ko_sizer, 0, wx.EXPAND | wx.ALL, 3)

        self.clear_keepout_layer_check = wx.CheckBox(options_scroll, label="Clear keepout layer after routing")
        self.clear_keepout_layer_check.SetValue(False)
        self.clear_keepout_layer_check.SetToolTip(
            "After a successful route, delete the keepout polygons from the keepout layer so you "
            "can draw new ones. Only acts when 'Keep out of User-layer polygon(s)' is enabled.")
        options_inner.Add(self.clear_keepout_layer_check, 0, wx.ALL, 3)

        # Power nets
        power_sizer = wx.BoxSizer(wx.HORIZONTAL)
        power_sizer.Add(wx.StaticText(options_scroll, label="Power Nets:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.power_nets_ctrl = wx.TextCtrl(options_scroll)
        self.power_nets_ctrl.SetToolTip("Glob patterns for power nets (e.g., *GND* *VCC*)")
        power_sizer.Add(self.power_nets_ctrl, 1, wx.EXPAND | wx.RIGHT, 5)
        self.ask_ai_power_btn = wx.Button(options_scroll, label="Ask AI", style=wx.BU_EXACTFIT)
        self.ask_ai_power_btn.SetToolTip(
            "Run the analyze-power-nets skill: looks up component datasheets to "
            "identify power nets and recommend per-net track widths, then fills "
            "the Power Nets and Power Widths fields. Takes a few minutes (web lookups).")
        self.ask_ai_power_btn.Bind(wx.EVT_BUTTON, self._on_ask_ai_power_nets)
        power_sizer.Add(self.ask_ai_power_btn, 0)
        options_inner.Add(power_sizer, 0, wx.EXPAND | wx.ALL, 3)

        # Coplanar nets (#486): which nets the Coplanar Gap applies to.
        coplanar_sizer = wx.BoxSizer(wx.HORIZONTAL)
        coplanar_sizer.Add(wx.StaticText(options_scroll, label="Coplanar Nets:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.coplanar_nets_ctrl = wx.TextCtrl(options_scroll)
        self.coplanar_nets_ctrl.SetToolTip(
            "Glob patterns for nets that run through a same-layer ground pour "
            "(e.g., RF_* /USB/D*). Only meaningful with Coplanar Gap > 0 and "
            "Impedance enabled: matching nets get their width from the "
            "coplanar-waveguide-over-ground model, everyone else stays "
            "microstrip. EMPTY = every net in this run is treated as coplanar.")
        coplanar_sizer.Add(self.coplanar_nets_ctrl, 1, wx.EXPAND)
        options_inner.Add(coplanar_sizer, 0, wx.EXPAND | wx.ALL, 3)

        # Power net widths
        widths_sizer = wx.BoxSizer(wx.HORIZONTAL)
        widths_sizer.Add(wx.StaticText(options_scroll, label="Power Widths:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.power_widths_ctrl = wx.TextCtrl(options_scroll)
        self.power_widths_ctrl.SetToolTip("Track widths in mm for each power-net pattern (space-separated)")
        widths_sizer.Add(self.power_widths_ctrl, 1, wx.EXPAND)
        options_inner.Add(widths_sizer, 0, wx.EXPAND | wx.ALL, 3)

        # Power route neck-down (issue #72)
        self.power_tap_neckdown_check = wx.CheckBox(options_scroll, label="Power route neck-down")
        self.power_tap_neckdown_check.SetValue(True)
        self.power_tap_neckdown_check.SetToolTip("Retry failed wide power routes at the default track width, "
                                                 "narrow near the pads and wide where clearance allows")
        options_inner.Add(self.power_tap_neckdown_check, 0, wx.ALL, 3)

        # No BGA zones
        bga_sizer = wx.BoxSizer(wx.HORIZONTAL)
        bga_sizer.Add(wx.StaticText(options_scroll, label="No BGA Zones:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        # Default empty == CLI route.py's --no-bga-zones default (None): auto-detect
        # and ENABLE BGA exclusion zones. "ALL" here would disable them all, which
        # diverged from the CLI (GUI/CLI default parity).
        self.no_bga_zones_ctrl = wx.TextCtrl(options_scroll, value="")
        self.no_bga_zones_ctrl.SetToolTip("Disable BGA exclusion zones: component refs (e.g., U1 U3), ALL, or leave empty (default) to keep all BGA zones")
        bga_sizer.Add(self.no_bga_zones_ctrl, 1, wx.EXPAND)
        options_inner.Add(bga_sizer, 0, wx.EXPAND | wx.ALL, 3)

        # Rip pre-existing nets (issue #103): make tracks committed by a
        # previous run eligible for rip-up during retry. Mirrors the CLI
        # --rip-existing-nets flag (fnmatch patterns; ALL = everything).
        rip_existing_sizer = wx.BoxSizer(wx.HORIZONTAL)
        rip_existing_sizer.Add(wx.StaticText(options_scroll, label="Rip Pre-Existing Nets:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.rip_existing_nets_ctrl = wx.TextCtrl(options_scroll, value="")
        self.rip_existing_nets_ctrl.SetToolTip("Let the router rip up tracks committed by a previous run when they block a retry: "
                                               "net-name patterns (e.g. /DDR* USB+), ALL for every pre-existing net, or leave empty to keep them fixed")
        rip_existing_sizer.Add(self.rip_existing_nets_ctrl, 1, wx.EXPAND)
        options_inner.Add(rip_existing_sizer, 0, wx.EXPAND | wx.ALL, 3)

        # Force re-route (#515 / PR #533): rip and re-route from scratch every
        # net SELECTED for this run, even if already fully connected. Mirrors
        # the CLI --force-reroute flag; the protection rules live engine-side
        # (protected nets skipped unless named exactly, locked copper never
        # ripped, plane nets skipped, originals restored on a no-copper replan).
        self.force_reroute = wx.CheckBox(options_scroll, label="Force re-route selected nets")
        self.force_reroute.SetToolTip(
            "Rip and re-route from scratch every net selected for this run, even if "
            "already fully connected (replaces a connected-but-unwanted route). "
            "Protected nets (length-matched groups, routed diff pairs) are skipped "
            "unless selected by exact name; KiCad-locked copper is never ripped; "
            "plane nets are skipped (use the Planes tab). If the re-route fails "
            "outright, the original copper is restored.")
        options_inner.Add(self.force_reroute, 0, wx.ALL, 3)

        # Keep input copper (#84 / --keep-input-copper): the flip side of rip --
        # rip-existing gates whether the ROUTER may tear up pre-existing tracks
        # that block a retry; this gates whether the post-route CLEANUP passes
        # may sweep/rewrite the input's own copper. Placed next to rip so both
        # "leave my existing copper alone" controls sit together on the Basic tab.
        self.keep_input_copper = wx.CheckBox(options_scroll, label="Keep all input copper")
        self.keep_input_copper.SetToolTip(
            "Treat the board's pre-existing copper as read-only: the post-route cleanup "
            "passes never remove or rewrite it (fanout escape stubs, hand-routed nets), "
            "only this run's new copper is cleaned")
        options_inner.Add(self.keep_input_copper, 0, wx.ALL, 3)

        # Layer costs
        layer_sizer = wx.BoxSizer(wx.HORIZONTAL)
        layer_sizer.Add(wx.StaticText(options_scroll, label="Layer Costs:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.layer_costs_ctrl = wx.TextCtrl(options_scroll)
        # Generate default layer costs: 1.0 for F.Cu, 3.0 for others
        default_costs = []
        for layer in self.pcb_data.board_info.copper_layers:
            default_costs.append("1.0" if layer == "F.Cu" else "3.0")
        self.layer_costs_ctrl.SetValue(" ".join(default_costs))
        self.layer_costs_ctrl.SetToolTip("Per-layer cost multipliers 1.0-1000, or any negative value "
                                         "(e.g. -1) = forbidden (obstacle/via-span only, no routed copper). "
                                         "Order: " + " ".join(self.pcb_data.board_info.copper_layers))
        layer_sizer.Add(self.layer_costs_ctrl, 1, wx.EXPAND)
        options_inner.Add(layer_sizer, 0, wx.EXPAND | wx.ALL, 3)

        options_scroll.SetSizer(options_inner)
        options_box_sizer.Add(options_scroll, 1, wx.EXPAND)
        return options_box_sizer

    def _on_ask_ai_power_nets(self, event):
        """Run analyze-power-nets headless and fill the Power Nets and
        Power Widths fields from its recommendation (issue #34)."""
        from .ai_gui import run_skill_dialog, board_path_for_analysis

        board = board_path_for_analysis(self.board_filename)
        if board is None:
            return
        value = run_skill_dialog(
            self, "AI: analyze power nets",
            "analyze-power-nets", os.path.abspath(board),
            "analysis only, do not modify any files. After the report, end "
            "your reply with exactly one line of the form "
            "RESULT=--power-nets <space-separated glob patterns> "
            "--power-nets-widths <space-separated widths in mm>, "
            'e.g. RESULT=--power-nets "*GND*" "*VCC*" --power-nets-widths 0.5 0.4',
            intro=f"Running analyze-power-nets on {os.path.basename(board)} ...\n"
                  "(datasheet lookups; typically a few minutes)",
            ai_params=self._ai_params())
        if value is not None:
            self._apply_power_nets_recommendation(value)

    def _apply_power_nets_recommendation(self, value):
        """Validate the AI's RESULT value and fill the power-net fields."""
        parsed = self._parse_power_nets_result(value)
        if parsed is None:
            self._append_log(f"AI: unusable power-nets recommendation {value!r}\n")
            return
        patterns, widths = parsed
        self.power_nets_ctrl.SetValue(" ".join(patterns))
        self.power_widths_ctrl.SetValue(" ".join(f"{w:g}" for w in widths))
        self._append_log(
            "AI recommended power nets: "
            + ", ".join(f"{p} -> {w:g}mm" for p, w in zip(patterns, widths)) + "\n")

    @staticmethod
    def _parse_power_nets_result(value):
        """Parse '--power-nets <patterns> --power-nets-widths <widths>'.

        Returns (patterns, widths) or None. Widths must be positive floats,
        one per pattern (first matching pattern wins, same as the CLI).
        """
        import shlex
        try:
            tokens = shlex.split(value)
        except ValueError:
            return None
        patterns, widths = [], []
        bucket = None
        for token in tokens:
            if token == "--power-nets":
                bucket = patterns
            elif token == "--power-nets-widths":
                bucket = widths
            elif token.startswith("--") or bucket is None:
                bucket = None  # unknown flag: ignore its values
            else:
                bucket.append(token)
        if not patterns or len(patterns) != len(widths):
            return None
        try:
            float_widths = [float(w) for w in widths]
        except ValueError:
            return None
        if any(w <= 0 for w in float_widths):
            return None
        return patterns, float_widths

    def _create_options_panel(self, panel):
        """Create the advanced options panel (MPS, crossing, length matching, debug)."""
        options_box = wx.StaticBox(panel, label="Options")
        options_box_sizer = wx.StaticBoxSizer(options_box, wx.VERTICAL)
        options_scroll = wx.ScrolledWindow(panel, style=wx.VSCROLL)
        options_scroll.SetScrollRate(0, 10)
        options_inner = wx.BoxSizer(wx.VERTICAL)

        # DRC settings fix (sub-options of the Basic tab's "Fix DRC settings
        # after routing" toggle) -- kept at the top of the Options box.
        drc_label = wx.StaticText(options_scroll, label="DRC Settings Fix:")
        drc_label.SetFont(drc_label.GetFont().Bold())
        options_inner.Add(drc_label, 0, wx.LEFT | wx.TOP, 3)

        self.keep_thermal_check = wx.CheckBox(options_scroll, label="Keep thermal-relief DRC severity")
        self.keep_thermal_check.SetValue(False)
        self.keep_thermal_check.SetToolTip(
            "When 'Fix DRC settings after routing' runs (Basic tab), by default it "
            "demotes the starved_thermal DRC category to a warning. Check this to "
            "leave thermal-relief severity untouched (matches the CLI's "
            "--keep-thermal). Off by default.")
        options_inner.Add(self.keep_thermal_check, 0, wx.ALL, 3)

        options_inner.AddSpacer(10)

        # MPS options
        mps_label = wx.StaticText(options_scroll, label="MPS Options:")
        mps_label.SetFont(mps_label.GetFont().Bold())
        options_inner.Add(mps_label, 0, wx.LEFT | wx.TOP, 3)

        self.mps_reverse_rounds = wx.CheckBox(options_scroll, label="Reverse MPS rounds")
        self.mps_reverse_rounds.SetToolTip("Route most-conflicting groups first instead of least-conflicting")
        options_inner.Add(self.mps_reverse_rounds, 0, wx.ALL, 3)

        self.mps_layer_swap = wx.CheckBox(options_scroll, label="MPS layer swap")
        self.mps_layer_swap.SetToolTip("Enable MPS-aware layer swaps to reduce crossing conflicts")
        options_inner.Add(self.mps_layer_swap, 0, wx.ALL, 3)

        self.mps_segment_intersection = wx.CheckBox(options_scroll, label="MPS segment intersection")
        self.mps_segment_intersection.SetToolTip("Force MPS to use segment intersection for crossing detection")
        options_inner.Add(self.mps_segment_intersection, 0, wx.ALL, 3)

        options_inner.AddSpacer(10)

        # Bus routing options
        bus_label = wx.StaticText(options_scroll, label="Bus Routing:")
        bus_label.SetFont(bus_label.GetFont().Bold())
        options_inner.Add(bus_label, 0, wx.LEFT | wx.TOP, 3)

        self.bus_enabled = wx.CheckBox(options_scroll, label="Enable bus routing")
        self.bus_enabled.SetToolTip("Auto-detect and route parallel groups of nets together")
        options_inner.Add(self.bus_enabled, 0, wx.ALL, 3)

        bus_detect_sizer = wx.BoxSizer(wx.HORIZONTAL)
        bus_detect_sizer.Add(wx.StaticText(options_scroll, label="Detection radius:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['bus_detection_radius']
        self.bus_detection_radius = wx.SpinCtrlDouble(options_scroll, min=r['min'], max=r['max'],
                                                       initial=defaults.BUS_DETECTION_RADIUS, inc=r['inc'])
        self.bus_detection_radius.SetDigits(r['digits'])
        self.bus_detection_radius.SetToolTip("Max endpoint distance to form bus group (mm)")
        bus_detect_sizer.Add(self.bus_detection_radius, 1, wx.EXPAND)
        options_inner.Add(bus_detect_sizer, 0, wx.EXPAND | wx.ALL, 3)

        bus_attract_sizer = wx.BoxSizer(wx.HORIZONTAL)
        bus_attract_sizer.Add(wx.StaticText(options_scroll, label="Attraction radius:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['bus_attraction_radius']
        self.bus_attraction_radius = wx.SpinCtrlDouble(options_scroll, min=r['min'], max=r['max'],
                                                        initial=defaults.BUS_ATTRACTION_RADIUS, inc=r['inc'])
        self.bus_attraction_radius.SetDigits(r['digits'])
        self.bus_attraction_radius.SetToolTip("Attraction radius from neighbor track (mm)")
        bus_attract_sizer.Add(self.bus_attraction_radius, 1, wx.EXPAND)
        options_inner.Add(bus_attract_sizer, 0, wx.EXPAND | wx.ALL, 3)

        bus_bonus_sizer = wx.BoxSizer(wx.HORIZONTAL)
        bus_bonus_sizer.Add(wx.StaticText(options_scroll, label="Attraction bonus:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['bus_attraction_bonus']
        self.bus_attraction_bonus = wx.SpinCtrl(options_scroll, min=r['min'], max=r['max'],
                                                 initial=defaults.BUS_ATTRACTION_BONUS)
        self.bus_attraction_bonus.SetToolTip("Cost bonus for staying parallel to neighbor track")
        bus_bonus_sizer.Add(self.bus_attraction_bonus, 1, wx.EXPAND)
        options_inner.Add(bus_bonus_sizer, 0, wx.EXPAND | wx.ALL, 3)

        bus_min_sizer = wx.BoxSizer(wx.HORIZONTAL)
        bus_min_sizer.Add(wx.StaticText(options_scroll, label="Min nets:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['bus_min_nets']
        self.bus_min_nets = wx.SpinCtrl(options_scroll, min=r['min'], max=r['max'],
                                         initial=defaults.BUS_MIN_NETS)
        self.bus_min_nets.SetToolTip("Minimum number of nets to form a bus group")
        bus_min_sizer.Add(self.bus_min_nets, 1, wx.EXPAND)
        options_inner.Add(bus_min_sizer, 0, wx.EXPAND | wx.ALL, 3)

        options_inner.AddSpacer(10)

        # Crossing/swap options
        self.no_crossing_layer_check = wx.CheckBox(options_scroll, label="Ignore crossing layers")
        self.no_crossing_layer_check.SetToolTip("Count crossings regardless of layer overlap")
        options_inner.Add(self.no_crossing_layer_check, 0, wx.ALL, 3)

        self.can_swap_to_top = wx.CheckBox(options_scroll, label="Allow swap to top layer")
        self.can_swap_to_top.SetToolTip("Allow swapping stubs to F.Cu (top layer)")
        options_inner.Add(self.can_swap_to_top, 0, wx.ALL, 3)

        # Crossing penalty
        crossing_sizer = wx.BoxSizer(wx.HORIZONTAL)
        crossing_sizer.Add(wx.StaticText(options_scroll, label="Crossing Penalty:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['crossing_penalty']
        self.crossing_penalty = wx.SpinCtrlDouble(options_scroll, min=r['min'], max=r['max'],
                                                   initial=defaults.CROSSING_PENALTY, inc=r['inc'])
        self.crossing_penalty.SetDigits(r['digits'])
        self.crossing_penalty.SetToolTip("Penalty for crossing assignments in target swap optimization")
        crossing_sizer.Add(self.crossing_penalty, 1, wx.EXPAND)
        options_inner.Add(crossing_sizer, 0, wx.EXPAND | wx.ALL, 3)

        options_inner.AddSpacer(10)

        # Length matching
        length_label = wx.StaticText(options_scroll, label="Length Matching:")
        length_label.SetFont(length_label.GetFont().Bold())
        options_inner.Add(length_label, 0, wx.LEFT | wx.TOP, 3)

        group_sizer = wx.BoxSizer(wx.HORIZONTAL)
        group_sizer.Add(wx.StaticText(options_scroll, label="Groups:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.length_match_groups_ctrl = wx.TextCtrl(options_scroll)
        self.length_match_groups_ctrl.SetToolTip("Net patterns to length-match (comma-separated groups, e.g., 'DATA*,ADDR*')")
        group_sizer.Add(self.length_match_groups_ctrl, 1, wx.EXPAND)
        options_inner.Add(group_sizer, 0, wx.EXPAND | wx.ALL, 3)

        length_params_sizer = wx.BoxSizer(wx.HORIZONTAL)
        length_params_sizer.Add(wx.StaticText(options_scroll, label="Tolerance:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['length_match_tolerance']
        self.length_match_tolerance = wx.SpinCtrlDouble(options_scroll, min=r['min'], max=r['max'],
                                                        initial=defaults.LENGTH_MATCH_TOLERANCE, inc=r['inc'])
        self.length_match_tolerance.SetDigits(r['digits'])
        self.length_match_tolerance.SetToolTip("Acceptable length difference in mm for matched nets")
        length_params_sizer.Add(self.length_match_tolerance, 0, wx.RIGHT, 10)
        length_params_sizer.Add(wx.StaticText(options_scroll, label="Amplitude:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['meander_amplitude']
        self.meander_amplitude = wx.SpinCtrlDouble(options_scroll, min=r['min'], max=r['max'],
                                                   initial=defaults.MEANDER_AMPLITUDE, inc=r['inc'])
        self.meander_amplitude.SetDigits(r['digits'])
        self.meander_amplitude.SetToolTip("Height of meander waves for length matching")
        length_params_sizer.Add(self.meander_amplitude, 0)
        options_inner.Add(length_params_sizer, 0, wx.EXPAND | wx.ALL, 3)

        # Own row: a third spin control overflows the Tolerance/Amplitude row
        spacing_sizer = wx.BoxSizer(wx.HORIZONTAL)
        spacing_sizer.Add(wx.StaticText(options_scroll, label="Arm spacing (x width):"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['meander_spacing']
        self.meander_spacing = wx.SpinCtrlDouble(options_scroll, min=r['min'], max=r['max'],
                                                 initial=defaults.MEANDER_SPACING, inc=r['inc'])
        self.meander_spacing.SetDigits(r['digits'])
        self.meander_spacing.SetToolTip("Centre-to-centre spacing of adjacent meander arms, in multiples of the track width (2 = 2W)")
        spacing_sizer.Add(self.meander_spacing, 0)
        options_inner.Add(spacing_sizer, 0, wx.EXPAND | wx.ALL, 3)

        # Time matching option
        time_match_sizer = wx.BoxSizer(wx.HORIZONTAL)
        self.time_matching_check = wx.CheckBox(options_scroll, label="Time matching")
        self.time_matching_check.SetValue(False)
        self.time_matching_check.SetToolTip("Match propagation time instead of length (accounts for layer dielectric)")
        time_match_sizer.Add(self.time_matching_check, 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 10)
        time_match_sizer.Add(wx.StaticText(options_scroll, label="Time tol (ps):"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        r = defaults.PARAM_RANGES['time_match_tolerance']
        self.time_match_tolerance = wx.SpinCtrlDouble(options_scroll, min=r['min'], max=r['max'],
                                                      initial=defaults.TIME_MATCH_TOLERANCE, inc=r['inc'])
        self.time_match_tolerance.SetDigits(r['digits'])
        self.time_match_tolerance.SetToolTip("Acceptable time variance in picoseconds")
        time_match_sizer.Add(self.time_match_tolerance, 0)
        options_inner.Add(time_match_sizer, 0, wx.EXPAND | wx.ALL, 3)

        options_inner.AddSpacer(10)

        # Debug options
        debug_label = wx.StaticText(options_scroll, label="Debug:")
        debug_label.SetFont(debug_label.GetFont().Bold())
        options_inner.Add(debug_label, 0, wx.LEFT | wx.TOP, 3)

        self.debug_lines_check = wx.CheckBox(options_scroll, label="Add debug visualization lines")
        self.debug_lines_check.SetValue(False)
        self.debug_lines_check.SetToolTip("Add routing paths to User layers for debugging")
        options_inner.Add(self.debug_lines_check, 0, wx.ALL, 3)

        self.verbose_check = wx.CheckBox(options_scroll, label="Verbose output")
        self.verbose_check.SetToolTip("Print detailed diagnostic output")
        options_inner.Add(self.verbose_check, 0, wx.ALL, 3)

        self.skip_routing_check = wx.CheckBox(options_scroll, label="Skip routing (swaps only)")
        self.skip_routing_check.SetToolTip("Skip actual routing, only do swaps and write debug info")
        options_inner.Add(self.skip_routing_check, 0, wx.ALL, 3)

        self.debug_memory_check = wx.CheckBox(options_scroll, label="Debug memory")
        self.debug_memory_check.SetToolTip("Print memory usage statistics at key points")
        options_inner.Add(self.debug_memory_check, 0, wx.ALL, 3)

        self.stats_check = wx.CheckBox(options_scroll, label="Show A* statistics")
        self.stats_check.SetToolTip("Show A* search statistics (iterations, expansions, etc.)")
        options_inner.Add(self.stats_check, 0, wx.ALL, 3)

        # Routing movie (#506). Off by default: it snapshots the board after
        # every routing step and renders a movie, which costs a few seconds.
        self.make_movie_check = wx.CheckBox(options_scroll, label="Make routing movie")
        self.make_movie_check.SetValue(False)
        self.make_movie_check.SetToolTip(
            "Record the routing and write a movie next to the board "
            "(<board>_routing.mp4, or .gif without imageio-ffmpeg). Each routing "
            "step gets its own movie; a plan run from the AI tab (Run "
            "Selected Steps / Run All Selected Steps) gets ONE movie covering "
            "all of its steps. New copper flashes white, rips flash red. The "
            "path is printed in green in the Log tab. Same movie as the command "
            "line's make_movie.py.")
        self.make_movie_check.Bind(wx.EVT_CHECKBOX, self._on_make_movie_toggle)
        options_inner.Add(self.make_movie_check, 0, wx.ALL, 3)

        options_scroll.SetSizer(options_inner)
        options_box_sizer.Add(options_scroll, 1, wx.EXPAND)
        return options_box_sizer

    def _create_progress_panel(self, panel):
        """Create the progress panel."""
        progress_box = wx.StaticBox(panel, label="Progress")
        progress_sizer = wx.StaticBoxSizer(progress_box, wx.VERTICAL)

        self.progress_bar = wx.Gauge(panel, range=100)
        progress_sizer.Add(self.progress_bar, 0, wx.EXPAND | wx.ALL, 5)

        self.status_text = wx.StaticText(panel, label="Ready")
        progress_sizer.Add(self.status_text, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)

        return progress_sizer

    def _create_buttons_panel(self, panel):
        """Create the buttons panel."""
        button_sizer = wx.BoxSizer(wx.HORIZONTAL)

        self.route_btn = wx.Button(panel, label="Route")
        self.route_btn.SetToolTip("Start routing selected nets")
        self.route_btn.Bind(wx.EVT_BUTTON, self._on_route)
        button_sizer.Add(self.route_btn, 1, wx.RIGHT, 5)

        self.cancel_btn = wx.Button(panel, label="Close")
        self.cancel_btn.SetToolTip("Close dialog (or cancel routing if in progress)")
        self.cancel_btn.Bind(wx.EVT_BUTTON, self._on_cancel_or_close)
        button_sizer.Add(self.cancel_btn, 1)

        return button_sizer

    def _on_cancel_or_close(self, event):
        """Handle cancel/close button - cancel if routing, otherwise close dialog."""
        if self._routing_thread and self._routing_thread.is_alive():
            # Routing is running - cancel it
            self._cancel_requested = True
            self.status_text.SetLabel("Cancelling...")
            # Also notify the differential tab if it has a routing operation running
            if hasattr(self, 'differential_tab'):
                self.differential_tab.request_cancel()
        else:
            # Not routing - close the modal dialog
            self.EndModal(wx.ID_CANCEL)

    def _create_log_tab(self):
        """Create the Log tab."""
        log_panel = wx.Panel(self.notebook)
        log_sizer = wx.BoxSizer(wx.VERTICAL)

        # Log output text control
        self.log_text = wx.TextCtrl(
            log_panel,
            style=wx.TE_MULTILINE | wx.TE_READONLY | wx.TE_RICH2 | wx.HSCROLL | wx.VSCROLL | wx.ALWAYS_SHOW_SB
        )
        font = wx.Font(10, wx.FONTFAMILY_TELETYPE, wx.FONTSTYLE_NORMAL, wx.FONTWEIGHT_NORMAL)
        self.log_text.SetFont(font)
        log_sizer.Add(self.log_text, 1, wx.EXPAND | wx.ALL, 5)

        # Clear log button
        clear_log_btn = wx.Button(log_panel, label="Clear Log")
        clear_log_btn.SetToolTip("Clear all log output")
        clear_log_btn.Bind(wx.EVT_BUTTON, self._on_clear_log)
        log_sizer.Add(clear_log_btn, 0, wx.ALIGN_RIGHT | wx.RIGHT | wx.BOTTOM, 5)

        log_panel.SetSizer(log_sizer)
        return log_panel

    def _create_fanout_tab(self):
        """Create the Fanout tab for BGA/QFN fanout operations."""
        from .fanout_gui import FanoutTab

        def get_shared_params():
            # Per-layer cost multipliers from the shared Basic-tab control, so
            # the BGA fanout honors them like route/diff do (issue #288):
            # negative = no escape copper on that layer (soon-to-be-plane),
            # weights fill cheaper layers first. Empty/invalid -> [].
            layer_costs = self._selected_layer_costs()
            return {
                'track_width': self._effective_track_width(),
                'clearance': self._effective_clearance(),
                'via_size': self._effective_via_size(),
                'via_drill': self._effective_via_drill(),
                'layers': self._get_selected_layers(),
                'layer_costs': layer_costs,
                # Use the diff tab's EFFECTIVE gap (net-class default or override,
                # fab-floored) -- the same value the diff router / CLI use -- so BGA
                # fanout escapes P/N at the gap the pairs are then routed at (#439:
                # was reading the raw control, which diverged when the gap override
                # was unchecked).
                'diff_pair_gap': self.differential_tab._effective_diff_pair_gap(),
                # Escape stub ends are snapped to this grid so the router gets
                # on-grid terminals (issue #149); use the Basic tab's grid step.
                'grid_step': self.grid_step.GetValue(),
                'fab_tier': self.fab_tier.GetString(self.fab_tier.GetSelection()),
                'fab_overrides_path': self.fab_overrides_path.GetValue().strip(),
                # Edge.Cuts keep-out for QFN escape stubs/vias (issue #288);
                # 0 = fall back to the copper clearance inside generate_qfn_fanout.
                'board_edge_clearance': self._effective_board_edge_clearance(),
                # #489 section 9: the ONE shared "Add teardrops" checkbox now
                # reaches fanout too -- it is the step where a track-to-via
                # teardrop matters most.
                'add_teardrops': self.add_teardrops_check.GetValue(),
            }

        return FanoutTab(
            self.notebook,
            self.pcb_data,
            self.board_filename,
            get_shared_params=get_shared_params,
            on_fanout_complete=self._on_tab_operation_complete,
            get_connectivity_check=self._get_connectivity_check_fn,
            sync_pcb_data_callback=self._sync_pcb_data_from_board
        )

    def _create_planes_tab(self):
        """Create the Planes tab for copper plane creation and repair."""
        from .planes_gui import PlanesTab

        def get_shared_params():
            # Plane zones use the PLANE edge inset (board rule else PLANE_EDGE_CLEARANCE
            # 0.5, fab-floored) -- like the CLI plane scripts -- NOT the signal edge,
            # which would collapse a no-edge-rule board to the 0.2 fab floor.
            edge_clearance = self._effective_plane_edge_clearance()
            # Power nets/widths from the route tab, so plane rip-up re-routes a
            # ripped wide power net at its proper width, not the signal default
            # (matches the CLI passing --power-nets to repair_planes).
            power_nets = _split_net_list(self.power_nets_ctrl.GetValue()) or None
            try:
                power_widths = [float(w) for w in self.power_widths_ctrl.GetValue().split()] or None
            except ValueError:
                power_widths = None
            return {
                'track_width': self._effective_track_width(),
                'clearance': self._effective_clearance(),
                'via_size': self._effective_via_size(),
                'via_drill': self._effective_via_drill(),
                'grid_step': self.grid_step.GetValue(),
                'hole_to_hole_clearance': self._effective_hole_to_hole_clearance(),
                'max_iterations': int(self.max_iterations.GetValue()),
                'max_ripup': int(self.max_ripup.GetValue()),
                'board_edge_clearance': edge_clearance,
                # #381 D6: per-layer cost multipliers from the shared Basic-tab
                # control, so the Planes tab honors --layer-costs like the CLI
                # (route_planes.py) does; empty/invalid -> [] -> engine uses 1.0
                # (or its F.Cu/inner default). Previously dropped entirely.
                'layer_costs': self._selected_layer_costs(),
                # Share the route tab's No-BGA-Zones intent so plane rip-up
                # reroutes match signal routing on BGA boards (issue #88).
                'no_bga_zones_text': self.no_bga_zones_ctrl.GetValue().strip(),
                'power_nets': power_nets,
                'power_nets_widths': power_widths,
                # Shared across all tabs: the single "Fix DRC settings after
                # routing" toggle lives on the Basic tab (issue #160).
                'fix_drc_settings': self.fix_drc_check.GetValue(),
                'keep_thermal': self.keep_thermal_check.GetValue(),
                'clamp_netclasses': self.clearance_check.GetValue(),
                'fab_tier': self.fab_tier.GetString(self.fab_tier.GetSelection()),
                'fab_overrides_path': self.fab_overrides_path.GetValue().strip(),
                # #489 section 9: planes_gui already READ config['add_teardrops']
                # for the create path, but nothing ever supplied it, so the
                # checkbox was dead here. Both plane modes get it now.
                'add_teardrops': self.add_teardrops_check.GetValue(),
                # #424: route_planes.py passes --ripup-blocker-select to
                # create_plane; the shared Basic-tab dropdown must reach the plane
                # engine too or a non-default blocker strategy applies to signal
                # routing only, and plane rip-up silently keeps 'count'.
                'ripup_blocker_select': self.ripup_blocker_select.GetString(
                    self.ripup_blocker_select.GetSelection()),
                # #511 follow-on: both plane call sites read these
                # (planes_gui 'debug_lines'/'verbose') but nothing supplied
                # them, so the shared Basic-tab checkboxes were dead for
                # planes -- found by the same gate sweep the moment its
                # control probe learned the _check suffix.
                'debug_lines': self.debug_lines_check.GetValue(),
                'verbose': self.verbose_check.GetValue(),
            }

        # Deferred: the AI tab is created after the Planes tab, but this
        # is only called on button click.
        get_ai_params = self._ai_params

        return PlanesTab(
            self.notebook,
            self.pcb_data,
            self.board_filename,
            get_shared_params=get_shared_params,
            on_planes_complete=self._on_tab_operation_complete,
            get_connectivity_check=self._get_connectivity_check_fn,
            append_log=self._append_log,
            sync_pcb_data_callback=self._sync_pcb_data_from_board,
            get_ai_params=get_ai_params
        )

    def _create_ai_tab(self):
        """Create the AI tab for running AI skills headless (issue #40)."""
        from .ai_gui import AITab

        return AITab(
            self.notebook,
            self.board_filename,
            log_callback=self._append_log,
            routing_dialog=self,
        )

    def _ai_params(self):
        """The AI tab's backend/model/effort selection, for the other tabs'
        'Ask AI' buttons (passed to ai_gui.run_skill_dialog)."""
        return {
            'backend': self.ai_tab.get_backend_value(),
            'model': self.ai_tab.get_model_value(),
            'effort': self.ai_tab.get_effort_value(),
        }

    def _create_differential_tab(self):
        """Create the Differential tab for differential pair routing."""
        from .differential_gui import DifferentialTab

        def get_shared_params():
            return {
                'track_width': self._effective_track_width(),
                'clearance': self._effective_clearance(),
                'via_size': self._effective_via_size(),
                'via_drill': self._effective_via_drill(),
                # Shared across all tabs: the single "Fix DRC settings after
                # routing" toggle lives on the Basic tab (issue #160).
                'fix_drc_settings': self.fix_drc_check.GetValue(),
            }

        def get_routing_config():
            """Get full routing configuration from the main dialog.

            #511: delegate to the single-ended builder so the Differential tab
            inherits EVERY Basic/Advanced-tab knob and cannot drift again. This
            closure used to hand-maintain a ~30-key subset that had fallen 53
            keys behind _build_routing_config: 25 same-named controls (crossing
            penalty, the MPS ordering toggles, proximity/attraction costs,
            length/time-match tolerances, bus routing, ...) plus a dozen more
            behind differently-named controls (keepout, length_match_groups,
            time_matching, schematic_dir, direction, swappable nets, ...) were
            silently ignored for diff pairs while route_diff.py passed all of
            them on the CLI (#486 coplanar_gap, #489 add_teardrops and #424
            ripup_blocker_select were earlier one-off instances of the same
            drift). Keys the diff tab owns (impedance, diff_pair_width/gap,
            geometry, polarity swaps) still win: the caller merges
            {**this, **DifferentialTab.get_config()} with the diff keys last.
            'nets' is inert here -- pair net names are passed to the engine
            positionally -- so the Basic-tab net selection is not consulted.
            """
            return self._build_routing_config([], self._get_selected_layers())

        def sync_pcb_data():
            """Sync pcb_data from board after routing and clear connectivity cache."""
            self._sync_pcb_data_from_board()
            self._connectivity_cache = {}

        self.differential_tab = DifferentialTab(
            self.notebook,
            self.pcb_data,
            self.board_filename,
            get_shared_params=get_shared_params,
            get_connectivity_check=self._get_connectivity_check_fn,
            get_routing_config=get_routing_config,
            append_log=self._append_log,
            sync_pcb_data_callback=sync_pcb_data,
            # Deferred: the AI tab is created after this tab, but the
            # callback only fires on button click.
            get_ai_params=self._ai_params
        )
        # Wire the Differential tab's "Hide short routes" to the Basic net list:
        # short (deferred) pairs stay visible there under "Hide differential" so
        # they get routed single-ended, and toggling it refreshes that list.
        self.net_panel.set_short_net_filter(
            self.differential_tab.get_short_pair_net_ids,
            self.differential_tab.is_hide_short_enabled)
        self.differential_tab.on_hide_short_changed = lambda: self.net_panel.refresh()
        return self.differential_tab

    def _create_advanced_tab(self):
        """Create the Advanced tab with swappable nets on left, parameters+options on right."""
        panel = wx.Panel(self.notebook)
        main_sizer = wx.BoxSizer(wx.HORIZONTAL)

        # Left side: Swappable nets selection (1:1 ratio with right side)
        left_sizer = self._create_swappable_nets_panel(panel)
        main_sizer.Add(left_sizer, 1, wx.EXPAND | wx.ALL, 5)

        # Right side: Advanced parameters and options
        right_sizer = wx.BoxSizer(wx.VERTICAL)
        right_sizer.Add(self._create_advanced_parameters_panel(panel), 1, wx.EXPAND | wx.BOTTOM, 5)
        right_sizer.Add(self._create_options_panel(panel), 1, wx.EXPAND)
        main_sizer.Add(right_sizer, 1, wx.EXPAND | wx.ALL, 5)

        panel.SetSizer(main_sizer)

        return panel

    def _create_swappable_nets_panel(self, panel):
        """Create the swappable nets selection panel (left side of Advanced tab)."""
        swap_box = wx.StaticBox(panel, label="Swappable Nets")
        swap_sizer = wx.StaticBoxSizer(swap_box, wx.VERTICAL)

        # Use shared NetSelectionPanel
        self.swappable_net_panel = NetSelectionPanel(
            panel, self.pcb_data,
            instructions="Select nets that can swap targets ...",
            hide_label="Hide connected",
            hide_tooltip="Hide nets that are already fully connected",
            show_hide_checkbox=True,
            show_component_filter=True,
            show_component_dropdown=True,
            min_pads_for_dropdown=3
        )
        swap_sizer.Add(self.swappable_net_panel, 1, wx.EXPAND | wx.ALL, 5)

        # Schematic update options
        self.update_schematic_check = wx.CheckBox(panel, label="Update schematic with swaps")
        self.update_schematic_check.SetToolTip("Update .kicad_sch files with pin swap changes")
        self.update_schematic_check.Bind(wx.EVT_CHECKBOX, self._on_update_schematic_changed)
        swap_sizer.Add(self.update_schematic_check, 0, wx.ALL, 5)

        dir_sizer = wx.BoxSizer(wx.HORIZONTAL)
        dir_sizer.Add(wx.StaticText(panel, label="Schematic dir.:"), 0, wx.ALIGN_CENTER_VERTICAL | wx.RIGHT, 5)
        self.schematic_dir_ctrl = wx.TextCtrl(panel)
        self.schematic_dir_ctrl.SetValue(os.path.dirname(self.board_filename))
        self.schematic_dir_ctrl.SetToolTip("Directory containing .kicad_sch files")
        self.schematic_dir_ctrl.Enable(False)
        dir_sizer.Add(self.schematic_dir_ctrl, 1, wx.EXPAND | wx.RIGHT, 5)
        self.browse_schematic_btn = wx.Button(panel, label="...")
        self.browse_schematic_btn.SetToolTip("Browse for schematic directory")
        self.browse_schematic_btn.Bind(wx.EVT_BUTTON, self._on_browse_schematic_dir)
        self.browse_schematic_btn.Enable(False)
        dir_sizer.Add(self.browse_schematic_btn, 0)
        swap_sizer.Add(dir_sizer, 0, wx.EXPAND | wx.LEFT | wx.RIGHT | wx.BOTTOM, 5)

        return swap_sizer

    def _create_advanced_parameters_panel(self, panel):
        """Create the advanced parameters panel (right side of Advanced tab)."""
        param_box = wx.StaticBox(panel, label="Parameters")
        param_box_sizer = wx.StaticBoxSizer(param_box, wx.VERTICAL)
        param_scroll = wx.ScrolledWindow(panel, style=wx.VSCROLL)
        param_scroll.SetScrollRate(0, 10)
        param_inner = wx.BoxSizer(wx.VERTICAL)

        # Advanced parameters grid
        param_grid = wx.FlexGridSizer(cols=2, hgap=10, vgap=5)
        param_grid.AddGrowableCol(1)
        self._add_advanced_parameters(param_scroll, param_grid)
        param_inner.Add(param_grid, 0, wx.EXPAND | wx.ALL, 5)

        param_scroll.SetSizer(param_inner)
        param_box_sizer.Add(param_scroll, 1, wx.EXPAND)
        return param_box_sizer


    def _on_edge_clearance_check(self, event):
        """Handle edge clearance checkbox change."""
        self.board_edge_clearance.Enable(self.edge_clearance_check.GetValue())

    def _on_param_override_check(self, event):
        """Enable/disable the paired geometry spinctrl for whichever override
        checkbox fired (#439). Checking a box == the CLI passing that flag."""
        chk = event.GetEventObject()
        for name in ('track_width', 'clearance', 'via_size', 'via_drill',
                     'hole_to_hole_clearance'):
            if getattr(self, name + '_check', None) is chk:
                getattr(self, name).Enable(chk.GetValue())
                break
        event.Skip()

    def _on_main_tab_changed(self, event):
        """Handle main notebook tab change - validate settings when switching tabs."""
        event.Skip()  # Allow normal tab switching

        # Switching to the Basic tab (index 0): refresh the net list so short
        # (deferred) pairs reflect the current Differential-tab params/toggle.
        if event.GetSelection() == 0 and getattr(self, 'differential_tab', None):
            self.net_panel.refresh()

        # (Planes tab needs no cross-validation since #562: its repair
        # panel is gone -- the route step's finalize owns repair widths.)

    def _on_update_schematic_changed(self, event):
        """Handle update schematic checkbox change."""
        enabled = self.update_schematic_check.GetValue()
        self.schematic_dir_ctrl.Enable(enabled)
        self.browse_schematic_btn.Enable(enabled)

    def _on_browse_schematic_dir(self, event):
        """Browse for schematic directory."""
        default_path = self.schematic_dir_ctrl.GetValue() or os.path.dirname(self.board_filename)
        dlg = wx.DirDialog(self, "Select Schematic Directory",
                           defaultPath=default_path,
                           style=wx.DD_DEFAULT_STYLE | wx.DD_DIR_MUST_EXIST)
        if dlg.ShowModal() == wx.ID_OK:
            self.schematic_dir_ctrl.SetValue(dlg.GetPath())
        dlg.Destroy()

    def _get_swappable_nets(self):
        """Get list of selected swappable net names."""
        return self.swappable_net_panel.get_selected_nets()

    def _parse_length_match_groups(self):
        """Parse length match groups from the text control."""
        text = self.length_match_groups_ctrl.GetValue().strip()
        if not text:
            return None
        # Split by comma to get separate groups, each group has space-separated patterns
        groups = []
        for group_text in text.split(','):
            # _split_net_list, not split(): net names may contain spaces (#493)
            patterns = _split_net_list(group_text)
            if patterns:
                groups.append(patterns)
        return groups if groups else None

    def _load_nets_immediate(self):
        """Load net names from PCB data (fast, no connectivity check)."""
        # The NetSelectionPanel loads nets automatically, but we need to store
        # the list for connectivity checking
        self.all_nets = []

        for net_id, net in self.pcb_data.nets.items():
            name = net.name
            if not name:
                continue
            # Skip unconnected nets
            if name.lower().startswith('unconnected-'):
                continue
            # Skip nets with fewer than 2 pads
            if len(net.pads) < 2:
                continue
            self.all_nets.append((name, net_id))

        # Sort by name
        self.all_nets.sort(key=lambda x: x[0].lower())

        # Update the net panel's all_nets list to match our filtered list
        self.net_panel.all_nets = self.all_nets
        self.net_panel.refresh()
        self.status_text.SetLabel("Loading...")

    def _deferred_init(self):
        """Run after dialog is shown: sync board and check connectivity."""
        # Set up connectivity check function on the net panel
        # This function returns True if a net should be hidden (i.e., is connected)
        def is_connected(net_id):
            if net_id in self._connectivity_cache:
                return self._connectivity_cache[net_id]
            is_conn = self._is_net_connected(net_id)
            self._connectivity_cache[net_id] = is_conn
            return is_conn

        self.net_panel.set_check_function(is_connected)
        self.swappable_net_panel.set_check_function(is_connected)
        self.differential_tab.pair_panel.set_check_function(is_connected)

        # Restore saved settings if available, otherwise use defaults
        if self._saved_settings:
            restore_dialog_settings(self, self._saved_settings)
        else:
            # Enable hide checkbox by default on Basic tab only
            if self.net_panel.hide_check:
                self.net_panel.hide_check.SetValue(True)

        # Pre-check nets the user selected in the PCB editor. This overrides any
        # restored/default net selection so the KiCad selection takes priority.
        self._apply_preselected_nets()

        # Apply board-level minimum constraints if checkbox is enabled
        self._apply_board_minimums_to_controls()

        # Do initial refresh
        self.refresh_from_board()

    def _apply_preselected_nets(self):
        """Pre-check the nets the user selected in the PCB editor.

        Applies the selection to every net-based tab (Basic routing, Fanout,
        Planes) and to differential pairs whose nets are selected. Does nothing
        when no nets were selected, leaving restored/default behaviour intact.
        """
        if not self._preselected_nets:
            return

        names = self._preselected_nets

        # Show selected nets even if they are already routed, so the user can
        # see exactly what was carried over from their KiCad selection.
        if self.net_panel.hide_check:
            self.net_panel.hide_check.SetValue(False)

        self.net_panel.set_selected_nets(names)
        self.fanout_tab.net_panel.set_selected_nets(names)
        self.planes_tab.net_panel.set_selected_nets(names)
        self.differential_tab.pair_panel.set_selected_pairs_by_net(names)

    def refresh_from_board(self):
        """Refresh pcb_data from the current board state.

        Call this when re-showing the dialog after the user has made
        changes in KiCad.
        """
        # Save current selections from all net panels BEFORE any refresh
        # Use _checked_nets directly to preserve restored settings (don't sync from visible items)
        saved_selections = {
            'net_panel': set(self.net_panel._checked_nets),
            'swappable_net_panel': set(self.swappable_net_panel._checked_nets),
            'fanout_tab': set(self.fanout_tab.net_panel._checked_nets),
            'planes_tab': set(self.planes_tab.net_panel._checked_nets),
        }
        # DiffPairSelectionPanel uses _checked_pairs, not _checked_nets
        saved_diff_pairs = set(self.differential_tab.pair_panel._checked_pairs)

        # Sync pcb_data with pcbnew's in-memory board state
        # Skip on initial load since pcb_data was built directly from pcbnew
        if self._initial_load:
            self._initial_load = False
        else:
            self.status_text.SetLabel("Syncing with board...")
            wx.Yield()
            self._sync_pcb_data_from_board()

        # Run connectivity check with progress
        self._check_connectivity_with_progress()

        # Restore selections to each panel before refreshing
        self.net_panel._checked_nets = saved_selections['net_panel']
        self.swappable_net_panel._checked_nets = saved_selections['swappable_net_panel']
        self.fanout_tab.net_panel._checked_nets = saved_selections['fanout_tab']
        self.planes_tab.net_panel._checked_nets = saved_selections['planes_tab']
        self.differential_tab.pair_panel._checked_pairs = saved_diff_pairs

        # Refresh all net panels (skip syncing from visible to preserve restored selections)
        self.net_panel.refresh(sync_from_visible=False)
        self.swappable_net_panel.refresh(sync_from_visible=False)
        self.differential_tab.pair_panel.refresh(sync_from_visible=False)
        self.fanout_tab.net_panel.refresh(sync_from_visible=False)
        self.planes_tab.net_panel.refresh(sync_from_visible=False)

        # Update status bar and progress text
        self._update_status_bar()

        # Log per-net health warnings (bad outline parse / off-board pads / <2
        # on-board pads) to the LOG TAB at load time. stdout isn't redirected to
        # the log here (only during routing), so write via _append_log directly;
        # \033[93m renders yellow.
        try:
            from net_queries import log_net_health
            def _log(msg):
                self._append_log("\033[93m" + msg + "\033[0m\n")
            nu, no, npars = log_net_health(self.pcb_data, log=_log)
            if nu or no or npars:
                _log(f"[NET HEALTH] {nu} unroutable (<2 on-board pads), "
                     f"{no} net(s) with off-board pads, {npars} parse warning(s).")
        except Exception as _e:
            self._append_log(f"[NET HEALTH] check failed: {_e}\n")

    def _is_net_connected(self, net_id):
        """Check if a net is already fully connected using check_connected logic."""
        try:
            from check_connected import check_net_connectivity

            net_segments = [s for s in self.pcb_data.segments if s.net_id == net_id]
            net_vias = [v for v in self.pcb_data.vias if v.net_id == net_id]
            net_pads = self.pcb_data.pads_by_net.get(net_id, [])
            net_zones = [z for z in self.pcb_data.zones if z.net_id == net_id]

            # Need at least 2 pads to be a routable net
            if len(net_pads) < 2:
                return True  # Nothing to route

            # No segments means not connected (unless connected via zones)
            if len(net_segments) == 0 and len(net_zones) == 0:
                return False

            # pcb_data enables the fill-COMPONENT-aware zone credit
            # (validator parity): without it a pinched pour island graded
            # plane-connected here while KiCad DRC showed it open, so
            # "hide connected" hid a genuinely broken net.
            result = check_net_connectivity(
                net_id, net_segments, net_vias, net_pads, net_zones,
                tolerance=0.02, pcb_data=self.pcb_data
            )

            return result['connected']
        except Exception as e:
            import traceback
            traceback.print_exc()
            return False

    def _check_connectivity_with_progress(self):
        """Check connectivity for all nets with progress display."""
        # Check which nets need connectivity check (not in cache)
        uncached_nets = [(name, net_id) for name, net_id in self.all_nets
                         if net_id not in self._connectivity_cache]

        if uncached_nets:
            self.progress_bar.SetRange(len(uncached_nets))
            self.progress_bar.SetValue(0)

            for i, (name, net_id) in enumerate(uncached_nets):
                is_connected = self._is_net_connected(net_id)
                self._connectivity_cache[net_id] = is_connected

                self.progress_bar.SetValue(i + 1)
                self.status_text.SetLabel(f"Checking connectivity... {i + 1}/{len(uncached_nets)}")
                wx.Yield()

        # Note: Don't refresh here - caller (refresh_from_board) will do it
        # after restoring selections
        self.progress_bar.SetValue(0)

    def _update_net_list(self):
        """Update the net list - delegates to panel and updates status."""
        self.net_panel.refresh()
        self.swappable_net_panel.refresh()
        self.differential_tab.pair_panel.refresh()
        self.fanout_tab.net_panel.refresh()
        self.planes_tab.net_panel.refresh()

        # Update status bar and progress text
        self._update_status_bar()

    def _update_status_bar(self):
        """Update the status bar with net counts."""
        total_nets = len(self.all_nets)
        connected_count = sum(1 for v in self._connectivity_cache.values() if v)
        remaining = total_nets - connected_count
        selected_count = len(self.net_panel.get_selected_nets())

        # Update bottom status bar
        self.status_bar.SetLabel(
            f"Total: {total_nets}  |  Connected: {connected_count}  |  "
            f"To route: {remaining}  |  Selected: {selected_count}"
        )

        # Update progress text (simplified)
        self.status_text.SetLabel(f"Ready - {selected_count} nets selected to route")

    def _on_clear_log(self, event):
        """Clear the log text control."""
        self.log_text.Clear()

    def _get_connectivity_check_fn(self):
        """Return a function to check if a net is connected.

        Used as callback by Fanout, Planes, and Differential tabs.
        """
        def is_connected(net_id):
            if net_id in self._connectivity_cache:
                return self._connectivity_cache[net_id]
            is_conn = self._is_net_connected(net_id)
            self._connectivity_cache[net_id] = is_conn
            return is_conn
        return is_connected

    def _on_tab_operation_complete(self, affected_nets=None):
        """Handle completion of tab operations (fanout, planes, etc.).

        Syncs board data, refreshes connectivity cache, and updates net lists.
        If `affected_nets` is provided, those nets' cached connectivity
        results are dropped first so they're re-checked (otherwise nets that
        were "disconnected" before the operation would stay flagged that way
        in the cache even after the operation connected them).
        """
        self._sync_pcb_data_from_board()
        if affected_nets:
            name_to_id = {net.name: net.net_id for net in self.pcb_data.nets.values()}
            for name in affected_nets:
                net_id = name_to_id.get(name)
                if net_id is not None:
                    self._connectivity_cache.pop(net_id, None)
        self._check_connectivity_with_progress()
        self._update_net_list()

    def _reset_all_settings(self):
        """Reset all settings to defaults, clear log, and uncheck all selections."""
        # Clear log
        self.log_text.Clear()

        # Clear all net selections
        self.net_panel._checked_nets = set()
        self.swappable_net_panel._checked_nets = set()
        self.fanout_tab.net_panel._checked_nets = set()
        self.planes_tab.net_panel._checked_nets = set()
        self.differential_tab.pair_panel._checked_pairs = set()

        # An explicit "reset settings" DOES turn movie recording off (unlike
        # the per-step parameter reset, which must leave it alone -- see
        # reset_params_to_defaults).
        self.make_movie_check.SetValue(False)
        self.movie_recorder.cleanup()

        self.reset_params_to_defaults()

    def reset_params_to_defaults(self):
        """Reset every routing PARAMETER control to routing_defaults --
        selections and the log untouched. The plan executor calls this
        before each step (when 'reset other options' is on) so a plan run
        starts from CLI-default-equivalent state instead of inheriting
        stale session tweaks (the add_gnd_vias leak, generalized)."""
        # Tab option panels too -- these are OUTSIDE the dialog's own
        # controls and were the actual leak vector (planes add_gnd_vias).
        # Best-effort with hasattr guards: a missing control just keeps its
        # state (and the plan-side absent-means-off rules still apply).
        try:
            _po = self.planes_tab.create_options
            if hasattr(_po, 'thermal_relief'):
                _po.thermal_relief.SetValue(False)
            if hasattr(_po, 'thermal_vias'):
                import routing_defaults as _rd
                _po.thermal_vias.SetValue(_rd.THERMAL_VIAS)
            if hasattr(_po, 'zone_clearance_check'):
                # Default = unchecked = follow routed clearance (the
                # ottercast sealed-field fix); a plan's explicit
                # zone_clearance param checks it (override convention).
                _po.zone_clearance_check.SetValue(False)
                if hasattr(_po, 'zone_clearance'):
                    _po.zone_clearance.SetValue(defaults.PLANE_ZONE_CLEARANCE)
                    _po.zone_clearance.Enable(False)
            if hasattr(_po, 'stitch_vias'):
                _po.stitch_vias.SetValue(False)
            if hasattr(_po, 'stitch_pitch'):
                _po.stitch_pitch.SetValue(defaults.STITCH_PITCH)
            if hasattr(_po, 'stitch_edge_fence'):
                _po.stitch_edge_fence.SetValue(False)
            if hasattr(_po, 'stitch_fence_pitch'):
                _po.stitch_fence_pitch.SetValue(0.0)  # 0 = follow lattice pitch
            if hasattr(_po, 'stitch_inset'):
                _po.stitch_inset.SetValue(0.0)        # 0 = auto
            if hasattr(_po, 'stitch_max_freq'):
                _po.stitch_max_freq.SetValue(0.0)     # 0 = off
            if hasattr(_po, 'add_gnd_vias_check'):
                _po.add_gnd_vias_check.SetValue(False)
            if hasattr(_po, 'gnd_via_distance'):
                _po.gnd_via_distance.SetValue(defaults.GND_VIA_DISTANCE)
            if hasattr(_po, 'gnd_via_net'):
                _po.gnd_via_net.SetValue(defaults.GND_VIA_NET)
            if hasattr(_po, 'via_in_pad_check'):
                # Default ON = same_net_pad_clearance -1.0 (CLI parity, big plane
                # connectivity win; see CreatePlanesOptionsPanel #362).
                _po.via_in_pad_check.SetValue(True)
                if hasattr(_po, 'same_net_pad_clearance'):
                    _po.same_net_pad_clearance.Enable(False)
        except Exception:
            pass
        try:
            _ft = self.fanout_tab
            # The option controls live on the bga_options / qfn_options
            # PANELS, not the tab -- a tab-only getattr silently skipped
            # every one of these resets (found wiring #424's plane_drop).
            _holders = [h for h in (_ft, getattr(_ft, 'bga_options', None),
                                    getattr(_ft, 'qfn_options', None))
                        if h is not None]

            def _fctl(name):
                for _h in _holders:
                    _c = getattr(_h, name, None)
                    if _c is not None:
                        return _c
                return None

            for _name, _val in (
                    ('exit_margin', defaults.BGA_EXIT_MARGIN),
                    ('extension', defaults.QFN_EXTENSION),
                    ('differential_check', False),
                    ('force_escape', False),
                    ('rebalance_escape', False),
                    ('check_previous', False),
                    ('no_inner_top', False),
                    ('optimize_caps', False),
                    ('cap_allow_rotation', True),
                    ('cap_max_passes', 30),
                    ('underpad_escape', False),
                    ('allow_via_in_pad', False),
                    ('plane_drop', True),    # #424 drops: default ON
                    ('plane_net_layers_ctrl', '')):  # future-pour decl, empty
                _ctl = _fctl(_name)
                if _ctl is not None:
                    try:
                        _ctl.SetValue(_val)
                    except Exception:
                        pass
            for _name in ('escape_method_choice',):
                _ctl = _fctl(_name)
                if _ctl is not None:
                    try:
                        _ctl.SetSelection(0)
                    except Exception:
                        pass
            # #381 D7: QFN width/clearance controls live on qfn_options; reset
            # them to the QFN-tuned defaults so a plan step doesn't inherit a
            # prior step's value (the plan executor resets through here).
            _qo = getattr(_ft, 'qfn_options', None)
            if _qo is not None:
                for _n, _v in (('qfn_track_width', defaults.QFN_TRACK_WIDTH),
                               ('qfn_clearance', defaults.QFN_CLEARANCE)):
                    _ctl = getattr(_qo, _n, None)
                    if _ctl is not None:
                        try:
                            _ctl.SetValue(_v)
                        except Exception:
                            pass
        except Exception:
            pass
        try:
            _dt = self.differential_tab
            if hasattr(_dt, 'diff_pair_width'):
                _dt.diff_pair_width.SetValue(defaults.DIFF_PAIR_WIDTH)
            if hasattr(_dt, 'diff_pair_gap'):
                _dt.diff_pair_gap.SetValue(defaults.DIFF_PAIR_GAP)
        except Exception:
            pass
        # Reset basic parameters to defaults
        self.track_width.SetValue(defaults.TRACK_WIDTH)
        self.clearance.SetValue(defaults.CLEARANCE)
        self.via_size.SetValue(defaults.VIA_SIZE)
        self.via_drill.SetValue(defaults.VIA_DRILL)
        self.grid_step.SetValue(defaults.GRID_STEP)
        self.via_cost.SetValue(defaults.VIA_COST)
        self.max_ripup.SetValue(defaults.MAX_RIPUP)
        self.ripup_abandon_metric.SetStringSelection(defaults.RIPUP_ABANDON_METRIC)
        self.ripup_blocker_select.SetStringSelection(defaults.RIPUP_BLOCKER_SELECT)

        # Reset layer selections (select all copper layers by default)
        for layer, cb in self.layer_checks.items():
            cb.SetValue(True)

        # Reset basic options
        self.enable_layer_switch.SetValue(True)
        self.move_text_check.SetValue(True)
        self.add_teardrops_check.SetValue(False)  # match creation default + CLI (--add-teardrops off)
        self.power_nets_ctrl.SetValue("")
        self.power_widths_ctrl.SetValue("")
        self.no_bga_zones_ctrl.SetValue("")  # empty == CLI default (None: keep BGA zones)
        self.rip_existing_nets_ctrl.SetValue("")
        self.force_reroute.SetValue(False)  # match creation default + CLI (store_true)
        self.layer_costs_ctrl.SetValue("")

        # Reset advanced parameters
        self.impedance_check.SetValue(False)
        self.impedance_value.SetValue(50.0)
        self.coplanar_gap.SetValue(defaults.COPLANAR_GAP)
        self.coplanar_nets_ctrl.SetValue("")
        self.max_iterations.SetValue(defaults.MAX_ITERATIONS)
        self.max_probe_iterations.SetValue(defaults.MAX_PROBE_ITERATIONS)
        self.heuristic_weight.SetValue(defaults.HEURISTIC_WEIGHT)
        self.proximity_heuristic_factor.SetValue(defaults.PROXIMITY_HEURISTIC_FACTOR)
        self.turn_cost.SetValue(defaults.TURN_COST)
        self.direction_preference_cost.SetValue(defaults.DIRECTION_PREFERENCE_COST)
        self.ordering_strategy.SetSelection(0)
        self.fab_tier.SetSelection(0)
        self.fab_overrides_path.SetValue("")
        self.bga_proximity_radius.SetValue(defaults.BGA_PROXIMITY_RADIUS)
        self.bga_proximity_cost.SetValue(defaults.BGA_PROXIMITY_COST)
        self.stub_proximity_radius.SetValue(defaults.STUB_PROXIMITY_RADIUS)
        self.stub_proximity_cost.SetValue(defaults.STUB_PROXIMITY_COST)
        self.neckdown_length.SetValue(defaults.NECKDOWN_LENGTH)
        self.neckdown_taper_length.SetValue(defaults.NECKDOWN_TAPER_LENGTH)
        self.power_tap_neckdown_check.SetValue(True)
        self.via_proximity_cost.SetValue(defaults.VIA_PROXIMITY_COST)
        self.track_proximity_distance.SetValue(defaults.TRACK_PROXIMITY_DISTANCE)
        self.track_proximity_cost.SetValue(defaults.TRACK_PROXIMITY_COST)
        self.vertical_attraction_radius.SetValue(defaults.VERTICAL_ATTRACTION_RADIUS)
        self.vertical_attraction_cost.SetValue(defaults.VERTICAL_ATTRACTION_COST)
        self.ripped_route_avoidance_radius.SetValue(defaults.RIPPED_ROUTE_AVOIDANCE_RADIUS)
        self.ripped_route_avoidance_cost.SetValue(defaults.RIPPED_ROUTE_AVOIDANCE_COST)
        self.routing_clearance_margin.SetValue(defaults.ROUTING_CLEARANCE_MARGIN)
        self.hole_to_hole_clearance.SetValue(defaults.HOLE_TO_HOLE_CLEARANCE)
        self.edge_clearance_check.SetValue(False)
        self.board_edge_clearance.SetValue(defaults.BOARD_EDGE_CLEARANCE)
        self.board_edge_clearance.Enable(False)
        # #439: every geometry-floor override starts UNCHECKED (= use the board's
        # own value) with its spinctrl disabled, matching a fresh CLI invocation.
        # (The edge control's checkbox attr is edge_clearance_check, reset above.)
        for _name in ('track_width', 'clearance', 'via_size', 'via_drill',
                      'hole_to_hole_clearance'):
            getattr(self, _name + '_check').SetValue(False)
            getattr(self, _name).Enable(False)
        self.direction_choice.SetSelection(0)

        # Reset advanced options. mps_*/can_swap default OFF to match the checkbox
        # creation state, the CLI (--mps-*/--can-swap-to-top-layer are store_true),
        # and the engine signature (batch_route defaults all False).
        self.mps_reverse_rounds.SetValue(False)
        self.mps_layer_swap.SetValue(False)
        self.keep_input_copper.SetValue(False)
        self.mps_segment_intersection.SetValue(False)
        self.bus_enabled.SetValue(False)
        self.bus_detection_radius.SetValue(defaults.BUS_DETECTION_RADIUS)
        self.bus_attraction_radius.SetValue(defaults.BUS_ATTRACTION_RADIUS)
        self.bus_attraction_bonus.SetValue(defaults.BUS_ATTRACTION_BONUS)
        self.bus_min_nets.SetValue(defaults.BUS_MIN_NETS)
        self.no_crossing_layer_check.SetValue(False)
        self.can_swap_to_top.SetValue(False)  # match creation default + CLI/engine (off)
        self.crossing_penalty.SetValue(defaults.CROSSING_PENALTY)
        self.length_match_groups_ctrl.SetValue("")
        self.length_match_tolerance.SetValue(defaults.LENGTH_MATCH_TOLERANCE)
        self.meander_amplitude.SetValue(defaults.MEANDER_AMPLITUDE)
        self.meander_spacing.SetValue(defaults.MEANDER_SPACING)
        self.time_matching_check.SetValue(defaults.TIME_MATCHING)
        self.time_match_tolerance.SetValue(defaults.TIME_MATCH_TOLERANCE)
        self.debug_lines_check.SetValue(False)
        self.verbose_check.SetValue(False)
        self.skip_routing_check.SetValue(False)
        self.debug_memory_check.SetValue(False)
        self.stats_check.SetValue(False)
        # NOT reset: make_movie_check (#506). The plan executor resets params
        # before EVERY step, so resetting the movie box here would untick the
        # user's choice mid-plan and abandon the run's movie halfway. It is a
        # session output preference, not a routing parameter -- nothing about
        # the routed copper depends on it.

        # Reset hide checkboxes
        if self.net_panel.hide_check:
            self.net_panel.hide_check.SetValue(True)
        if self.net_panel.hide_diff_check:
            self.net_panel.hide_diff_check.SetValue(False)
        if self.swappable_net_panel.hide_check:
            self.swappable_net_panel.hide_check.SetValue(False)
        if self.differential_tab.pair_panel.hide_check:
            self.differential_tab.pair_panel.hide_check.SetValue(False)
        if self.fanout_tab.net_panel.hide_check:
            self.fanout_tab.net_panel.hide_check.SetValue(False)
        if self.planes_tab.net_panel.hide_check:
            self.planes_tab.net_panel.hide_check.SetValue(False)

        # Reset filters
        self.net_panel.filter_ctrl.SetValue("")
        self.swappable_net_panel.filter_ctrl.SetValue("")
        self.differential_tab.pair_panel.filter_ctrl.SetValue("")
        self.fanout_tab.net_panel.filter_ctrl.SetValue("")
        self.planes_tab.net_panel.filter_ctrl.SetValue("")

        # Reset AI tab backend/model/effort to defaults
        self.ai_tab.set_backend_value(None)
        self.ai_tab.set_model_value(None)
        self.ai_tab.set_effort_value(None)

        # Reset component dropdowns to "All"
        if self.net_panel.component_dropdown:
            self.net_panel.component_dropdown.SetSelection(0)
            self.net_panel._component_filter_value = ""
        if self.swappable_net_panel.component_dropdown:
            self.swappable_net_panel.component_dropdown.SetSelection(0)
            self.swappable_net_panel._component_filter_value = ""
        if self.differential_tab.pair_panel.component_dropdown:
            self.differential_tab.pair_panel.component_dropdown.SetSelection(0)
            self.differential_tab.pair_panel._component_filter_value = ""
        if self.fanout_tab.net_panel.component_dropdown:
            self.fanout_tab.net_panel.component_dropdown.SetSelection(0)
            self.fanout_tab.net_panel._component_filter_value = ""
        if self.planes_tab.net_panel.component_dropdown:
            self.planes_tab.net_panel.component_dropdown.SetSelection(0)
            self.planes_tab.net_panel._component_filter_value = ""

        # Reset differential tab
        self.differential_tab.diff_pair_width_check.SetValue(False)
        self.differential_tab.diff_pair_width.SetValue(defaults.DIFF_PAIR_WIDTH)
        self.differential_tab.diff_pair_width.Enable(False)
        self.differential_tab.diff_pair_gap_check.SetValue(False)
        self.differential_tab.diff_pair_gap.SetValue(defaults.DIFF_PAIR_GAP)
        self.differential_tab.diff_pair_gap.Enable(False)
        self.differential_tab.min_turning_radius.SetValue(defaults.DIFF_PAIR_MIN_TURNING_RADIUS)
        self.differential_tab.max_setback_angle.SetValue(defaults.DIFF_PAIR_MAX_SETBACK_ANGLE)
        self.differential_tab.max_turn_angle.SetValue(defaults.DIFF_PAIR_MAX_TURN_ANGLE)
        self.differential_tab.chamfer_extra.SetValue(defaults.DIFF_PAIR_CHAMFER_EXTRA)
        # #381 D3: reset to EMPTY (deny all swaps) to match tab creation and the
        # CLI deny-by-default (#279); '*' here silently widened plan-replay swaps.
        self.differential_tab.polarity_swap_nets_text.SetValue("")
        # #381 D2: diff GND return vias default ON, matching tab creation
        # (differential_gui.py) and the CLI (route_diff.py's negative flag
        # --no-gnd-vias defaults gnd_via_enabled True). Resetting to False here
        # meant every plan-replayed diff step routed without GND return vias --
        # a silent SI regression, since a manifest records nothing when ON.
        self.differential_tab.gnd_via_check.SetValue(True)
        self.differential_tab.intra_match_check.SetValue(False)
        self.differential_tab.ac_couple_check.SetValue(False)

        # Reset fanout tab
        self.fanout_tab.fanout_type.SetSelection(0)
        self.fanout_tab._on_type_changed(None)

        # Reset planes tab
        self.planes_tab.assignment_panel.clear_assignments()

        # Reset transparency to default
        self.SetTransparent(240)
        self.about_tab.transparency_slider.SetValue(240)

        # Refresh all net panels
        self._update_net_list()

        # Update status
        self.status_text.SetLabel("Settings reset to defaults")

    def _append_log(self, text):
        """Append text to the log (thread-safe via CallAfter)."""
        wx.CallAfter(self._do_append_log, text)

    def _do_append_log(self, text):
        """Actually append text to log (must be called on main thread).

        Parses ANSI escape codes and applies corresponding colors.
        """
        # ANSI color code mapping
        ansi_colors = {
            '\033[91m': wx.Colour(220, 50, 50),    # RED
            '\033[92m': wx.Colour(50, 180, 50),    # GREEN
            '\033[93m': wx.Colour(200, 180, 50),   # YELLOW
            '\033[0m': None,                        # RESET
        }

        # Pattern to match ANSI escape codes
        ansi_pattern = re.compile(r'\033\[\d+m')

        # Split text by ANSI codes while keeping track of positions
        parts = ansi_pattern.split(text)
        codes = ansi_pattern.findall(text)

        current_color = None
        for i, part in enumerate(parts):
            if part:
                start_pos = self.log_text.GetLastPosition()
                self.log_text.AppendText(part)
                if current_color:
                    end_pos = self.log_text.GetLastPosition()
                    attr = wx.TextAttr(current_color)
                    self.log_text.SetStyle(start_pos, end_pos, attr)
            # Update color for next part
            if i < len(codes):
                current_color = ansi_colors.get(codes[i])

    def _get_selected_nets(self):
        """Get list of selected net names, including those checked but currently filtered out."""
        return self.net_panel.get_selected_nets()

    def _get_selected_layers(self):
        """Get list of selected layers."""
        return [layer for layer, cb in self.layer_checks.items() if cb.GetValue()]

    def _selected_layer_costs(self):
        """Layer costs from the shared Basic-tab control, aligned to the
        SELECTED layers (what batch_route/generate_bga_fanout expect).

        The control's documented order is the board's full copper stack (its
        defaults are generated per copper layer, and AI plans emit costs
        "in board layer order") -- but the engines want one value per selected
        layer. With a subset of layers checked on a >N-layer board, the raw
        list crashed the fanout ("--layer-costs needs one value per layer").
        Translate by name: board-ordered input is subset to the checked
        layers; input already matching the selected count passes through.
        Anything else is returned raw so the engine's clear error stands.
        Empty/invalid -> [].
        """
        lc_text = self.layer_costs_ctrl.GetValue().strip()
        try:
            costs = [float(c) for c in lc_text.split()] if lc_text else []
        except ValueError:
            return []
        if not costs:
            return []
        selected = self._get_selected_layers()
        if len(costs) == len(selected):
            return costs
        copper = self.pcb_data.board_info.copper_layers
        if len(costs) == len(copper):
            by_layer = dict(zip(copper, costs))
            return [by_layer[l] for l in selected if l in by_layer]
        return costs

    def _validate_routing_inputs(self):
        """Validate routing inputs before starting.

        Returns:
            tuple: (selected_nets, selected_layers) if valid, (None, None) if invalid
        """
        selected_nets = self._get_selected_nets()
        if not selected_nets:
            wx.MessageBox(
                "Please select at least one net to route.",
                "No Nets Selected",
                wx.OK | wx.ICON_WARNING
            )
            return None, None

        selected_layers = self._get_selected_layers()
        if not selected_layers:
            wx.MessageBox(
                "Please select at least one layer.",
                "No Layers Selected",
                wx.OK | wx.ICON_WARNING
            )
            return None, None

        return selected_nets, selected_layers

    @staticmethod
    def _safe_float(text, default):
        """Parse a float from a text control, falling back to default."""
        try:
            return float(str(text).strip())
        except (ValueError, TypeError):
            return default

    def _build_routing_config(self, selected_nets, selected_layers):
        """Build the routing configuration dictionary from UI controls.

        Args:
            selected_nets: List of selected net names
            selected_layers: List of selected layer names

        Returns:
            dict: Configuration for the router
        """
        config = {
            'nets': selected_nets,
            'layers': selected_layers,
            # Basic parameters
            'track_width': self._effective_track_width(),
            'clearance': self._effective_clearance(),
            'via_size': self._effective_via_size(),
            'via_drill': self._effective_via_drill(),
            'grid_step': self.grid_step.GetValue(),
            'via_cost': self.via_cost.GetValue(),
            'move_copper_text': self.move_text_check.GetValue(),
            'debug_lines': self.debug_lines_check.GetValue(),
            # Impedance routing
            'impedance': self.impedance_value.GetValue() if self.impedance_check.GetValue() else None,
            'coplanar_gap': self.coplanar_gap.GetValue(),
            'coplanar_nets': _split_net_list(self.coplanar_nets_ctrl.GetValue()) or None,
            # Advanced parameters
            'max_iterations': self.max_iterations.GetValue(),
            'max_probe_iterations': self.max_probe_iterations.GetValue(),
            'heuristic_weight': self.heuristic_weight.GetValue(),
            'proximity_heuristic_factor': self.proximity_heuristic_factor.GetValue(),
            'turn_cost': self.turn_cost.GetValue(),
            'direction_preference_cost': self.direction_preference_cost.GetValue(),
            'max_ripup': self.max_ripup.GetValue(),
            'ripup_abandon_metric': self.ripup_abandon_metric.GetString(
                self.ripup_abandon_metric.GetSelection()),
            'ripup_blocker_select': self.ripup_blocker_select.GetString(
                self.ripup_blocker_select.GetSelection()),
            'ordering_strategy': self.ordering_strategy.GetString(self.ordering_strategy.GetSelection()),
            'fab_tier': self.fab_tier.GetString(self.fab_tier.GetSelection()),
            'fab_overrides_path': self.fab_overrides_path.GetValue().strip(),
            'stub_proximity_radius': self.stub_proximity_radius.GetValue(),
            'stub_proximity_cost': self.stub_proximity_cost.GetValue(),
            'power_tap_neckdown': self.power_tap_neckdown_check.GetValue(),
            'neckdown_length': self.neckdown_length.GetValue(),
            'neckdown_taper_length': self.neckdown_taper_length.GetValue(),
            'via_proximity_cost': self.via_proximity_cost.GetValue(),
            'track_proximity_distance': self.track_proximity_distance.GetValue(),
            'track_proximity_cost': self.track_proximity_cost.GetValue(),
            'bga_proximity_radius': self.bga_proximity_radius.GetValue(),
            'bga_proximity_cost': self.bga_proximity_cost.GetValue(),
            'vertical_attraction_radius': self.vertical_attraction_radius.GetValue(),
            'vertical_attraction_cost': self.vertical_attraction_cost.GetValue(),
            'ripped_route_avoidance_radius': self.ripped_route_avoidance_radius.GetValue(),
            'ripped_route_avoidance_cost': self.ripped_route_avoidance_cost.GetValue(),
            'crossing_penalty': self.crossing_penalty.GetValue(),
            'routing_clearance_margin': self.routing_clearance_margin.GetValue(),
            'hole_to_hole_clearance': self._effective_hole_to_hole_clearance(),
            'board_edge_clearance': self._effective_board_edge_clearance(),
            'enable_layer_switch': self.enable_layer_switch.GetValue(),
            # Direction
            'direction': ['forward', 'backward'][self.direction_choice.GetSelection() - 1] if self.direction_choice.GetSelection() > 0 else None,
            # Options
            'add_teardrops': self.add_teardrops_check.GetValue(),
            'fix_drc_settings': self.fix_drc_check.GetValue(),
            'keep_thermal': self.keep_thermal_check.GetValue(),
            'clamp_netclasses': self.clearance_check.GetValue(),
            # Guide corridor (issue #7)
            'guide_corridor_enabled': self.guide_corridor_check.GetValue(),
            'guide_corridor_layer': self.guide_corridor_layer_ctrl.GetValue().strip() or defaults.GUIDE_CORRIDOR_LAYER,
            'guide_corridor_spacing': self._safe_float(self.guide_corridor_spacing_ctrl.GetValue(), defaults.GUIDE_CORRIDOR_SPACING),
            # Keepout zone (issue #27)
            'keepout_enabled': self.keepout_check.GetValue(),
            'keepout_layer': self.keepout_layer_ctrl.GetValue().strip() or defaults.KEEPOUT_LAYER,
            # Clear User-layer graphics after a successful route (plugin-only)
            'clear_guide_layer': self.clear_guide_layer_check.GetValue(),
            'clear_keepout_layer': self.clear_keepout_layer_check.GetValue(),
            'verbose': self.verbose_check.GetValue(),
            'skip_routing': self.skip_routing_check.GetValue(),
            'debug_memory': self.debug_memory_check.GetValue(),
            'stats': self.stats_check.GetValue(),
            # MPS options
            'mps_reverse_rounds': self.mps_reverse_rounds.GetValue(),
            'mps_layer_swap': self.mps_layer_swap.GetValue(),
            'keep_input_copper': self.keep_input_copper.GetValue(),
            'force_reroute': self.force_reroute.GetValue(),
            'mps_segment_intersection': self.mps_segment_intersection.GetValue(),
            # Bus routing options
            'bus_enabled': self.bus_enabled.GetValue(),
            'bus_detection_radius': self.bus_detection_radius.GetValue(),
            'bus_attraction_radius': self.bus_attraction_radius.GetValue(),
            'bus_attraction_bonus': self.bus_attraction_bonus.GetValue(),
            'bus_min_nets': self.bus_min_nets.GetValue(),
            # Crossing/swap options
            'no_crossing_layer_check': self.no_crossing_layer_check.GetValue(),
            'can_swap_to_top_layer': self.can_swap_to_top.GetValue(),
            # Swappable nets
            'swappable_nets': self._get_swappable_nets() or None,
            'schematic_dir': self.schematic_dir_ctrl.GetValue() if self.update_schematic_check.GetValue() else None,
            # Length matching
            'length_match_groups': self._parse_length_match_groups(),
            'length_match_tolerance': self.length_match_tolerance.GetValue(),
            'meander_amplitude': self.meander_amplitude.GetValue(),
            'meander_spacing': self.meander_spacing.GetValue(),
            # Time matching
            'time_matching': self.time_matching_check.GetValue(),
            'time_match_tolerance': self.time_match_tolerance.GetValue(),
        }

        # Parse power nets and widths
        power_nets_text = self.power_nets_ctrl.GetValue().strip()
        power_widths_text = self.power_widths_ctrl.GetValue().strip()
        if power_nets_text:
            config['power_nets'] = _split_net_list(power_nets_text)
            if power_widths_text:
                try:
                    config['power_nets_widths'] = [float(w) for w in power_widths_text.split()]
                except ValueError:
                    config['power_nets_widths'] = []
            else:
                config['power_nets_widths'] = []
        else:
            config['power_nets'] = []
            config['power_nets_widths'] = []

        # Parse no BGA zones
        no_bga_text = self.no_bga_zones_ctrl.GetValue().strip()
        if no_bga_text.upper() == 'ALL':
            config['no_bga_zones'] = []  # Empty list means disable all
        elif no_bga_text:
            config['no_bga_zones'] = _split_net_list(no_bga_text)
        else:
            config['no_bga_zones'] = None  # None means use BGA zones

        # Parse rip-pre-existing-nets (issue #103): empty -> None (keep
        # pre-existing tracks fixed), ALL -> ["*"], else fnmatch patterns.
        rip_existing_text = self.rip_existing_nets_ctrl.GetValue().strip()
        if not rip_existing_text:
            config['rip_existing_nets'] = None
        elif rip_existing_text.upper() == 'ALL':
            config['rip_existing_nets'] = ['*']
        else:
            config['rip_existing_nets'] = _split_net_list(rip_existing_text)

        # Parse layer costs
        config['layer_costs'] = self._selected_layer_costs()

        return config

    def _on_tabbed_view_changed(self, notebook):
        """Called when net panel's tabbed view is created or destroyed.

        Args:
            notebook: The wx.Notebook if tabbed view was created, None if destroyed
        """
        if notebook is None and hasattr(self, '_last_notebook') and self._last_notebook:
            # Tabbed view was destroyed - unbind from old notebook
            try:
                self._last_notebook.Unbind(wx.EVT_NOTEBOOK_PAGE_CHANGED)
            except Exception:
                pass  # Notebook may already be destroyed

        # Keep track of the notebook for cleanup
        self._last_notebook = notebook

    def _get_netclass_params(self, class_name):
        """Get parameters for a net class."""
        return _get_netclass_parameters(class_name)

    def _maybe_offer_planes_for_power_nets(self, selected_nets):
        """If GND and/or VCC is selected without an existing zone, ask the user
        whether they want to create a plane first.

        Returns True if the user accepted and was navigated to the Planes tab
        (so the caller should abort routing); False otherwise.
        """
        # During an automated AI plan run the plan sequences its own
        # route_planes steps - don't interrupt or abort the route step.
        if getattr(self, '_suppress_plane_offer', False):
            return False
        # Suggested net -> layer mappings to offer.
        suggestions = [('GND', 'B.Cu'), ('VCC', 'F.Cu')]

        def normalize(name):
            return name.lstrip('/').upper() if name else ''

        # Map normalized -> actual selected name (so we add the assignment using
        # the exact net name as it appears in the PCB).
        selected_by_norm = {normalize(n): n for n in selected_nets}

        # Existing zones in the loaded PCB - skip suggesting these.
        existing_zone_keys = set()
        for z in getattr(self.pcb_data, 'zones', []) or []:
            existing_zone_keys.add((normalize(z.net_name), z.layer))

        to_offer = []  # list of (actual_net_name, layer)
        for net_norm, layer in suggestions:
            if net_norm not in selected_by_norm:
                continue
            actual = selected_by_norm[net_norm]
            if (net_norm, layer) in existing_zone_keys:
                continue
            if (actual, layer) in self._plane_prompt_dismissed:
                continue
            to_offer.append((actual, layer))

        if not to_offer:
            return False

        # Build the dialog message.
        bullets = "\n".join(f"  • {net} → {layer}" for net, layer in to_offer)
        msg = (
            "Before routing, would you like to create power/ground plane(s) "
            "for the selected net(s)?\n\n"
            f"{bullets}\n\n"
            "Choosing Yes opens the Planes tab with the assignment(s) pre-filled. "
            "You can then click 'Create Planes' there before coming back to route."
        )
        answer = wx.MessageBox(
            msg,
            "Create plane first?",
            wx.YES_NO | wx.ICON_QUESTION,
            parent=self,
        )
        if answer != wx.YES:
            # Remember the dismissal so we don't pester them again this session.
            for entry in to_offer:
                self._plane_prompt_dismissed.add(entry)
            return False

        # Switch to Planes tab, ensure Create mode, and append the assignments.
        planes_idx = None
        for i in range(self.notebook.GetPageCount()):
            if self.notebook.GetPageText(i) == "Planes":
                planes_idx = i
                break
        if planes_idx is None:
            wx.MessageBox(
                "Couldn't find the Planes tab.", "Error",
                wx.OK | wx.ICON_ERROR, parent=self,
            )
            return False

        existing = self.planes_tab.assignment_panel.get_assignments()
        existing_keys = {(tuple(nets), tuple(layers)) for nets, layers in existing}
        for net, layer in to_offer:
            key = ((net,), (layer,))
            if key not in existing_keys:
                existing.append(([net], [layer]))
        self.planes_tab.assignment_panel.set_assignments(existing)

        self.notebook.SetSelection(planes_idx)
        return True

    def _on_route(self, event):
        """Handle route button click."""
        # Pick up any board changes since the last sync BEFORE routing -- most
        # importantly footprint/pad moves from a preceding optimize_caps step,
        # so the router sees the caps where they ACTUALLY are, not where they
        # were at load (#362). Segments/vias/zones/footprints all refresh here.
        self._sync_pcb_data_from_board()
        selected_nets, selected_layers = self._validate_routing_inputs()
        if selected_nets is None:
            return

        # If the user selected GND and/or VCC and there's no zone for them yet,
        # offer to create planes first. If they accept, jump to the Planes tab
        # with the assignment(s) pre-added and don't start routing.
        if self._maybe_offer_planes_for_power_nets(selected_nets):
            return

        # Disable UI during routing
        self.route_btn.Disable()
        self.cancel_btn.SetLabel("Cancel")
        self._cancel_requested = False
        self._routing_start_time = time.time()

        # Build configuration
        config = self._build_routing_config(selected_nets, selected_layers)

        # Run routing in a thread. _apply_pending stays True until the
        # results have actually been APPLIED to the board on the main
        # thread: the worker queues the apply via wx.CallAfter, so the
        # thread can be dead while the copper is still in the event queue
        # -- re-enabling the button on thread death alone let the plan
        # executor start the NEXT step before this one's tracks landed
        # (Andy's 'tracks don't all appear, rerun fixes it').
        self._apply_pending = True
        self._routing_thread = threading.Thread(
            target=self._run_routing,
            args=(config,),
            daemon=True
        )
        self._routing_thread.start()

        # Poll for completion
        self._poll_routing()

    def _run_routing(self, config):
        """Run the routing in a background thread."""
        # Start a fresh clearance ledger so a prior operation's fine-pitch
        # clearance doesn't leak into this board's DRC floor.
        import clearance_ledger
        clearance_ledger.reset()
        from fab_tiers import set_fab_tier_from_config
        set_fab_tier_from_config(config)
        # Set up stdout redirection to capture routing output
        original_stdout = sys.stdout
        sys.stdout = StdoutRedirector(self._append_log, original_stdout)

        try:
            try:
                # Capture stdout during import so startup_checks messages
                # are preserved for error reporting
                import io
                captured = io.StringIO()
                old_stdout = sys.stdout
                sys.stdout = captured
                try:
                    from route import batch_route
                finally:
                    sys.stdout = old_stdout
                    captured_output = captured.getvalue()
                if captured_output:
                    self._append_log(captured_output)
            except _STARTUP_FAILURES as e:
                # StartupCheckError as well as SystemExit (#457 item 3): the
                # checks now raise instead of exiting when route.py is IMPORTED,
                # which is exactly what this call site does. Catching only
                # SystemExit here would turn the friendly dependency dialog below
                # into a raw traceback in the plugin.
                captured_output = captured.getvalue() if 'captured' in dir() else ''
                # Check which dependencies are missing
                missing = []
                try:
                    import numpy
                except ImportError:
                    missing.append('numpy')
                try:
                    import scipy
                except ImportError:
                    missing.append('scipy')
                try:
                    from shapely.geometry import Polygon
                except ImportError:
                    missing.append('shapely')

                if missing:
                    msg = f"Missing Python dependencies: {', '.join(missing)}\n\n"
                    msg += "Install them using KiCad's Python interpreter:\n"
                    msg += f"  {sys.executable} -m pip install " + " ".join(missing)
                    raise RuntimeError(msg)

                # Check if Rust router is the problem
                try:
                    rust_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', 'rust_router')
                    if rust_dir not in sys.path:
                        sys.path.insert(0, rust_dir)
                    if ROOT_DIR not in sys.path:
                        sys.path.insert(0, ROOT_DIR)
                    import rust_alloc  # noqa: F401  # issue #419: MIMALLOC_PURGE_DELAY before grid_router
                    import grid_router
                except ImportError:
                    msg = "Rust router module not found.\n\n"
                    msg += "Build it by running:\n"
                    msg += "  python build_router.py\n\n"
                    msg += "from the KiCadRoutingTools directory."
                    raise RuntimeError(msg)

                # Include any captured output in the error message
                if captured_output.strip():
                    raise RuntimeError(captured_output.strip())
                raise RuntimeError(f"Startup check failed: {e}")

            def check_cancel():
                return self._cancel_requested

            def on_progress(current, total, net_name=""):
                wx.CallAfter(self._update_progress, current, total, net_name)
                # Brief sleep releases GIL, allowing main thread to process CallAfter events
                time.sleep(0.01)

            # Build net_clearances for ALL nets on the PCB
            # This ensures obstacles from nets with larger clearance (e.g., Wide class pads)
            # are properly expanded even when routing nets from a different class
            net_clearances = {}
            net_name_to_id = {net.name: net.net_id for net in self.pcb_data.nets.values()}
            try:
                from .fanout_gui import _get_net_classes_from_board
                all_net_to_class, all_class_names = _get_net_classes_from_board()
                # Cache class clearances
                class_clearance_cache = {}
                for cname in all_class_names:
                    params = self._get_netclass_params(cname)
                    if params:
                        class_clearance_cache[cname] = params.get('clearance', config['clearance'])
                    else:
                        class_clearance_cache[cname] = config['clearance']
                # Build net_clearances for ALL nets
                for net_name, net_id in net_name_to_id.items():
                    cname = all_net_to_class.get(net_name, 'Default')
                    net_clearances[net_id] = class_clearance_cache.get(cname, config['clearance'])
                # #439: checking the Min Clearance override box (== the CLI passing
                # --clearance) makes that base clearance the ceiling -- cap each class
                # at min(class, clearance). Unchecked = classes routed at their own
                # (board Default-derived) clearance, no clamp.
                if config.get('clamp_netclasses', False):
                    _base_clr = config['clearance']
                    net_clearances = {nid: min(clr, _base_clr)
                                      for nid, clr in net_clearances.items()}
            except Exception as e:
                print(f"Warning: Could not get net class clearances: {e}")
                # Fall back to using config clearance for all nets

            # Refresh user-layer guide polylines from the live board so a path
            # drawn this session is used without saving the file first (issue #7).
            if config.get('guide_corridor_enabled'):
                guide_layer = config.get('guide_corridor_layer', 'User.1')
                try:
                    import pcbnew
                    from kicad_parser import extract_guide_paths_from_board
                    board = pcbnew.GetBoard()
                    if board is not None:
                        self.pcb_data.guide_paths = extract_guide_paths_from_board(board, guide_layer)
                        print(f"Guide corridor: found {len(self.pcb_data.guide_paths)} "
                              f"polyline(s) on {guide_layer}")
                        if not self.pcb_data.guide_paths:
                            print(f"  (No graphic lines found on {guide_layer} - "
                                  f"draw a line there to guide routing.)")
                except Exception as e:
                    print(f"Warning: could not read guide paths from board: {e}")

            # Refresh user-layer keepout polygons from the live board so a zone
            # drawn this session is used without saving the file first (issue #27).
            if config.get('keepout_enabled'):
                keepout_layer = config.get('keepout_layer', 'User.2')
                try:
                    import pcbnew
                    from kicad_parser import extract_keepout_zones_from_board
                    board = pcbnew.GetBoard()
                    if board is not None:
                        self.pcb_data.keepout_zones = extract_keepout_zones_from_board(board, keepout_layer)
                        print(f"Keepout: found {len(self.pcb_data.keepout_zones)} "
                              f"polygon(s) on {keepout_layer}")
                        if not self.pcb_data.keepout_zones:
                            print(f"  (No closed polygon found on {keepout_layer} - "
                                  f"draw a polygon there to keep tracks out.)")
                except Exception as e:
                    print(f"Warning: could not read keepout zones from board: {e}")

            def _stage_live_board():
                """Temp-save the LIVE board for the finalize's oracle leg.

                Returns a path the engine owns and deletes, or None so the
                engine falls back to the post-apply oracle. Never raises: the
                oracle leg is an earner, never a blocker.
                """
                try:
                    import tempfile
                    import pcbnew
                    _b = pcbnew.GetBoard()
                    if _b is None:
                        return None
                    with tempfile.NamedTemporaryFile(
                            suffix='.kicad_pcb', delete=False) as _f:
                        _p = _f.name
                    pcbnew.SaveBoard(_p, _b)
                    return _p
                except Exception as e:
                    print(f"(could not stage the live board for the "
                          f"plane-finalize oracle: {e})")
                    return None

            def run_batch(net_names, track_width, clearance, via_size, via_drill):
                """Run batch_route with given parameters."""
                return batch_route(
                    input_file=self.board_filename,
                    output_file="",  # Not used when return_results=True
                    net_names=net_names,
                    layers=config['layers'],
                    track_width=track_width,
                    # #435 companion: Track Width override UNCHECKED (and no impedance)
                    # -> route each net at its OWN netclass width engine-side, matching
                    # the CLI's omitted --track-width. Checked/impedance = the CLI's
                    # explicit flag (verbatim global width).
                    track_width_from_class=(not self.track_width_check.GetValue()
                                            and not config.get('impedance')),
                    clearance=clearance,
                    via_size=via_size,
                    via_drill=via_drill,
                    grid_step=config['grid_step'],
                    via_cost=config['via_cost'],
                    impedance=config.get('impedance'),
                    coplanar_gap=config.get('coplanar_gap', 0.0),
                    coplanar_nets=config.get('coplanar_nets'),
                    max_iterations=config['max_iterations'],
                    max_probe_iterations=config.get('max_probe_iterations', 5000),
                    heuristic_weight=config['heuristic_weight'],
                    proximity_heuristic_factor=config.get('proximity_heuristic_factor', 0.02),
                    turn_cost=config['turn_cost'],
                    direction_preference_cost=config.get('direction_preference_cost', defaults.DIRECTION_PREFERENCE_COST),
                    max_rip_up_count=config['max_ripup'],
                    ripup_abandon_metric=config.get('ripup_abandon_metric', defaults.RIPUP_ABANDON_METRIC),
                    ripup_blocker_select=config.get('ripup_blocker_select', defaults.RIPUP_BLOCKER_SELECT),
                    ordering_strategy=config['ordering_strategy'],
                    direction_order=config.get('direction'),
                    stub_proximity_radius=config['stub_proximity_radius'],
                    stub_proximity_cost=config['stub_proximity_cost'],
                    power_tap_neckdown=config.get('power_tap_neckdown', True),
                    neckdown_length=config.get('neckdown_length', defaults.NECKDOWN_LENGTH),
                    neckdown_taper_length=config.get('neckdown_taper_length', defaults.NECKDOWN_TAPER_LENGTH),
                    via_proximity_cost=config['via_proximity_cost'],
                    track_proximity_distance=config['track_proximity_distance'],
                    track_proximity_cost=config['track_proximity_cost'],
                    bga_proximity_radius=config.get('bga_proximity_radius', 7.0),
                    bga_proximity_cost=config.get('bga_proximity_cost', 0.2),
                    vertical_attraction_radius=config.get('vertical_attraction_radius', 1.0),
                    vertical_attraction_cost=config.get('vertical_attraction_cost', 0.0),
                    ripped_route_avoidance_radius=config.get('ripped_route_avoidance_radius', 1.0),
                    ripped_route_avoidance_cost=config.get('ripped_route_avoidance_cost', 0.1),
                    crossing_penalty=config.get('crossing_penalty', 1000.0),
                    routing_clearance_margin=config['routing_clearance_margin'],
                    hole_to_hole_clearance=config['hole_to_hole_clearance'],
                    board_edge_clearance=config['board_edge_clearance'],
                    enable_layer_switch=config['enable_layer_switch'],
                    crossing_layer_check=not config.get('no_crossing_layer_check', False),
                    can_swap_to_top_layer=config.get('can_swap_to_top_layer', False),
                    swappable_net_patterns=config.get('swappable_nets'),
                    schematic_dir=config.get('schematic_dir'),
                    mps_reverse_rounds=config.get('mps_reverse_rounds', False),
                    mps_layer_swap=config.get('mps_layer_swap', False),
                    keep_input_copper=config.get('keep_input_copper', False),
                    mps_segment_intersection=config.get('mps_segment_intersection', False),
                    bus_enabled=config.get('bus_enabled', False),
                    bus_detection_radius=config.get('bus_detection_radius', 5.0),
                    bus_attraction_radius=config.get('bus_attraction_radius', 5.0),
                    bus_attraction_bonus=config.get('bus_attraction_bonus', 5000),
                    bus_min_nets=config.get('bus_min_nets', 2),
                    guide_corridor_enabled=config.get('guide_corridor_enabled', False),
                    guide_corridor_layer=config.get('guide_corridor_layer', 'User.1'),
                    guide_corridor_spacing=config.get('guide_corridor_spacing', 0.0),
                    keepout_enabled=config.get('keepout_enabled', False),
                    keepout_layer=config.get('keepout_layer', 'User.2'),
                    power_nets=config.get('power_nets', []),
                    power_nets_widths=config.get('power_nets_widths', []),
                    disable_bga_zones=config.get('no_bga_zones'),
                    rip_existing_nets=config.get('rip_existing_nets'),
                    force_reroute=config.get('force_reroute', False),
                    layer_costs=config.get('layer_costs', []),
                    length_match_groups=config.get('length_match_groups'),
                    length_match_tolerance=config.get('length_match_tolerance', 0.1),
                    meander_amplitude=config.get('meander_amplitude', 1.0),
                    meander_spacing=config.get('meander_spacing', defaults.MEANDER_SPACING),
                    time_matching=config.get('time_matching', False),
                    time_match_tolerance=config.get('time_match_tolerance', 1.0),
                    add_teardrops=config.get('add_teardrops', False),
                    verbose=config.get('verbose', False),
                    skip_routing=config.get('skip_routing', False),
                    debug_memory=config.get('debug_memory', False),
                    collect_stats=config.get('stats', False),
                    debug_lines=config['debug_lines'],
                    cancel_check=check_cancel,
                    progress_callback=on_progress,
                    return_results=True,
                    pcb_data=self.pcb_data,
                    net_clearances=net_clearances,
                    # #562 parity: let the plane finalize run its ORACLE leg
                    # IN-RUN, at the CLI's own sequence point, by handing it a
                    # save of the LIVE board to stage onto. Saving the live
                    # board (not re-reading self.board_filename) is the whole
                    # point -- the file on disk lacks copper that earlier
                    # chain steps applied in this session.
                    stage_board_fn=_stage_live_board,
                )

            # Standard routing with a single set of parameters for all selected nets
            successful, failed, total_time, results_data = run_batch(
                config['nets'],
                config['track_width'],
                config['clearance'],
                config['via_size'],
                config['via_drill'],
            )

            if self._cancel_requested:
                wx.CallAfter(self._routing_finished, self._routing_cancelled)
            else:
                # Calculate wall time from button press
                wall_time = time.time() - self._routing_start_time
                # Apply results to pcbnew on main thread
                wx.CallAfter(self._routing_finished,
                             self._apply_results_to_board, results_data,
                             successful, failed, wall_time, config)

        except Exception as e:
            wx.CallAfter(self._routing_finished, self._routing_error, str(e))
        finally:
            # Restore original stdout
            sys.stdout = original_stdout

    def _routing_finished(self, handler, *args):
        """Main-thread completion wrapper: run the apply/cancel/error
        handler, then clear _apply_pending so _poll_routing may re-enable
        the button (the plan executor's busy signal)."""
        try:
            handler(*args)
        finally:
            self._apply_pending = False

    def _poll_routing(self):
        """Poll for routing thread completion AND results application."""
        if (self._routing_thread and self._routing_thread.is_alive()) \
                or getattr(self, '_apply_pending', False):
            wx.CallLater(100, self._poll_routing)
        else:
            self.route_btn.Enable()
            self.cancel_btn.SetLabel("Close")

    def _update_progress(self, current, total, step_name):
        """Update progress bar and status."""
        if total > 0:
            percent = int(100 * current / total)
            self.progress_bar.SetValue(percent)
            self.progress_bar.SetRange(100)
            self.status_text.SetLabel(f"{step_name} ({current}/{total})")
        else:
            # Setup phase - no count, just show the step name
            self.progress_bar.Pulse()  # Indeterminate progress
            self.status_text.SetLabel(step_name)

    def _clear_user_layer_graphics(self, board, layer_name):
        """Remove graphic shapes (lines/polys/rects) on a User layer from the board.

        Used to clear guide/keepout drawings after a successful route so the user
        can draw fresh ones. Returns the number of shapes removed.
        """
        try:
            layer_id = board.GetLayerID(layer_name)
        except Exception:
            return 0
        if layer_id is None or layer_id < 0:
            return 0
        to_remove = []
        for d in board.GetDrawings():
            try:
                if d.GetLayer() == layer_id and d.GetClass() in ("PCB_SHAPE", "DRAWSEGMENT"):
                    to_remove.append(d)
            except Exception:
                continue
        for d in to_remove:
            board.Remove(d)
        return len(to_remove)

    def _apply_results_to_board(self, results_data, successful, failed, total_time, config):
        """Apply routing results directly to the open pcbnew board."""
        import pcbnew
        from .board_swaps import apply_swaps_to_board

        board = pcbnew.GetBoard()
        if board is None:
            wx.MessageBox("Board is no longer open", "Error", wx.OK | wx.ICON_ERROR)
            return

        # Apply pad/stub net swaps (target swaps) and stub layer modifications
        # BEFORE adding new tracks - the routes were created assuming these
        # swaps, so skipping them leaves shorts at swapped pads
        apply_swaps_to_board(board, results_data)

        # Move copper text to silkscreen if enabled. The CLI writer pairs the text
        # and graphic relocations (kicad_writer), so move copper logos/graphics
        # too (issue #146) - otherwise a net-less copper logo shorts the routed
        # copper in the GUI output but not the CLI's.
        text_moved = 0
        if config.get('move_copper_text', True):
            text_moved = self._move_copper_text_to_silkscreen(board)
            from .gui_utils import move_copper_graphics_to_silkscreen_board
            gfx_moved = move_copper_graphics_to_silkscreen_board(board)
            if gfx_moved:
                print(f"Moved {gfx_moved} copper graphic(s)/logo(s) to silkscreen")

        # Track counts for reporting
        tracks_added = 0
        vias_added = 0
        debug_lines_added = 0

        # Get layer mappings
        name_to_id, _ = _build_layer_mappings()

        def get_layer_id(layer_name):
            """Convert layer name to pcbnew layer ID."""
            return name_to_id.get(layer_name, pcbnew.F_Cu)

        # Remove original-board dead-end copper the sweep flagged (issue #84),
        # mirroring the CLI writer's strip so the GUI output matches. Match each
        # flagged segment to an existing board track by its unordered endpoint
        # pair, layer, and net, then delete it.
        tracks_removed = 0
        segs_to_remove = results_data.get('segments_to_remove') or []
        if segs_to_remove:
            remove_keys = set()
            for s in segs_to_remove:
                a = (round(s.start_x, POSITION_DECIMALS), round(s.start_y, POSITION_DECIMALS))
                b = (round(s.end_x, POSITION_DECIMALS), round(s.end_y, POSITION_DECIMALS))
                remove_keys.add((frozenset((a, b)), s.layer, s.net_id))
            for track in list(board.GetTracks()):
                if track.Type() != pcbnew.PCB_TRACE_T:
                    continue  # skip vias / arcs
                a = (round(pcbnew.ToMM(track.GetStart().x), POSITION_DECIMALS),
                     round(pcbnew.ToMM(track.GetStart().y), POSITION_DECIMALS))
                b = (round(pcbnew.ToMM(track.GetEnd().x), POSITION_DECIMALS),
                     round(pcbnew.ToMM(track.GetEnd().y), POSITION_DECIMALS))
                key = (frozenset((a, b)), board.GetLayerName(track.GetLayer()),
                       track.GetNetCode())
                if key in remove_keys:
                    board.Remove(track)
                    tracks_removed += 1

        # Remove stale input VIAS of ripped/re-routed nets (#284), mirroring the
        # CLI writer's remove_vias_from_content -- previously the GUI only
        # removed segments, so the old via and its reroute's replacement both
        # stayed on the live board as a same-net drill pair.
        vias_to_remove = results_data.get('vias_to_remove') or []
        if vias_to_remove:
            via_keys = {(round(v.x, POSITION_DECIMALS), round(v.y, POSITION_DECIMALS),
                         v.net_id) for v in vias_to_remove}
            for track in list(board.GetTracks()):
                if track.Type() != pcbnew.PCB_VIA_T:
                    continue
                vk = (round(pcbnew.ToMM(track.GetPosition().x), POSITION_DECIMALS),
                      round(pcbnew.ToMM(track.GetPosition().y), POSITION_DECIMALS),
                      track.GetNetCode())
                if vk in via_keys:
                    board.Remove(track)
                    tracks_removed += 1

        # Add segments from routing results
        for result in results_data.get('results', []):
            for seg in result.get('new_segments', []):
                track = pcbnew.PCB_TRACK(board)
                # mm -> internal units. mm_to_iu, never FromMM(round(...)):
                # rounding to 1 um moved off-grid copper and FromMM truncates
                # (#493 item 5).
                track.SetStart(pcbnew.VECTOR2I(
                    mm_to_iu(seg.start_x), mm_to_iu(seg.start_y)))
                track.SetEnd(pcbnew.VECTOR2I(
                    mm_to_iu(seg.end_x), mm_to_iu(seg.end_y)))
                track.SetWidth(mm_to_iu(seg.width))  # never position-rounded (#362):
                # round(w,3) drops a 0.0762 fab-floor width to 0.076
                track.SetLayer(get_layer_id(seg.layer))
                track.SetNetCode(seg.net_id)
                board.Add(track)
                tracks_added += 1

            for via in result.get('new_vias', []):
                self._add_via_to_board(board, via, get_layer_id)
                vias_added += 1

        # Add vias from layer swapping
        for via in results_data.get('all_swap_vias', []):
            self._add_via_to_board(board, via, get_layer_id)
            vias_added += 1

        # Add reuse-connector segments from layer swapping (#340): when a swap
        # anchors its layer transition on an existing same-net via instead of
        # drilling a new pad-via hole, the pad->via connector copper rides the
        # all_swap_segments channel -- draw it or the swapped net is left open
        # in the GUI (CLI parity: write_routed_output emits these too).
        for seg in results_data.get('all_swap_segments', []):
            track = pcbnew.PCB_TRACK(board)
            track.SetStart(pcbnew.VECTOR2I(
                mm_to_iu(seg.start_x), mm_to_iu(seg.start_y)))
            track.SetEnd(pcbnew.VECTOR2I(
                mm_to_iu(seg.end_x), mm_to_iu(seg.end_y)))
            track.SetWidth(mm_to_iu(seg.width))  # never position-rounded (#362)
            track.SetLayer(get_layer_id(seg.layer))
            track.SetNetCode(seg.net_id)
            board.Add(track)
            tracks_added += 1

        # Add debug visualization lines if enabled
        if config.get('debug_lines', False):
            debug_lines_added = self._add_debug_lines(board, results_data)

        # Clear guide/keepout User-layer graphics after a successful route, if
        # requested (only for features that were actually enabled this run).
        if successful > 0:
            cleared = 0
            if config.get('clear_guide_layer') and config.get('guide_corridor_enabled'):
                cleared += self._clear_user_layer_graphics(
                    board, config.get('guide_corridor_layer', 'User.1'))
            if config.get('clear_keepout_layer') and config.get('keepout_enabled'):
                cleared += self._clear_user_layer_graphics(
                    board, config.get('keepout_layer', 'User.2'))
            if cleared:
                print(f"Cleared {cleared} graphic(s) from the guide/keepout User layer(s)")

        # Build connectivity to register new items properly
        board.BuildConnectivity()

        # Re-fill plane zones so any pour pulls back around the copper we just
        # routed (#362): a signal routed AFTER planes exist would otherwise
        # leave the plane fill stale (no antipad), which KiCad DRC flags as
        # clearance / shorting violations on the saved board.
        from .gui_utils import refill_all_zones
        _rf = refill_all_zones(board)
        if _rf:
            print(f"Refilled {_rf} zone(s) around the new copper")

        # Plane-finalize ORACLE leg (#562) -- FALLBACK PATH ONLY.
        # Normally the finalize runs the oracle IN-RUN (stage_board_fn above),
        # at the CLI's own sequence point, so its copper lands before the
        # final reconciliation and its unroutable links feed custody. The
        # engine posts 'plane_finalize_oracle' only when it could NOT stage a
        # board (no callback, or the save failed); then the copper is already
        # on the live board and the staged-save oracle runs here instead (the
        # planes-tab pattern, shared core in gui_utils). Post-apply means the
        # reconcile has already run, so this path earns completion but cannot
        # feed custody. Refill afterwards: routed links change the fill.
        _pfo = results_data.get('plane_finalize_oracle') or None
        if _pfo and _pfo.get('nets'):
            try:
                from .gui_utils import run_kicad_oracle_on_live_board
                _orc = run_kicad_oracle_on_live_board(
                    board, _pfo['nets'],
                    clearance=_pfo.get('clearance'),
                    track_width=_pfo.get('track_width'),
                    via_size=_pfo.get('via_size'),
                    via_drill=_pfo.get('via_drill'),
                    grid_step=_pfo.get('grid_step'),
                    hole_to_hole_clearance=_pfo.get(
                        'hole_to_hole_clearance'),
                    layer_clearances=_pfo.get('layer_clearances'))
                if _orc is not None:
                    board.BuildConnectivity()
                    _rf2 = refill_all_zones(board)
                    if _rf2:
                        print(f"Refilled {_rf2} zone(s) after the "
                              f"plane-finalize oracle")
            except Exception as e:
                print(f"(plane-finalize oracle skipped: {e})")

        # Make the live board's DRC constraints consistent with what we just
        # routed to (issue #160), the GUI counterpart of the CLI's
        # fix_kicad_drc_settings: loosen the Board Setup floors + Default net
        # class + non-routing severities to the routed values via the pcbnew API,
        # so the user's manual DRC only flags genuine problems. Best-effort and
        # guarded -- never block applying the routes. The user's next save
        # persists it (mark the board modified).
        if successful > 0 and config.get('fix_drc_settings', True):
            try:
                from fix_kicad_drc_settings import (compute_targets, severity_plan,
                                                    apply_targets_to_board, fab_edge_floor)
                # Grade at the smallest clearance any step actually routed at
                # (e.g. fine-pitch single-ended taps below nominal), like the CLI.
                import clearance_ledger
                eff_clearance = clearance_ledger.effective(config.get('clearance')) \
                    if config.get('clearance') else config.get('clearance')
                targets = compute_targets(
                    clearance=eff_clearance,
                    hole_to_hole=config.get('hole_to_hole_clearance'),
                    edge_clearance=config.get('board_edge_clearance'),
                    track_width=config.get('track_width'),
                    via_diameter=config.get('via_size'),
                    via_drill=config.get('via_drill'),
                    fab_edge=fab_edge_floor())
                drc_changes = apply_targets_to_board(
                    board, targets, severity_plan(keep_thermal=config.get('keep_thermal', False)),
                    clamp_nondefault_netclasses=config.get('clamp_netclasses', False))
                if drc_changes:
                    board.SetModified()
                    print(f"DRC settings: loosened {len(drc_changes)} Board Setup "
                          f"value(s) to the routed floors (save to persist)")
            except Exception as e:
                print(f"(skipped DRC-settings write-back: {e})")

        # #521: persist this run's protection-worthy nets (matched groups) and
        # impedance declarations, engine-noted during batch_route. The diff tab
        # does this via update_live_drc_floors; the signal tab's manual runs
        # end here, so consume at this step boundary or the notes linger until
        # some later consumer writes them.
        try:
            from protected_nets import (consume_protection_candidates,
                                        consume_impedance_specs,
                                        persist_protected_nets,
                                        persist_impedance_specs, pro_path_for_board)
            _bf = board.GetFileName()
            if _bf:
                _pro = pro_path_for_board(_bf)
                persist_protected_nets(_pro, consume_protection_candidates())
                persist_impedance_specs(_pro, consume_impedance_specs())
        except Exception:
            pass

        # Refresh the view
        pcbnew.Refresh()

        # Sync pcb_data from pcbnew board to ensure subsequent routing and
        # connectivity checks see the new tracks
        self._sync_pcb_data_from_board()

        # Update UI and show completion message
        self.progress_bar.SetValue(100)
        self.status_text.SetLabel(f"Complete: {successful} routed, {failed} failed")

        msg = f"Routing complete!\n\n"
        msg += f"Successfully routed: {successful} nets\n"
        msg += f"Failed: {failed}\n"
        msg += f"Time: {total_time:.1f}s\n\n"
        msg += f"Added to board:\n"
        msg += f"  {tracks_added} segments\n"
        msg += f"  {vias_added} vias\n"
        if tracks_removed > 0:
            msg += f"  {tracks_removed} dead-end stub(s) removed\n"
        if text_moved > 0:
            msg += f"  {text_moved} text items moved to silkscreen\n"
        if debug_lines_added > 0:
            msg += f"  {debug_lines_added} debug lines\n"
        # If any nets failed, append heuristic suggestions for what to tweak.
        if failed > 0:
            try:
                from routing_diagnostics import (
                    suggest_route_adjustments, format_suggestions_for_dialog)
                suggestions = suggest_route_adjustments(
                    failed=failed, total=successful + failed, config=config)
                block = format_suggestions_for_dialog(suggestions)
                if block:
                    msg += "\n" + block + "\n"
            except Exception as e:
                print(f"Warning: failed to build routing suggestions: {e}")
        msg += "\nUse Edit -> Undo to revert changes."

        # Routing movie (#506): snapshot the board this step just produced,
        # BEFORE the completion popup blocks on the user. No-op unless the
        # Advanced tab's "Make routing movie" box is ticked.
        from .movie_recorder import record_movie_step
        record_movie_step(self, 'route')

        if getattr(getattr(self, 'GetTopLevelParent', lambda: self)(), '_suppress_completion_popups', False):
            print(msg)  # unattended plan run: no per-step OK dialog
        else:
            wx.MessageBox(msg, "Routing Complete", wx.OK | wx.ICON_INFORMATION)

        # Clear the selected nets since they've been routed
        self.net_panel._checked_nets.clear()
        # Also uncheck all visible checkboxes
        for i in range(self.net_panel.net_list.GetCount()):
            self.net_panel.net_list.Check(i, False)
        # Uncheck in tabbed view if active
        if self.net_panel._tabbed_net_lists:
            for check_list in self.net_panel._tabbed_net_lists.values():
                for i in range(check_list.GetCount()):
                    check_list.Check(i, False)

        # Check connectivity after dialog is dismissed
        self._check_connectivity_with_progress()

        # Refresh net list to hide newly connected nets (don't sync from visible since we just cleared)
        self.net_panel.refresh(sync_from_visible=False)
        self._update_status_bar()

        # Per-step live DRC floors (GUI twin of the CLI's per-step
        # fix_project_for_output): a DRC pressed right after this step must
        # grade at the routed floors, not stock constraints.
        from .gui_utils import update_live_drc_floors
        update_live_drc_floors(
            board,
            clearance=config.get('clearance'),
            track_width=config.get('track_width'),
            via_size=config.get('via_size'),
            via_drill=config.get('via_drill'),
            hole_to_hole=config.get('hole_to_hole_clearance'),
            edge_clearance=config.get('board_edge_clearance'))

    def _add_via_to_board(self, board, via, get_layer_id):
        """Add a via to the pcbnew board."""
        import pcbnew
        pcb_via = pcbnew.PCB_VIA(board)
        # #493 item 5: size/drill were position-rounded too, the same class as
        # the #362 track-width bug (round(0.0762,3) -> 0.076).
        pcb_via.SetPosition(pcbnew.VECTOR2I(mm_to_iu(via.x), mm_to_iu(via.y)))
        pcb_via.SetWidth(mm_to_iu(via.size))
        pcb_via.SetDrill(mm_to_iu(via.drill))
        pcb_via.SetNetCode(via.net_id)
        if hasattr(via, 'layers') and len(via.layers) >= 2:
            top_layer = get_layer_id(via.layers[0])
            bot_layer = get_layer_id(via.layers[1])
            pcb_via.SetLayerPair(top_layer, bot_layer)
        # Keep a re-placed via's own tenting/plugging/filling (#489 §8). A via
        # with no spec is left to inherit the board setting, as before.
        from .gui_utils import apply_via_protection
        apply_via_protection(pcb_via, getattr(via, 'tenting_attrs', None))
        board.Add(pcb_via)

    def _move_copper_text_to_silkscreen(self, board):
        """Move gr_text items from copper layers to silkscreen."""
        import pcbnew

        count = 0
        for drawing in board.GetDrawings():
            if drawing.GetClass() == "PCB_TEXT":
                layer = drawing.GetLayer()
                # Check if on F.Cu or B.Cu
                if layer == pcbnew.F_Cu:
                    drawing.SetLayer(pcbnew.F_SilkS)
                    count += 1
                elif layer == pcbnew.B_Cu:
                    drawing.SetLayer(pcbnew.B_SilkS)
                    count += 1
        return count

    def _add_debug_lines(self, board, results_data):
        """Add debug visualization lines to User layers."""
        import pcbnew

        count = 0

        # User layer mapping
        user_layers = {
            'User.3': pcbnew.User_3,   # Connector lines
            'User.4': pcbnew.User_4,   # Stub direction arrows
            'User.5': pcbnew.User_5,   # Exclusion zones
            'User.8': pcbnew.User_8,   # Simplified path
            'User.9': pcbnew.User_9,   # Raw A* path
        }

        def add_line(start, end, layer_name, width_mm=0.05):
            nonlocal count
            layer_id = user_layers.get(layer_name, pcbnew.User_9)
            # mm_to_iu, not FromMM: FromMM truncates (#493). These are debug
            # overlay graphics rather than routed copper, but the project has
            # ONE canonical mm->IU conversion and mixed converters are how the
            # original #493 divergence arose.
            from kicad_parser import mm_to_iu as _m2i
            shape = pcbnew.PCB_SHAPE(board)
            shape.SetShape(pcbnew.SHAPE_T_SEGMENT)
            shape.SetStart(pcbnew.VECTOR2I(_m2i(start[0]), _m2i(start[1])))
            shape.SetEnd(pcbnew.VECTOR2I(_m2i(end[0]), _m2i(end[1])))
            shape.SetWidth(_m2i(width_mm))
            shape.SetLayer(layer_id)
            board.Add(shape)
            count += 1

        for result in results_data.get('results', []):
            # Raw A* path on User.9
            raw_path = result.get('raw_astar_path', [])
            if len(raw_path) >= 2:
                for i in range(len(raw_path) - 1):
                    x1, y1 = raw_path[i][0], raw_path[i][1]
                    x2, y2 = raw_path[i + 1][0], raw_path[i + 1][1]
                    if abs(x1 - x2) > 0.001 or abs(y1 - y2) > 0.001:
                        add_line((x1, y1), (x2, y2), 'User.9')

            # Simplified path on User.8
            simplified_path = result.get('simplified_path', [])
            if len(simplified_path) >= 2:
                for i in range(len(simplified_path) - 1):
                    x1, y1 = simplified_path[i][0], simplified_path[i][1]
                    x2, y2 = simplified_path[i + 1][0], simplified_path[i + 1][1]
                    if abs(x1 - x2) > 0.001 or abs(y1 - y2) > 0.001:
                        add_line((x1, y1), (x2, y2), 'User.8')

            # Connector segments on User.3
            for start, end in result.get('debug_connector_lines', []):
                add_line(start, end, 'User.3')

            # Stub direction arrows on User.4
            for start, end in result.get('debug_stub_arrows', []):
                add_line(start, end, 'User.4')

        # Exclusion zone lines on User.5
        for start, end in results_data.get('exclusion_zone_lines', []):
            add_line(start, end, 'User.5')

        return count

    def _routing_cancelled(self):
        """Handle routing cancellation."""
        self.route_btn.Enable()
        self.cancel_btn.SetLabel("Close")
        self.progress_bar.SetValue(0)
        self.status_text.SetLabel("Cancelled")

    def _routing_error(self, error_msg):
        """Handle routing error."""
        self.route_btn.Enable()
        self.cancel_btn.SetLabel("Close")
        self.progress_bar.SetValue(0)
        self.status_text.SetLabel("Error")
        wx.MessageBox(
            f"Routing error:\n\n{error_msg}",
            "Routing Error",
            wx.OK | wx.ICON_ERROR
        )

    def get_settings(self):
        """Get all current dialog settings for persistence."""
        return get_dialog_settings(self)
